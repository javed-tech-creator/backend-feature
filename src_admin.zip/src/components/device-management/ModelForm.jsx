import React, { useEffect, useState } from "react";
import PageHeader from "../../components/PageHeader";
import { toast } from "react-toastify";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, ImagePlus, Plus, Save, Trash2 } from "lucide-react";

import {
  useModelCreateMutation,
  useModelUpdateMutation,
  useGetModelByIdQuery,
} from "../../api/model.api";

import { useGetAllDeviceQuery } from "../../api/device.api";
import { useGetBrandsByDeviceQuery } from "../../api/brand.api";
import { useGetAllStorageQuery } from "../../api/storage.api";
import { capitalize, storageLabel } from "../../lib/helper";

const emptyStorageRow = () => ({ storageId: "", basePrice: "" });

const ModelForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const isEdit = !!id;

  const { data: modelData } = useGetModelByIdQuery(id, {
    skip: !id,
  });

  const [createModel, { isLoading: creating }] = useModelCreateMutation();
  const [updateModel, { isLoading: updating }] = useModelUpdateMutation();

  const isLoading = creating || updating;

  const [deviceId, setDeviceId] = useState("");
  const [brandId, setBrandId] = useState("");
  const [name, setName] = useState("");
  const [storageRows, setStorageRows] = useState([emptyStorageRow()]);
  const [logo, setLogo] = useState(null);
  const [preview, setPreview] = useState("");

  const { data: deviceData } = useGetAllDeviceQuery({});
  const { data: brandData } = useGetBrandsByDeviceQuery(deviceId, {
    skip: !deviceId,
  });
  const { data: storageData } = useGetAllStorageQuery({ limit: 100 });

  const devices = deviceData?.data?.data || [];
  const brands = brandData?.data?.data || [];
  const storages = storageData?.data?.data || [];

  // Pre-fill on edit
  useEffect(() => {
    if (!modelData?.data) return;

    const model = modelData.data;

    setName(model.name || "");
    setBrandId(model.brandId?._id || model.brandId || "");
    setPreview(model.logo || "");

    const rows = (model.storages || []).map((row) => ({
      storageId: row.storageId?._id || row.storageId || "",
      basePrice: row.basePrice ?? "",
    }));
    setStorageRows(rows.length ? rows : [emptyStorageRow()]);

    // device from brand (for filtering view)
    const brandDevice =
      model.brandId?.deviceId?._id || model.brandId?.deviceId || "";
    setDeviceId(brandDevice);
  }, [modelData]);

  const updateStorageRow = (index, field, value) => {
    setStorageRows((rows) =>
      rows.map((row, i) => (i === index ? { ...row, [field]: value } : row)),
    );
  };

  const addStorageRow = () =>
    setStorageRows((rows) => [...rows, emptyStorageRow()]);

  const removeStorageRow = (index) =>
    setStorageRows((rows) =>
      rows.length === 1 ? rows : rows.filter((_, i) => i !== index),
    );

  // A storage already priced on another row must not be offered again.
  const availableStorages = (index) =>
    storages.filter(
      (storage) =>
        !storageRows.some(
          (row, i) => i !== index && row.storageId === storage._id,
        ),
    );

  const handleImage = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLogo(file);
    setPreview(URL.createObjectURL(file));
  };

  // Reset brand if device changes
  const handleDeviceChange = (value) => {
    setDeviceId(value);
    setBrandId("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!brandId) {
      toast.error("Please select a brand");
      return;
    }

    if (!name.trim()) {
      toast.error("Model name is required");
      return;
    }

    const filledRows = storageRows.filter(
      (row) => row.storageId || row.basePrice !== "",
    );

    if (!filledRows.length) {
      toast.error("Please add at least one storage with its base price");
      return;
    }

    if (filledRows.some((row) => !row.storageId)) {
      toast.error("Please select a storage for every row");
      return;
    }

    if (
      filledRows.some(
        (row) => row.basePrice === "" || isNaN(Number(row.basePrice)),
      )
    ) {
      toast.error("Every storage needs a valid base price");
      return;
    }

    if (!isEdit && !logo) {
      toast.error("Model logo is required");
      return;
    }

    const formData = new FormData();
    formData.append("brandId", brandId);
    formData.append("name", name.trim());


    // multipart/form-data cannot carry an array of objects, so the rows go as JSON.
    formData.append(
      "storages",
      JSON.stringify(
        filledRows.map((row) => ({
          storageId: row.storageId,
          basePrice: Number(row.basePrice),
        })),
      ),
    );

    if (logo) {
      formData.append("logo", logo);
    }

    try {
      if (isEdit) {
        await updateModel({ id, formData }).unwrap();
        toast.success("Model Updated Successfully");
      } else {
        await createModel(formData).unwrap();
        toast.success("Model Created Successfully");
      }

      navigate("/device-management/models");
    } catch (err) {
      toast.error(err?.data?.message || "Something went wrong");
    }
  };

  return (
    <div>
      <PageHeader
        title={isEdit ? "Edit Model" : "Add Model"}
        subtitle={isEdit ? "Update model information" : "Create a new model"}
      />

      <div className="max-w-7xl mx-auto mt-8">
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden"
        >
          {/* Header */}
          <div className="px-8 py-5 border-b bg-gray-50">
            <h2 className="text-xl font-semibold text-gray-800">
              {isEdit ? "Edit Model" : "Model Information"}
            </h2>

            <p className="text-sm text-gray-500 mt-1">
              Select device to filter brands, enter the model details, then add
              every storage this model is sold in with its own base price.
            </p>
          </div>

          {/* Body */}
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Device (filter for brands) */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Device{" "}
                  <span className="text-gray-400 text-xs">
                    (to filter brands)
                  </span>
                </label>

                <select
                  value={deviceId}
                  onChange={(e) => handleDeviceChange(e.target.value)}
                  className="w-full h-11 rounded-lg border border-gray-300 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Device</option>

                  {devices.map((device) => (
                    <option key={device._id} value={device._id}>
                      {capitalize(device.name)}
                    </option>
                  ))}
                </select>
              </div>

              {/* Brand */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Brand <span className="text-red-500">*</span>
                </label>

                <select
                  value={brandId}
                  onChange={(e) => setBrandId(e.target.value)}
                  disabled={!deviceId}
                  className={`w-full h-11 rounded-lg border border-gray-300 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    !deviceId ? "bg-gray-100 cursor-not-allowed" : ""
                  }`}
                >
                  <option value="">
                    {deviceId ? "Select Brand" : "Select device first"}
                  </option>

                  {brands.map((brand) => (
                    <option key={brand._id} value={brand._id}>
                      {capitalize(brand.name)}
                    </option>
                  ))}
                </select>
              </div>

              {/* Model Name */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Model Name <span className="text-red-500">*</span>
                </label>

                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter Model Name"
                  className="w-full h-11 rounded-lg border border-gray-300 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Storages with their own base price */}
              <div className="md:col-span-2">
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Storages &amp; Base Price{" "}
                    <span className="text-red-500">*</span>
                  </label>

                  <button
                    type="button"
                    onClick={addStorageRow}
                    className="flex items-center gap-1 px-3 py-1.5 text-sm rounded-lg border border-blue-200 bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white transition"
                  >
                    <Plus size={15} />
                    Add Storage
                  </button>
                </div>

                <div className="space-y-3 rounded-lg border border-gray-200 p-4">
                  {storageRows.map((row, index) => (
                    <div key={index} className="flex gap-2">
                      <select
                        value={row.storageId}
                        onChange={(e) =>
                          updateStorageRow(index, "storageId", e.target.value)
                        }
                        className="flex-1 h-11 rounded-lg border border-gray-300 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select Storage</option>

                        {availableStorages(index).map((storage) => (
                          <option key={storage._id} value={storage._id}>
                            {storageLabel(storage)}
                          </option>
                        ))}
                      </select>

                      <input
                        type="number"
                        min="0"
                        step="0.01"
                        value={row.basePrice}
                        onChange={(e) =>
                          updateStorageRow(index, "basePrice", e.target.value)
                        }
                        placeholder="Base Price"
                        className="flex-1 h-11 rounded-lg border border-gray-300 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />

                      <button
                        type="button"
                        title="Remove"
                        onClick={() => removeStorageRow(index)}
                        disabled={storageRows.length === 1}
                        className="w-11 h-11 shrink-0 rounded-lg border border-red-200 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white flex items-center justify-center disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-red-50 disabled:hover:text-red-600"
                      >
                        <Trash2 size={17} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Logo */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Model Logo <span className="text-red-500">*</span>
                </label>

                <label className="h-44 flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-primary hover:bg-blue-50 transition">
                  {preview ? (
                    <img
                      src={preview}
                      alt="Preview"
                      className="w-24 h-24 object-contain"
                    />
                  ) : (
                    <>
                      <ImagePlus size={36} className="text-gray-400 mb-2" />

                      <p className="text-sm font-medium text-gray-600">
                        Upload Logo
                      </p>

                      <span className="text-xs text-gray-400">
                        PNG, JPG, JPEG
                      </span>
                    </>
                  )}

                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImage}
                    required={!isEdit}
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="flex justify-end gap-3 px-6 py-4 border-t bg-gray-50">
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-100"
            >
              <ArrowLeft size={16} />
              Cancel
            </button>

            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 px-5 py-2 bg-primary text-white rounded-lg"
            >
              <Save size={16} />

              {isLoading
                ? isEdit
                  ? "Updating..."
                  : "Saving..."
                : isEdit
                  ? "Update Model"
                  : "Save Model"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ModelForm;
