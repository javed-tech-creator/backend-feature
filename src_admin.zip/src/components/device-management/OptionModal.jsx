import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import {
  X,
  Save,
  ImagePlus,
  Check,
  Percent,
  IndianRupee,
  Ban,
  CircleSlash,
  TrendingUp,
  TrendingDown,
  Tag,
  Sparkles,
} from "lucide-react";
import {
  useOptionCreateMutation,
  useOptionUpdateMutation,
} from "../../api/question.api";
import IconPicker, { AppIcon } from "../IconPicker";

// Mirrors the backend DeductionType enum.
export const ADJUSTMENT_PERCENTAGE = "percentage";
export const ADJUSTMENT_FIXED = "fixed";
export const ADJUSTMENT_NONE = "none";
export const ADJUSTMENT_REJECT = "reject";

export const OPERATION_INCREASE = "increase";
export const OPERATION_DECREASE = "decrease";

// Presentational config for each adjustment type — drives the card selector so
// the UI stays in sync with the backend enum in a single place.
const ADJUSTMENT_TYPES = [
  {
    value: ADJUSTMENT_PERCENTAGE,
    label: "Percentage",
    hint: "Adjust by a % of the price",
    Icon: Percent,
  },
  {
    value: ADJUSTMENT_FIXED,
    label: "Fixed Amount",
    hint: "Adjust by a flat ₹ amount",
    Icon: IndianRupee,
  },
  {
    value: ADJUSTMENT_NONE,
    label: "No Effect",
    hint: "Option has no price impact",
    Icon: CircleSlash,
  },
  {
    value: ADJUSTMENT_REJECT,
    label: "Reject Listing",
    hint: "Block the sale entirely",
    Icon: Ban,
  },
];

const OPERATIONS = [
  {
    value: OPERATION_INCREASE,
    label: "Increase Price",
    hint: "Add to the offer",
    Icon: TrendingUp,
  },
  {
    value: OPERATION_DECREASE,
    label: "Decrease Price",
    hint: "Deduct from the offer",
    Icon: TrendingDown,
  },
];

/**
 * OptionModal — create or edit an answer option for a question.
 *
 *   mode: "add" | "edit"
 *   questionId: string (required for add)
 *   option: existing option object (for edit)
 */
const OptionModal = ({ mode = "add", questionId, option, onClose }) => {
  const isEdit = mode === "edit";

  const [title, setTitle] = useState("");
  const [icon, setIcon] = useState("");
  const [adjustmentType, setAdjustmentType] = useState(ADJUSTMENT_PERCENTAGE);
  const [operation, setOperation] = useState(OPERATION_DECREASE);
  const [value, setValue] = useState("");
  const [pickerOpen, setPickerOpen] = useState(false);

  const [createOption, { isLoading: creating }] = useOptionCreateMutation();
  const [updateOption, { isLoading: updating }] = useOptionUpdateMutation();
  const isLoading = creating || updating;

  useEffect(() => {
    if (isEdit && option) {
      setTitle(option.title || "");
      setIcon(option.icon || "");
      setAdjustmentType(option.adjustmentType || ADJUSTMENT_PERCENTAGE);

      setOperation(option.operation || OPERATION_DECREASE);

      setValue(
        option.value === null || option.value === undefined
          ? ""
          : String(option.value),
      );
    }
  }, [isEdit, option]);

  const hideControls =
    adjustmentType === ADJUSTMENT_NONE || adjustmentType === ADJUSTMENT_REJECT;
  const isPercentage = adjustmentType === ADJUSTMENT_PERCENTAGE;

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!title.trim()) {
      toast.error("Option title is required");
      return;
    }

    if (!hideControls) {
      if (value === "" || isNaN(Number(value))) {
        toast.error("Adjustment value is required");
        return;
      }

      if (Number(value) < 0) {
        toast.error("Value cannot be negative");
        return;
      }

      if (adjustmentType === ADJUSTMENT_PERCENTAGE && Number(value) > 100) {
        toast.error("Percentage cannot exceed 100");
        return;
      }
    }

    const adjustmentValue = Number(value);

    const payload = {
      title: title.trim(),
      icon: icon || undefined,
      value: hideControls ? null : adjustmentValue,
      adjustmentType,
      operation: hideControls ? null : operation,
    };

    try {
      if (isEdit) {
        await updateOption({ id: option._id, data: payload }).unwrap();
        toast.success("Option updated");
      } else {
        await createOption({ ...payload, questionId }).unwrap();
        toast.success("Option added");
      }
      onClose();
    } catch (err) {
      toast.error(err?.data?.message || "Something went wrong");
    }
  };

  const getPreview = () => {
    if (adjustmentType === ADJUSTMENT_NONE) {
      return "No Price Impact";
    }

    if (adjustmentType === ADJUSTMENT_REJECT) {
      return "Reject Listing";
    }

    const sign = operation === OPERATION_INCREASE ? "+" : "-";

    if (adjustmentType === ADJUSTMENT_PERCENTAGE) {
      return `${sign}${value || 0}%`;
    }

    return `${sign}₹${value || 0}`;
  };

  // Preview colour follows the semantic meaning of the adjustment.
  const previewColor =
    adjustmentType === ADJUSTMENT_REJECT
      ? "text-red-600"
      : adjustmentType === ADJUSTMENT_NONE
        ? "text-gray-600"
        : operation === OPERATION_INCREASE
          ? "text-green-600"
          : "text-red-600";

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
        <form
          onSubmit={handleSubmit}
          className="w-full max-w-lg rounded-2xl bg-white shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-sky-50">
            <div className="min-w-0">
              <h3 className="text-lg font-semibold text-gray-800">
                {isEdit ? "Edit Answer Option" : "Add Answer Option"}
              </h3>
              <p className="text-xs text-gray-500 mt-0.5">
                Define a choice and how it affects the final price.
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="w-9 h-9 shrink-0 rounded-lg border bg-white text-gray-500 hover:bg-gray-100 flex items-center justify-center"
            >
              <X size={18} />
            </button>
          </div>

          <div className="p-6 space-y-6 overflow-y-auto">
            {/* Option Title */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Option Title <span className="text-red-500">*</span>
              </label>

              <div className="relative">
                <Tag
                  size={16}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                />
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Minor Scratches"
                  className="w-full h-11 rounded-lg border border-gray-300 pl-10 pr-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>
            </div>

            {/* Icon */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Icon <span className="text-gray-400">(optional)</span>
              </label>

              <button
                type="button"
                onClick={() => setPickerOpen(true)}
                className="w-full h-11 flex items-center gap-2 rounded-lg border border-gray-300 px-3 hover:border-primary hover:bg-blue-50 transition"
              >
                {icon ? (
                  <>
                    <AppIcon name={icon} size={18} className="text-primary" />
                    <span className="truncate">{icon}</span>
                  </>
                ) : (
                  <>
                    <ImagePlus size={18} className="text-gray-400" />
                    <span className="text-gray-400">Select an icon</span>
                  </>
                )}
              </button>

              {icon && (
                <button
                  type="button"
                  onClick={() => setIcon("")}
                  className="mt-2 text-xs text-red-500 hover:underline"
                >
                  Remove icon
                </button>
              )}
            </div>

            {/* Adjustment Type — card selector */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Adjustment Type
              </label>

              <div className="grid grid-cols-2 gap-2">
                {ADJUSTMENT_TYPES.map((item) => {
                  const active = adjustmentType === item.value;
                  const { Icon } = item;
                  return (
                    <button
                      type="button"
                      key={item.value}
                      onClick={() => setAdjustmentType(item.value)}
                      className={`flex items-start gap-2.5 rounded-xl border px-3 py-2.5 text-left transition ${
                        active
                          ? "border-primary bg-blue-50"
                          : "border-gray-200 hover:border-primary hover:bg-blue-50/50"
                      }`}
                    >
                      <span
                        className={`mt-0.5 w-8 h-8 shrink-0 rounded-lg flex items-center justify-center ${
                          active
                            ? "bg-primary text-white"
                            : "bg-gray-100 text-gray-500"
                        }`}
                      >
                        <Icon size={16} />
                      </span>
                      <span className="min-w-0">
                        <span className="block text-sm font-medium text-gray-800">
                          {item.label}
                        </span>
                        <span className="block text-xs text-gray-500">
                          {item.hint}
                        </span>
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {!hideControls && (
              <>
                {/* Operation — card selector */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Operation
                  </label>

                  <div className="grid grid-cols-2 gap-2">
                    {OPERATIONS.map((item) => {
                      const active = operation === item.value;
                      const { Icon } = item;
                      return (
                        <button
                          type="button"
                          key={item.value}
                          onClick={() => setOperation(item.value)}
                          className={`flex items-center gap-2.5 rounded-xl border px-3 py-2.5 text-left transition ${
                            active
                              ? "border-primary bg-blue-50"
                              : "border-gray-200 hover:border-primary hover:bg-blue-50/50"
                          }`}
                        >
                          <span
                            className={`w-8 h-8 shrink-0 rounded-lg flex items-center justify-center ${
                              active
                                ? "bg-primary text-white"
                                : "bg-gray-100 text-gray-500"
                            }`}
                          >
                            <Icon size={16} />
                          </span>
                          <span className="min-w-0">
                            <span className="block text-sm font-medium text-gray-800">
                              {item.label}
                            </span>
                            <span className="block text-xs text-gray-500">
                              {item.hint}
                            </span>
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Adjustment Value */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Adjustment Value <span className="text-red-500">*</span>
                  </label>

                  <div className="relative">
                    <input
                      type="number"
                      value={value}
                      min="0"
                      max={isPercentage ? 100 : undefined}
                      onChange={(e) => setValue(e.target.value)}
                      placeholder={isPercentage ? "e.g. 10" : "e.g. 500"}
                      className="w-full h-11 rounded-lg border border-gray-300 pl-3 pr-12 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    />

                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 font-medium">
                      {isPercentage ? "%" : "₹"}
                    </span>
                  </div>

                  <p className="mt-1.5 text-xs text-gray-400">
                    {isPercentage
                      ? "Enter a value between 0 and 100."
                      : "Enter the flat amount in rupees."}
                  </p>
                </div>
              </>
            )}

            {/* Preview — prominent visual chip */}
            <div className="rounded-xl border border-gray-200 bg-gradient-to-br from-slate-50 to-blue-50/50 p-4">
              <div className="flex items-center gap-1.5 text-xs font-medium text-gray-500 mb-2">
                <Sparkles size={13} className="text-primary" />
                Live Preview
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xs text-gray-400">Price impact</span>
                <span
                  className={`text-lg font-bold ${previewColor} flex items-center gap-2`}
                >
                  {getPreview()}
                </span>
              </div>

              {icon && (
                <div className="mt-3 pt-3 border-t border-gray-200 flex items-center gap-2">
                  <AppIcon name={icon} size={18} className="text-primary" />
                  <span className="text-sm text-gray-700 truncate">
                    {title || "Untitled option"}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="flex justify-end gap-3 px-6 py-4 border-t bg-gray-50">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border rounded-lg text-sm text-gray-700 hover:bg-gray-100 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 px-5 py-2 bg-primary text-white rounded-lg text-sm disabled:opacity-60 hover:opacity-90 transition"
            >
              <Save size={16} />
              {isLoading
                ? isEdit
                  ? "Updating..."
                  : "Saving..."
                : isEdit
                  ? "Update Option"
                  : "Add Option"}
            </button>
          </div>
        </form>
      </div>

      {pickerOpen && (
        <IconPicker
          value={icon}
          onSelect={(name) => setIcon(name)}
          onClose={() => setPickerOpen(false)}
        />
      )}
    </>
  );
};

export default OptionModal;
