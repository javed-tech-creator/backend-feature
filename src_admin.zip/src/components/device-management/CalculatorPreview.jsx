import React, { useEffect, useMemo, useState } from "react";
import { toast } from "react-toastify";
import { Calculator, Loader2, RotateCcw, TrendingDown } from "lucide-react";

import { useGetAllDeviceQuery } from "../../api/device.api";
import { useGetBrandsByDeviceQuery } from "../../api/brand.api";
import { useGetAllModelQuery, useGetModelByIdQuery } from "../../api/model.api";
import {
  useGetCalculatorQuestionsQuery,
  useCalculatePriceMutation,
} from "../../api/calculator.api";
import { AppIcon } from "../IconPicker";
import {
  capitalize,
  formatAdjustment,
  formatPrice,
  storageLabel,
} from "../../lib/helper";

const toArray = (res) => {
  const inner = res?.data;
  if (Array.isArray(inner)) return inner;
  if (Array.isArray(inner?.data)) return inner.data;
  return [];
};

const Field = ({ label, children }) => (
  <div>
    <label className="block text-sm font-medium text-gray-700 mb-2">
      {label}
    </label>
    {children}
  </div>
);

const selectClass =
  "w-full h-11 rounded-lg border border-gray-300 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100 disabled:cursor-not-allowed";

/**
 * CalculatorPreview — lets an admin run the live pricing rules end to end:
 * pick a device/brand/model/storage, answer the questions, see the breakdown.
 */
const CalculatorPreview = () => {
  const [deviceId, setDeviceId] = useState("");
  const [brandId, setBrandId] = useState("");
  const [modelId, setModelId] = useState("");
  const [storageId, setStorageId] = useState("");
  const [answers, setAnswers] = useState({}); // questionId -> optionId
  const [result, setResult] = useState(null);

  const { data: deviceRes } = useGetAllDeviceQuery({ limit: 100 });
  const { data: brandRes } = useGetBrandsByDeviceQuery(deviceId, {
    skip: !deviceId,
  });
  const { data: modelRes, isFetching: modelsLoading } = useGetAllModelQuery(
    { brandId, limit: 100 },
    { skip: !brandId },
  );
  // The list response already carries `storages`, but the detail call keeps the
  // dropdown correct even when the model sits beyond the first page.
  const { data: modelDetail } = useGetModelByIdQuery(modelId, {
    skip: !modelId,
  });
  const { data: questionRes, isFetching: questionsLoading } =
    useGetCalculatorQuestionsQuery(deviceId, { skip: !deviceId });

  const [calculate, { isLoading: calculating }] = useCalculatePriceMutation();

  const devices = toArray(deviceRes);
  const brands = toArray(brandRes);
  const models = toArray(modelRes);
  const questions = useMemo(() => {
    const inner = questionRes?.data;
    return Array.isArray(inner) ? inner : [];
  }, [questionRes]);

  const storages = modelDetail?.data?.storages || [];
  const selectedStorage = storages.find(
    (row) => (row.storageId?._id || row.storageId) === storageId,
  );
  const basePrice = selectedStorage?.basePrice;

  // Any change higher up the chain invalidates everything below it.
  useEffect(() => {
    setBrandId("");
  }, [deviceId]);

  useEffect(() => {
    setModelId("");
  }, [brandId]);

  useEffect(() => {
    setStorageId("");
  }, [modelId]);

  // The questionnaire belongs to the device, so switching device drops answers.
  useEffect(() => {
    setAnswers({});
    setResult(null);
  }, [deviceId]);

  useEffect(() => {
    setResult(null);
  }, [storageId, answers]);

  const answeredCount = Object.keys(answers).length;

  const handleReset = () => {
    setAnswers({});
    setResult(null);
  };

  const handleCalculate = async () => {
    if (!modelId || !storageId) {
      toast.error("Please select a model and its storage");
      return;
    }

    if (questions.length && answeredCount === 0) {
      toast.error("Answer at least one question to calculate");
      return;
    }

    const payload = {
      modelId,
      storageId,
      answers: Object.entries(answers).map(([questionId, optionId]) => ({
        questionId,
        optionId,
      })),
    };

    try {
      const res = await calculate(payload).unwrap();
      setResult(res?.data || null);
    } catch (err) {
      toast.error(err?.data?.message || "Could not calculate the price");
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-[1fr_380px] gap-5 items-start">
      {/* Left — selection + questions */}
      <div className="space-y-5">
        <section className="bg-white rounded-2xl shadow-md border border-gray-200 border-l-4 border-l-primary overflow-hidden">
          <div className="px-5 py-3 border-b border-gray-200 bg-sky-50 flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-primary text-white text-xs font-bold flex items-center justify-center">
              1
            </span>
            <h2 className="text-sm font-semibold text-gray-800">
              Select the Device
            </h2>
          </div>

          <div className="p-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Device">
              <select
                value={deviceId}
                onChange={(e) => setDeviceId(e.target.value)}
                className={selectClass}
              >
                <option value="">Select Device</option>
                {devices.map((device) => (
                  <option key={device._id} value={device._id}>
                    {capitalize(device.name)}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Brand">
              <select
                value={brandId}
                onChange={(e) => setBrandId(e.target.value)}
                disabled={!deviceId}
                className={selectClass}
              >
                <option value="">
                  {deviceId ? "Select Brand" : "Select device first"}
                </option>
                {brands.map((brand) => (
                  <option key={brand._id} value={brand._id}>
                    {capitalize(brand.name)}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Model">
              <select
                value={modelId}
                onChange={(e) => setModelId(e.target.value)}
                disabled={!brandId || modelsLoading}
                className={selectClass}
              >
                <option value="">
                  {!brandId
                    ? "Select brand first"
                    : modelsLoading
                      ? "Loading models..."
                      : "Select Model"}
                </option>
                {models.map((model) => (
                  <option key={model._id} value={model._id}>
                    {capitalize(model.name)}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Storage">
              <select
                value={storageId}
                onChange={(e) => setStorageId(e.target.value)}
                disabled={!modelId}
                className={selectClass}
              >
                <option value="">
                  {modelId ? "Select Storage" : "Select model first"}
                </option>
                {storages.map((row) => (
                  <option
                    key={row._id}
                    value={row.storageId?._id || row.storageId}
                  >
                    {storageLabel(row.storageId)} — {formatPrice(row.basePrice)}
                  </option>
                ))}
              </select>
            </Field>
          </div>
        </section>

        <section className="bg-white rounded-2xl shadow-md border border-gray-200 border-l-4 border-l-primary overflow-hidden">
          <div className="px-5 py-3 border-b border-gray-200 bg-sky-50 flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-primary text-white text-xs font-bold flex items-center justify-center">
              2
            </span>
            <h2 className="text-sm font-semibold text-gray-800">
              Answer the Questions
            </h2>
            {questions.length > 0 && (
              <span className="ml-auto text-xs text-gray-500">
                {answeredCount}/{questions.length} answered
              </span>
            )}
          </div>

          <div className="p-5">
            {!deviceId ? (
              <p className="text-sm text-gray-500 py-6 text-center">
                Select a device to load its questions.
              </p>
            ) : questionsLoading ? (
              <p className="flex items-center justify-center gap-2 text-sm text-gray-400 py-8">
                <Loader2 size={16} className="animate-spin" /> Loading
                questions...
              </p>
            ) : questions.length === 0 ? (
              <p className="text-sm text-gray-500 py-6 text-center">
                No active questions for this device yet.
              </p>
            ) : (
              <div className="space-y-5">
                {questions.map((question, index) => (
                  <div key={question._id}>
                    <div className="flex items-start gap-2.5 mb-2.5">
                      <span className="mt-0.5 w-6 h-6 shrink-0 rounded-lg bg-primary text-white text-[11px] font-semibold flex items-center justify-center">
                        {index + 1}
                      </span>
                      <p className="font-medium text-gray-800">
                        {question.title}
                      </p>
                    </div>

                    {question.options?.length ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pl-8">
                        {question.options.map((option) => {
                          const active = answers[question._id] === option._id;
                          return (
                            <button
                              key={option._id}
                              type="button"
                              onClick={() =>
                                setAnswers((prev) => ({
                                  ...prev,
                                  [question._id]: option._id,
                                }))
                              }
                              className={`flex items-center gap-3 rounded-lg border px-3 py-2 text-left transition ${
                                active
                                  ? "border-primary bg-blue-50"
                                  : "border-gray-200 hover:border-primary hover:bg-blue-50/50"
                              }`}
                            >
                              <span
                                className={`w-9 h-9 shrink-0 rounded-lg flex items-center justify-center ${
                                  active
                                    ? "bg-primary text-white"
                                    : "bg-sky-50 border border-sky-100 text-primary"
                                }`}
                              >
                                <AppIcon name={option.icon} size={18} />
                              </span>
                              <span className="min-w-0 flex-1">
                                <span className="block text-sm text-gray-800 truncate">
                                  {option.title}
                                </span>
                                <span className="block text-xs text-red-500">
                                  {formatAdjustment(option)}
                                </span>
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="pl-8 text-xs text-gray-400 italic">
                        No options configured for this question.
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Right — the offer */}
      <section className="bg-white rounded-2xl shadow-md border border-gray-200 border-l-4 border-l-primary overflow-hidden xl:sticky xl:top-4">
        <div className="px-5 py-3 border-b border-gray-200 bg-sky-50 flex items-center gap-2">
          <span className="w-6 h-6 rounded-full bg-primary text-white text-xs font-bold flex items-center justify-center">
            3
          </span>
          <h2 className="text-sm font-semibold text-gray-800">The Offer</h2>
        </div>

        <div className="p-5 space-y-4">
          <div className="flex items-center justify-between rounded-xl bg-sky-50 border border-sky-100 px-4 py-3">
            <span className="text-sm text-gray-600">Base Price</span>
            <span className="font-semibold text-gray-800">
              {basePrice === undefined ? "--" : formatPrice(basePrice)}
            </span>
          </div>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={handleCalculate}
              disabled={calculating || !storageId}
              className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-primary text-white text-sm hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {calculating ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <Calculator size={16} />
              )}
              {calculating ? "Calculating..." : "Calculate"}
            </button>
            <button
              type="button"
              onClick={handleReset}
              title="Clear answers"
              className="w-11 h-11 shrink-0 rounded-lg border border-gray-300 text-gray-500 hover:bg-gray-100 flex items-center justify-center"
            >
              <RotateCcw size={16} />
            </button>
          </div>

          {!result ? (
            <p className="text-center text-sm text-gray-400 py-8">
              Pick a storage, answer the questions, then hit Calculate.
            </p>
          ) : (
            <div className="space-y-3">
              <div>
                <p className="text-xs uppercase tracking-wide text-gray-400 mb-2">
                  Deductions
                </p>

                {result.deductions?.length ? (
                  <div className="space-y-1.5">
                    {result.deductions.map((line, index) => (
                      <div
                        key={`${line.question}-${index}`}
                        className="flex items-start justify-between gap-3 text-sm border-b border-dashed border-gray-200 pb-1.5"
                      >
                        <span className="min-w-0">
                          <span className="block text-gray-700 truncate">
                            {line.question}
                          </span>
                          <span className="block text-xs text-gray-400">
                            {line.option} ·{" "}
                            {line.type === "fixed"
                              ? formatPrice(line.value)
                              : `${line.value}%`}
                          </span>
                        </span>
                        <span className="text-red-500 shrink-0">
                          − {formatPrice(line.amount)}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-400">
                    No deductions applied.
                  </p>
                )}
              </div>

              <div className="flex items-center justify-between text-sm">
                <span className="inline-flex items-center gap-1.5 text-gray-600">
                  <TrendingDown size={15} className="text-red-500" />
                  Total Deduction
                </span>
                <span className="font-medium text-red-500">
                  − {formatPrice(result.totalDeduction)}
                </span>
              </div>

              <div className="flex items-center justify-between rounded-xl bg-emerald-50 border border-emerald-200 px-4 py-3">
                <span className="text-sm font-medium text-emerald-800">
                  Final Offer
                </span>
                <span className="text-xl font-bold text-emerald-700">
                  {formatPrice(result.finalOffer)}
                </span>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default CalculatorPreview;
