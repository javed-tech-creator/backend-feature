import React, { useEffect, useState } from "react";
import PageHeader from "../../components/PageHeader";
import { toast } from "react-toastify";
import { useNavigate, useParams } from "react-router-dom";
import { ImagePlus, Save, ArrowLeft } from "lucide-react";
import {
  useDeviceCreateMutation,
  useDeviceUpdateMutation,
  useGetDeviceByIdQuery,
} from "../../api/device.api";

const DeviceForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;
  const { data, isFetching } = useGetDeviceByIdQuery(id, {
    skip: !id,
  });
  const [createDevice, { isLoading: creating }] = useDeviceCreateMutation();
  const [updateDevice, { isLoading: updating }] = useDeviceUpdateMutation();
  const isLoading = creating || updating;

  useEffect(() => {
    console.log("Fetched Device Data:", data);
    if (data?.data) {
      setName(data.data.name);
      setPreview(data.data.logo);
    }
  }, [data]);

  const [name, setName] = useState("");
  const [logo, setLogo] = useState(null);
  const [preview, setPreview] = useState("");

  const handleImage = (e) => {
    const file = e.target.files[0];

    if (!file) return;

    setLogo(file);
    setPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("Device name is required");
      return;
    }

    try {
      const formData = new FormData();

      formData.append("name", name.trim().toLowerCase());
      if (logo) {
        formData.append("logo", logo);
      }
      if (isEdit) {
        await updateDevice({ id, formData }).unwrap();

        toast.success("Device Updated Successfully");
      } else {
        if (!logo) {
          toast.error("Device logo is required");
          return;
        }

        await createDevice({ formData }).unwrap();

        toast.success("Device Created Successfully");
      }
      navigate("/device-management/devices");
    } catch (err) {
      toast.error(err?.data?.message || "Something went wrong");
    }
  };

  return (
    <div>
      <PageHeader
        title={isEdit ? "Edit Device" : "Add Device"}
        subtitle={
          isEdit
            ? "Update device information"
            : "Create a new device for your inventory"
        }
      />

      <div className="max-w-7xl mx-auto mt-8">
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden"
        >
          {/* Header */}
          <div className="px-8 py-5 border-b bg-gray-50">
            <h2 className="text-xl font-semibold text-gray-800">
              {isEdit ? "Edit Device" : "Device Information"}
            </h2>

            <p className="text-sm text-gray-500 mt-1">
              {isEdit
                ? "Update the device details."
                : "Fill in the details below to add a new device."}
            </p>
          </div>

          {/* Body */}
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Device Name */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Device Name <span className="text-red-500">*</span>
                </label>

                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter device name"
                  className="w-full h-11 rounded-lg border border-gray-300 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>

              {/* Logo Upload */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Device Logo <span className="text-red-500">*</span>
                </label>

                <label className="h-44 flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-primary/80 hover:bg-blue-50 transition">
                  {preview ? (
                    <img
                      src={preview}
                      alt="Preview"
                      className="w-24 h-24 object-contain"
                    />
                  ) : (
                    <>
                      <ImagePlus size={36} className="text-gray-400 mb-2" />
                      <p className="text-sm font-medium text-gray-600">
                        Upload Logo
                      </p>
                      <span className="text-xs text-gray-400">
                        PNG, JPG, JPEG
                      </span>
                    </>
                  )}

                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImage}
                    className="hidden"
                    required={!isEdit}
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="flex justify-end gap-3 px-6 py-4 border-t bg-gray-50">
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="flex items-center gap-2 px-4 py-1.5 border rounded-lg text-gray-700 hover:bg-gray-100 transition cursor-pointer"
            >
              <ArrowLeft size={16} />
              Cancel
            </button>

            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 px-5 py-1.5 bg-primary text-white rounded-lg cursor-pointer"
            >
              <Save size={16} />

              {isLoading
                ? isEdit
                  ? "Updating..."
                  : "Saving..."
                : isEdit
                  ? "Update Device"
                  : "Save Device"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DeviceForm;
