import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Download, UploadCloud } from "lucide-react";
import { toast } from "react-toastify";
import PageHeader from "../../components/PageHeader";
import { useGetAllDeviceQuery } from "../../api/device.api";
import { useGetBrandsByDeviceQuery } from "../../api/brand.api";
import { useUploadModelsMutation } from "../../api/model.api";
import { capitalize } from "../../lib/helper";

const ModelUploadPage = () => {
  const navigate = useNavigate();
  const [deviceId, setDeviceId] = useState("");
  const [brandId, setBrandId] = useState("");
  const [file, setFile] = useState(null);

  const { data: deviceData } = useGetAllDeviceQuery({});
  const { data: brandData } = useGetBrandsByDeviceQuery(deviceId, {
    skip: !deviceId,
  });

  const [uploadModels, { isLoading: uploading }] = useUploadModelsMutation();

  const devices = deviceData?.data?.data || [];
  const brands = brandData?.data?.data || [];

  useEffect(() => {
    if (!deviceId) {
      setBrandId("");
    }
  }, [deviceId]);

  const handleFileChange = (event) => {
    const selectedFile = event.target.files?.[0] || null;
    setFile(selectedFile);
  };

  const downloadTemplate = () => {
    const csv =
      "Model Name,Storage,Price\nGalaxy S23,8GB / 128GB,49999\nGalaxy S23,12GB / 256GB,59999\nGalaxy A15,4GB / 64GB,16999\n";
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "model-upload-template.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (!deviceId) {
      toast.error("Please select a device first.");
      return;
    }

    if (!brandId) {
      toast.error("Please select a brand.");
      return;
    }

    if (!file) {
      toast.error("Please choose an Excel file to upload.");
      return;
    }

    try {
      await uploadModels({ file, deviceId, brandId }).unwrap();
      toast.success("Models uploaded successfully.");
      navigate("/device-management/models");
    } catch (err) {
      toast.error(err?.data?.message || "Failed to upload models.");
    }
  };

  return (
    <div>
      <PageHeader
        title="Upload Model Excel"
      />

      <div className="max-w-7xl mx-auto mt-5">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
          <Link
            to="/device-management/models"
            className="inline-flex items-center gap-2 rounded-md border border-gray-300 bg-white px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
          >
            <ArrowLeft size={16} />
            Back to Models
          </Link>

          <button
            type="button"
            onClick={downloadTemplate}
            className="inline-flex items-center gap-2 rounded-md border border-blue-200 px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary/80 cursor-pointer"
          >
            <Download size={16} />
            Download Template
          </button>
        </div>

        <form
          onSubmit={handleSubmit}
          className="space-y-6 rounded-md border border-gray-200 bg-white p-6 shadow-sm"
        >
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Device <span className="text-red-500">*</span>
              </label>
              <select
                value={deviceId}
                onChange={(e) => setDeviceId(e.target.value)}
                className="w-full rounded-md border border-gray-300 bg-white px-4 py-3 text-sm text-gray-700 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200"
              >
                <option value="">Select Device</option>
                {devices.map((device) => (
                  <option key={device._id} value={device._id}>
                    {capitalize(device.name)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Brand <span className="text-red-500">*</span>
              </label>
              <select
                value={brandId}
                onChange={(e) => setBrandId(e.target.value)}
                disabled={!deviceId}
                className="w-full rounded-md border border-gray-300 bg-white px-4 py-3 text-sm text-gray-700 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200 disabled:cursor-not-allowed disabled:bg-gray-100"
              >
                <option value="">
                  {deviceId ? "Select Brand" : "Select device first"}
                </option>
                {brands.map((brand) => (
                  <option key={brand._id} value={brand._id}>
                    {capitalize(brand.name)}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-2 rounded-md border border-dashed border-gray-300 bg-gray-50 p-6 text-center">
            <UploadCloud size={36} className="mx-auto text-blue-600" />
            <p className="text-sm font-medium text-gray-900">Select an Excel file</p>
            <p className="text-sm text-gray-500">
              File must include columns: <strong>Model Name</strong>, <strong>Storage</strong>, and <strong>Price</strong>.
            </p>

            <label className="mx-auto inline-flex cursor-pointer items-center gap-2 rounded-md bg-white px-5 py-3 text-sm font-medium text-blue-700 shadow-sm transition hover:bg-blue-50">
              Choose File
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={handleFileChange}
              />
            </label>

            {file ? (
              <p className="text-sm text-gray-600">Selected file: {file.name}</p>
            ) : (
              <p className="text-sm text-gray-500">No file selected yet.</p>
            )}
          </div>

          <div className="rounded-md border border-gray-200 bg-white p-6">
            <h3 className="text-base font-semibold text-gray-900 mb-3">How the upload works</h3>
            <ul className="space-y-2 text-sm leading-6 text-gray-600">
              <li>• Rows with the same model name will be combined into one model entry.</li>
              <li>• Each distinct storage value under a model becomes its own storage row with the provided price.</li>
              <li>• The selected device and brand are applied to every uploaded model.</li>
              <li>• Uploads are sent to the backend as multipart form data.</li>
            </ul>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:justify-end">
            <button
              type="button"
              onClick={() => navigate("/device-management/models")}
              className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={uploading}
              className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-white hover:bg-primary/80 disabled:cursor-not-allowed disabled:bg-blue-300"
            >
              {uploading ? "Uploading..." : "Upload Models"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ModelUploadPage;
