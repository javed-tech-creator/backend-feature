import React from "react";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";
import { useGetAllOrdersQuery } from "../../api/order.api";
import { usePagination, extractPaginatedData } from "../../lib/usePagination";

const display = (value) => value || "--";
const formatDateTime = (value) => {
  if (!value) return "--";

  const date = new Date(value);
  const dateLabel = `${date.getDate()} ${date.toLocaleString("en-US", {
    month: "short",
  })} ${date.getFullYear()}`;
  const timeLabel = date.toLocaleString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

  return (
    <div className="text-center whitespace-nowrap">
      <div>{dateLabel}</div>
      <div className="text-xs text-gray-500">{timeLabel}</div>
    </div>
  );
};
const formatPrice = (value) => (value == null ? "--" : Number(value).toLocaleString());
const compactOrderId = (value) => {
  if (!value) return "--";

  const orderId = String(value);
  if (orderId.length <= 14) return orderId;

  return `${orderId.slice(0, 6)}...${orderId.slice(-6)}`;
};

const getUser = (row) => (row?.userId && typeof row.userId === "object" ? row.userId : row);
const getModel = (row) => row?.modelId;
const getStorage = (row) => row?.storageId;
const getAddress = (row) =>
  row?.OrderAddress || row?.orderAddress || row?.address || row?.orderAddressId || {};

const OrderDashboard = () => {
  const {
    page,
    limit,
    search,
    params,
    onPageChange,
    onPageSizeChange,
    onSearchChange,
  } = usePagination({ initialLimit: 20 });
  const { data, isLoading, isError, error } = useGetAllOrdersQuery(params);
  const { rows, totalRecords } = extractPaginatedData(data, {
    clientPage: page,
    clientLimit: limit,
    clientSearch: search,
  });
  const columnConfig = {
    orderId: {
      label: "Order ID",
      render: (value) => (
        <span title={value || "Order ID"}>{compactOrderId(value)}</span>
      ),
    },
    user: {
      label: "User",
      render: (_, row) => {
        const user = getUser(row);
        return (
          <div>
            <div>{display(user.fullName)}</div>
            <div className="text-xs text-gray-500">{display(user.email)}</div>
            <div className="text-xs text-gray-500">{display(user.phone)}</div>
          </div>
        );
      },
    },
    modelId: {
      label: "Model",
      render: (_, row) => {
        const model = getModel(row);
        if (!model || typeof model !== "object") return display(model);

        return (
          <div className="flex min-w-36 items-center gap-2 text-left">
            {model.logo ? (
              <img
                src={model.logo}
                alt={model.name || "Model"}
                className="h-10 w-10 rounded border border-gray-200 object-contain"
              />
            ) : null}
            <div>
              <div className="font-medium">{display(model.name)}</div>
              <div className="text-xs text-gray-500">
                {display(model.brandId?.name)}
                {model.deviceId?.name || model.brandId?.deviceId?.name
                  ? ` / ${model.deviceId?.name || model.brandId?.deviceId?.name}`
                  : ""}
              </div>
            </div>
          </div>
        );
      },
    },
    storageId: {
      label: "Storage",
      render: (_, row) => {
        const storage = getStorage(row);
        return display(
          typeof storage === "object"
            ? [storage.ram, storage.rom].filter(Boolean).join(" / ")
            : storage,
        );
      },
    },
    basePrice: { label: "Base Price", render: formatPrice },
    finalPrice: { label: "Final Price", render: formatPrice },
    status: { label: "Status", render: display },
    location: {
      label: "Location",
      render: (_, row) => (
        <div className="text-center whitespace-nowrap">
          <div>{display(row.city)}</div>
          <div className="text-xs text-gray-500">{display(row.state)}</div>
        </div>
      ),
    },
    address: {
      label: "Order Address",
      render: (_, row) => {
        const address = getAddress(row);
        return (
          <div>
            <div>{display(address.address1)}</div>
            <div>{display(address.address2)}</div>
            <div className="text-xs text-gray-500">
              {[address.city, address.state, address.pincode].filter(Boolean).join(", ") || "--"}
            </div>
          </div>
        );
      },
    },
    createdAt: { label: "Created At", render: formatDateTime },
  };

  if (isError) {
    return (
      <>
        <PageHeader title="Orders" />
        <div className="py-20 text-center text-sm text-red-600">
          {error?.data?.message || error?.message || "Failed to load orders"}
        </div>
      </>
    );
  }

  return (
    <div>
      <PageHeader title="Orders" />
      <Table
        data={rows}
        columnConfig={columnConfig}
        paginationMode="server"
        totalRecords={totalRecords}
        page={page}
        pageSize={limit}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
        loading={isLoading}
        searchValue={search}
        onSearch={onSearchChange}
      />
    </div>
  );
};

export default OrderDashboard;
