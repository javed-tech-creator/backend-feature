import { createApi } from "@reduxjs/toolkit/query/react";
import { axiosBaseQuery } from "./axiosBaseQuery";

export const orderApi = createApi({
  reducerPath: "orderApi",
  baseQuery: axiosBaseQuery(),
  tagTypes: ["Order"],
  endpoints: (builder) => ({
    getAllOrders: builder.query({
      query: ({ page, limit, search, ...rest } = {}) => ({
        url: "/admin/orders",
        method: "GET",
        params: {
          page,
          limit,
          search,
          ...rest,
        },
      }),
      providesTags: ["Order"],
    }),
  }),
});

export const { useGetAllOrdersQuery } = orderApi;
