import { HydratedDocument, Types } from 'mongoose';
import { AdjustmentOperation } from '../../lib/enum';
import { Device } from '../../model/device.model';
import { Question } from '../../model/question.model';
import { QuestionOption } from '../../model/question-option.model';
import { IQuestion } from '../../types/types';
import { buildMeta, toSkipTake } from '../../utils/pagination';
import { findLiveById } from '../../utils/query';
import {
  QuestionCreateDto,
  QuestionListQuery,
  QuestionReorderDto,
  QuestionUpdateDto,
} from './dto/index.dto';

const LABEL = 'Question';

type QuestionnaireOption = {
  _id: string;
  title: string;
  icon: string | null;
  operation: AdjustmentOperation | null;
};

type QuestionnaireQuestion = {
  _id: string;
  title: string;
  type: string | undefined;
  options: QuestionnaireOption[];
};

type QuestionnaireStep = {
  step: number;
  questions: QuestionnaireQuestion[];
};

export type QuestionnaireByDevice = {
  deviceId: string;
  steps: QuestionnaireStep[];
};

const mapOption = (option: {
  _id: { toString(): string };
  title: string;
  icon?: string;
  operation?: AdjustmentOperation | null;
}): QuestionnaireOption => ({
  _id: option._id.toString(),
  title: option.title,
  icon: option.icon ?? null,
  operation: option.operation ?? null,
});

const mapQuestion = (question: {
  _id: { toString(): string };
  title: string;
  type?: string;
  step?: number;
  options: Parameters<typeof mapOption>[0][];
}): QuestionnaireQuestion => ({
  _id: question._id.toString(),
  title: question.title,
  type: question.type,
  options: question.options.map(mapOption),
});

const groupQuestionsByStep = (
  questions: Array<{
    _id: { toString(): string };
    title: string;
    type?: string;
    step?: number;
    options: Parameters<typeof mapOption>[0][];
  }>,
): QuestionnaireStep[] => {
  const byStep = new Map<number, QuestionnaireQuestion[]>();

  for (const question of questions) {
    const step = question.step ?? 0;
    const mapped = mapQuestion(question);
    const existing = byStep.get(step);

    if (existing) {
      existing.push(mapped);
    } else {
      byStep.set(step, [mapped]);
    }
  }

  return [...byStep.entries()]
    .sort(([leftStep], [rightStep]) => leftStep - rightStep)
    .map(([step, stepQuestions]) => ({ step, questions: stepQuestions }));
};

/** Questions are always read with their options — the wizard needs both together. */
const withOptions = async (questions: HydratedDocument<IQuestion>[]) => {
  const options = await QuestionOption.find({
    questionId: { $in: questions.map((question) => question.id) },
    isDeleted: false,
  }).sort({ createdAt: 1 });

  return questions.map((question) => ({
    ...question.toJSON(),
    options: options.filter((option) => option.questionId.equals(question.id)),
  }));
};

export class QuestionService {
  static async create({ deviceId, title, type, step, sortOrder, isActive }: QuestionCreateDto) {
    await findLiveById(Device, deviceId, 'Device');

    return Question.create({ deviceId, title, type, step, sortOrder, isActive });
  }

  static async list(query: QuestionListQuery) {
    const { skip, take } = toSkipTake(query);
    const filter = {
      isDeleted: false,
      ...(query.deviceId ? { deviceId: query.deviceId } : {}),
      ...(query.type ? { type: query.type } : {}),
      // A missing flag counts as active, so "enabled" must not be a plain equality.
      ...(query.isActive === undefined
        ? {}
        : { isActive: query.isActive ? { $ne: false } : false }),
      ...(query.search ? { title: { $regex: query.search, $options: 'i' } } : {}),
    };

    const [questions, total] = await Promise.all([
      Question.find(filter)
        .populate({ path: 'deviceId', select: '_id name slug' })
        .sort({ [query.sortBy]: query.order === 'asc' ? 1 : -1 })
        .skip(skip)
        .limit(take),
      Question.countDocuments(filter),
    ]);

    return { questions: await withOptions(questions), meta: buildMeta(query, total) };
  }

  /** The questionnaire the calculator runs: live, enabled, in the order the admin set. */
  static async activeForDevice(deviceId: string) {
    await findLiveById(Device, deviceId, 'Device');

    const questions = await Question.find({
      deviceId,
      isDeleted: false,
      // Questions written before `isActive` existed have no such field, and a
      // missing flag means "not disabled" — `isActive: true` would skip them all.
      isActive: { $ne: false },
    }).sort({ step: 1, sortOrder: 1, createdAt: 1 });

    return withOptions(questions);
  }

  /** Step-grouped questionnaire for the storefront wizard — no pricing logic here. */
  static async questionnaireByDevice(deviceId: string): Promise<QuestionnaireByDevice> {
    const questions = await this.activeForDevice(deviceId);

    return {
      deviceId,
      steps: groupQuestionsByStep(questions),
    };
  }

  static async getById(id: string) {
    const question = await findLiveById(Question, id, LABEL);
    await question.populate({ path: 'deviceId', select: '_id name slug' });
    const [withItsOptions] = await withOptions([question]);

    return withItsOptions;
  }

  static async update(
    id: string,
    { deviceId, title, type, step, sortOrder, isActive }: QuestionUpdateDto,
  ) {
    const question = await findLiveById(Question, id, LABEL);

    // Moving a question to another device carries its options along with it.
    if (deviceId) {
      await findLiveById(Device, deviceId, 'Device');
      question.deviceId = new Types.ObjectId(deviceId);
    }

    question.title = title ?? question.title;
    question.type = type ?? question.type;
    question.step = step ?? question.step;
    question.sortOrder = sortOrder ?? question.sortOrder;
    question.isActive = isActive ?? question.isActive;

    return question.save();
  }

  static async reorder({ items }: QuestionReorderDto) {
    await Question.bulkWrite(
      items.map(({ id, sortOrder, step }) => ({
        updateOne: {
          filter: { _id: id, isDeleted: false },
          update: { $set: { sortOrder, ...(step === undefined ? {} : { step }) } },
        },
      })),
    );
  }

  static async remove(id: string) {
    const question = await findLiveById(Question, id, LABEL);
    question.isDeleted = true;
    await question.save();
    // Options only exist inside their question, so they go with it.
    await QuestionOption.updateMany({ questionId: id }, { isDeleted: true });
  }
}
