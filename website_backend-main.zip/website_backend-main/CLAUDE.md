# phonecash Backend

REST API for the phonecash platform (Swiss contract reading & payslip generation).
Stack: Node.js + Express 5 (TypeScript), MongoDB + TypeORM, Winston logging, zod validation, Husky + commitlint (conventional commits).

## Commands

- `npm run dev` — watch mode: rebuild + run `./dist/server.js` on every change
- `npm start` — build then run `./dist/server.js`; `npm run start:prod` — run `./dist` only
- `npm run lint` / `npm run typecheck` / `npm run build`
- The app ALWAYS runs from compiled `./dist` output — never run TS sources directly.

## Structure

- Module-per-feature: `src/modules/<name>/` with exactly four files — `<name>.route.ts`, `<name>.controller.ts`, `<name>.service.ts`, `<name>.dto.ts` (zod schemas). Mount new routers in `src/routes.ts`.
- Entities live in `src/entities/` (TypeORM, roles: employee / company / fiduciary / super_admin).
- Cross-cutting middleware in `src/middlewares/`, winston logger and `ApiError` in `src/utils/`.
- Env vars are validated with zod in `src/config/env.ts` — add new vars to the schema and `.env.example`, never read `process.env` elsewhere.
- List endpoints are paginated: extend `paginationQuerySchema` (`src/utils/pagination.ts`) in the module DTO with a `sortBy` enum, parse it in the controller, and respond via `ResponseHandler.paginated`, which emits `{ success, message, data: { data, page, limit, total, totalPages } }` (see the users module). Optional `search` fields must use `searchSchema` from `src/utils/pagination.ts` so an empty `?search=` means "no filter" instead of a 400.
- Body/params validation via `validate()` middleware; query schemas are parsed in the controller. ZodErrors become localized 400s in the global error handler.
- Role guards: `authorize(minRole)` from `src/middlewares/authorize.ts` is hierarchical — employee -> company -> fiduciary -> super_admin; the given role and everything above it pass (requires `req.user` from a future auth middleware). Rate limiting: `apiLimiter` covers the whole API; use `strictLimiter` for sensitive routes.

## i18n (it, en)

- Locale files: `src/i18n/locales/en.json` and `it.json`. Request locale is resolved by `localeMiddleware` (`?lang` → `X-Locale` header → `Accept-Language`) onto `req.locale`.
- **Locale JSON structure rule: only `success` and `error` are objects; every other key lives flat at the base level. No other nesting.**
- Error messages: throw `ApiError` with a translation key (e.g. `error.userNotFound`) — the error handler translates it. Success messages: `t(req.locale, 'success.xxx')` in controllers.
- Keep `en.json` and `it.json` key-for-key identical.

## Code generation rules

- Before generating any code, read this CLAUDE.md first and follow it.
- Generated code must be very simple and easy to read — no clever abstractions where plain code works.
- Follow all existing conventions of this repo (module layout, naming, error/i18n patterns above).
- Use as few comments as possible; only where the code cannot express a constraint itself.
- Never duplicate code or logic — reuse the existing helpers, middlewares, services and utils instead of re-creating them.
