import http from 'http';
import { createApp } from './app';
import { AppDataSource, connectDatabase, disconnectDatabase } from './config/data-source';
import { env } from './config/env';
import { logger } from './utils/logger';

const start = async (): Promise<void> => {
  try {
    await connectDatabase();
    console.log(`Database connected (${env.db.uri}/${env.db.name})`);
  } catch (error) {
    logger.error('Failed to connect to the database', { error });
    process.exit(1);
  }

  const app = createApp();
  const server = http.createServer(app);

  server.listen(env.port, () => {
    console.log(`phonecash API listening on http://localhost:${env.port}${env.apiPrefix}`);
  });

  const shutdown = (signal: string): void => {
    logger.info(`${signal} received — shutting down gracefully`);
    server.close(async () => {
      if (AppDataSource.connection.readyState === 1) {
        await disconnectDatabase();
        logger.info('Database connection closed');
      }
      process.exit(0);
    });
    // Force-exit if graceful shutdown hangs
    setTimeout(() => process.exit(1), 10_000).unref();
  };

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
};

void start();
