import type { Types } from 'mongoose';
import { AdjustmentOperation, AdjustmentType, OrderStatus, OrderType, QuestionType, UserRole } from '../lib/enum';

export interface IBaseDocument {
  id: Types.ObjectId;
  createdAt: Date;
  updatedAt: Date;
  isDeleted?: boolean | false;
}
export interface IBrand extends IBaseDocument {
  deviceId: Types.ObjectId;
  name: string;
  slug?: string;
  logo?: string;
  logoPublicId?: string;
}
export interface IDevice extends IBaseDocument {
  name: string;
  slug?: string;
  logo?: string;
  logoPublicId?: string;
}
export interface IOrder extends IBaseDocument {
  userId: Types.ObjectId;
  modelId: Types.ObjectId;
  storageId: Types.ObjectId;
  basePrice?: number;
  finalPrice?: number;
  status: OrderStatus;
  orderType?: OrderType;
}
export interface IModel extends IBaseDocument {
  brandId: Types.ObjectId;
  name: string;
  slug?: string;
  logo?: string;
  logoPublicId?: string;
}
export interface IModelStorage extends IBaseDocument {
  modelId: Types.ObjectId;
  storageId: Types.ObjectId;
  basePrice: number;
}
export interface IQuestionOption extends IBaseDocument {
  title: string;
  icon?: string;
  /** Read together with `adjustmentType`: 15 means "15%" or "15 currency units". */
  value?: number | null;
  adjustmentType: AdjustmentType;
  operation: AdjustmentOperation | null;
  questionId: Types.ObjectId;
}
export interface IQuestion extends IBaseDocument {
  deviceId: Types.ObjectId;
  title: string;
  type?: QuestionType;
  step?: number;
  /** Position inside its step — drives the order the calculator asks them in. */
  sortOrder: number;
  /** A disabled question is kept but skipped by the calculator. */
  isActive: boolean;
}
export interface IStorage extends IBaseDocument {
  ram?: string;
  rom: string;
  slug: string;
}
export interface IBlog extends IBaseDocument {
  title: string;
  slug?: string;
  description: string;
  image?: {
    url?: string;
    publicId?: string;
  };
  category: string;
  tags?: string[];
}
export interface IUserAnswer extends IBaseDocument {
  orderId: Types.ObjectId;
  selectedOptionId: Types.ObjectId;
  questionId: Types.ObjectId;
}
export interface IUserDetail extends IBaseDocument {
  userId: Types.ObjectId;
  address1?: string;
  address2?: string;
  city?: string;
  state?: string;
  pinCode?: string;
}
export interface IUser extends IBaseDocument {
  email?: string;
  phone: string;
  password?: string;
  fullName?: string;
  role: UserRole;
  otp?: string | null;
  otpExpiresAt?: Date | null;
  otpAttempts: number;
  isVerified: boolean;
}
export interface UploadedImage {
  url: string;
  publicId: string;
}

export type DeviceBrandParams = {
  deviceSlug: string;
  brandSlug: string;
};