import { UserRole } from '../lib/enum';

declare global {
  namespace Express {
    interface Request {
      /** Authenticated user (set by the authentication middleware). */
      user?: {
        id: string;
        role: UserRole;
        uid?: string;
        phoneNumber?: string;
      };
    }
  }
}

export {};
