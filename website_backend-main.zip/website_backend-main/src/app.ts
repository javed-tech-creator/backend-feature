import compression from 'compression';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import express, { Application } from 'express';
import helmet from 'helmet';
import morgan from 'morgan';
import { env } from './config/env';
import { errorHandler } from './middlewares/error-handler';
import { notFoundHandler } from './middlewares/not-found';
import { apiLimiter } from './middlewares/rate-limit';
import routes from './routes';
import { httpLogStream } from './utils/logger';

export const createApp = (): Application => {
  const app = express();

  // Security & parsing
  app.use(helmet());
  app.use(
    cors({
      origin: env.corsOrigins,
      credentials: true,
    }),
  );
  app.use(compression());
  app.use(cookieParser());
  app.use(express.json({ limit: env.bodyLimit }));
  app.use(express.urlencoded({ extended: true, limit: env.bodyLimit }));

  // HTTP access logs -> winston
  app.use(morgan(env.isProduction ? 'combined' : 'dev', { stream: httpLogStream }));

  // API routes (rate-limited per IP)
  app.use(env.apiPrefix, apiLimiter, routes);

  // 404 + error handling (keep last)
  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
};
