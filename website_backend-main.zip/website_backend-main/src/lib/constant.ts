export const AUTH_COOKIE_Admin = 'phone-admin-token';
export const AUTH_COOKIE_User = 'phone-user-token';
export const PASSWORD_SALT_ROUNDS = 10;
export const OTP_SALT_ROUNDS = 10;
