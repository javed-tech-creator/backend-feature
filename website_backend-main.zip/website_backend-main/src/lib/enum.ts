export enum UserRole {
  CUSTOMER = 'customer',
  ADMIN = 'admin',
}

/** How an option's adjustment is applied to the base price. */
export enum AdjustmentType {
  PERCENTAGE = 'percentage',
  FIXED = 'fixed',
  NONE = 'none',
  REJECT = 'reject',
}

export enum AdjustmentOperation {
  INCREASE = 'increase',
  DECREASE = 'decrease',
}

export enum QuestionType {
  CHECKBOX = 'checkbox',
  BOOLEAN = 'boolean',
  INPUT = 'input',
  RADIO = 'radio',
}

export enum OrderStatus {
  REQUESTED = 'requested',
  ACCEPTED = 'accepted',
  REJECTED = 'rejected',
  COMPLETED = 'completed',
  CANCELLED = 'cancelled',
}

export enum OrderType {
  BUY = 'buy',
  SELL = 'sell',
}
