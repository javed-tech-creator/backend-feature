import { Model } from '../model/model.model';
import { ModelStorage } from '../model/model-storage.model';
import { logger } from '../utils/logger';

interface LegacyModel {
  _id: object;
  storageId?: object;
  basePrice?: number;
}

/**
 * Models used to carry a single `storageId` + `basePrice`; both now live on the
 * ModelStorage join. This copies the old pair over so existing models stay
 * orderable. Re-running it is safe — a model that already has rows is skipped.
 */
export const seedModelStorages = async (): Promise<void> => {
  // The legacy fields were dropped from the schema, so they can only be read raw.
  const legacyModels = (await Model.collection
    .find({ storageId: { $exists: true } })
    .toArray()) as unknown as LegacyModel[];

  let migrated = 0;

  for (const legacy of legacyModels) {
    if (!legacy.storageId) {
      continue;
    }

    const existing = await ModelStorage.countDocuments({ modelId: legacy._id });

    if (existing > 0) {
      continue;
    }

    await ModelStorage.create({
      modelId: legacy._id,
      storageId: legacy.storageId,
      basePrice: legacy.basePrice ?? 0,
    });

    migrated += 1;
  }

  logger.info(`Model storages backfilled: ${migrated}`);
};
