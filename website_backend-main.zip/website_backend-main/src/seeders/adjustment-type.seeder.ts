import { AdjustmentType } from '../lib/enum';
import { QuestionOption } from '../model/question-option.model';
import { logger } from '../utils/logger';

/**
 * values used to be stored as a fraction (the admin typed 10, the UI saved
 * 0.1) with no type. They are now a plain value plus a `AdjustmentType`, so 10%
 * is stored as 10. Old rows are the ones with no `AdjustmentType` — setting it
 * as part of the same update makes re-running this a no-op instead of scaling
 * every value by 100 a second time.
 */
export const seedAdjustmentType = async (): Promise<void> => {
  const legacy = await QuestionOption.collection
    .find({ adjustmentType: { $exists: false } })
    .toArray();

  if (legacy.length === 0) {
    return;
  }

  for (const option of legacy) {
    const fraction = typeof option.value === 'number' ? option.value : 0;

    await QuestionOption.collection.updateOne(
      { _id: option._id },
      {
        $set: {
          value: Math.round(fraction * 100 * 100) / 100,
          adjustmentType: AdjustmentType.PERCENTAGE,
        },
      },
    );
  }

  logger.info(`Question options migrated to percentage values: ${legacy.length}`);
};
