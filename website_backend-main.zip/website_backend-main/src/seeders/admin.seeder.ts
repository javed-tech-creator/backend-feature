import { env } from '../config/env';
import { UserRole } from '../lib/enum';
import { User } from '../model/user.model';
import { AdminService } from '../modules/admin/admin.service';
import { adminSignupSchema } from '../modules/admin/dto/index.dto';
import { logger } from '../utils/logger';

export const seedAdmin = async (): Promise<void> => {
  const parsed = adminSignupSchema.safeParse(env.seedAdmin);

  if (!parsed.success) {
    const details = parsed.error.issues
      .map((issue) => `  SEED_ADMIN_${issue.path.join('.')}: ${issue.message}`)
      .join('\n');
    throw new Error(`Invalid admin seed environment variables:\n${details}`);
  }

  const admin = parsed.data;

  const existing = await User.findOne({
    phone: admin.phone,
    role: UserRole.ADMIN,
    isDeleted: false,
  });

  if (existing) {
    logger.info(`Admin already seeded (${admin.phone}) — skipping`);
    return;
  }

  await AdminService.signup(admin);
  logger.info(`Admin seeded (${admin.phone})`);
};
