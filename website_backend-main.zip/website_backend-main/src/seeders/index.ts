import { connectDatabase, disconnectDatabase } from '../config/data-source';
import { logger } from '../utils/logger';
import { seedAdmin } from './admin.seeder';
import { seedAdjustmentType } from './adjustment-type.seeder';
import { seedModelStorages } from './model-storage.seeder';
import { seedQuestionDevices } from './question-device.seeder';
import { seedQuestionOrder } from './question-order.seeder';

const run = async (): Promise<void> => {
  await connectDatabase();

  try {
    await seedAdmin();
    await seedModelStorages();
    await seedQuestionDevices();
    await seedAdjustmentType();
    await seedQuestionOrder();
  } finally {
    await disconnectDatabase();
  }
};

run().catch((error: Error) => {
  logger.error(`Seeding failed: ${error.message}`, { stack: error.stack });
  process.exit(1);
});
