import { Question } from '../model/question.model';
import { logger } from '../utils/logger';

/**
 * `isActive` and `sortOrder` were added after these questions were written, and
 * a schema default only applies to new documents — so existing rows have
 * neither. Backfills both, numbering each device/step group by creation order
 * so drag-to-reorder starts from a sane sequence. Re-running is a no-op.
 */
export const seedQuestionOrder = async (): Promise<void> => {
  const pending = await Question.collection
    .find({ $or: [{ isActive: { $exists: false } }, { sortOrder: { $exists: false } }] })
    .sort({ createdAt: 1 })
    .toArray();

  if (pending.length === 0) {
    return;
  }

  // Position is per device + step — that is the list the admin drags within.
  const seen = new Map<string, number>();

  for (const question of pending) {
    const key = `${String(question.deviceId)}:${question.step ?? 0}`;
    const position = seen.get(key) ?? 0;
    seen.set(key, position + 1);

    await Question.collection.updateOne(
      { _id: question._id },
      {
        $set: {
          isActive: question.isActive ?? true,
          sortOrder: question.sortOrder ?? position,
        },
      },
    );
  }

  logger.info(`Questions backfilled with order and active flag: ${pending.length}`);
};
