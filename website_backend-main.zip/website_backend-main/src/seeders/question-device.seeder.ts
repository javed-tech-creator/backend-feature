import { Device } from '../model/device.model';
import { Question } from '../model/question.model';
import { logger } from '../utils/logger';

/**
 * Questions used to be global; they now belong to a device. Existing questions
 * carry no `deviceId`, which would make them unreachable, so they are parked on
 * the oldest device — the admin can move them from there. Re-running is safe.
 */
export const seedQuestionDevices = async (): Promise<void> => {
  const orphans = await Question.collection.countDocuments({ deviceId: { $exists: false } });

  if (orphans === 0) {
    return;
  }

  const fallbackDevice = await Device.findOne({ isDeleted: false }).sort({ createdAt: 1 });

  if (!fallbackDevice) {
    logger.warn(`${orphans} question(s) have no device and no device exists to park them on`);
    return;
  }

  await Question.collection.updateMany(
    { deviceId: { $exists: false } },
    { $set: { deviceId: fallbackDevice._id } },
  );

  logger.info(`Questions assigned to device "${fallbackDevice.name}": ${orphans}`);
};
