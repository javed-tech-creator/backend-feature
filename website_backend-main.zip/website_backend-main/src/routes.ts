import { Router } from 'express';
import adminRouter from './modules/admin/admin.router';
import blogRouter from './modules/blog/blog.router';
import brandRouter from './modules/brand/brand.router';
import calculatorRouter from './modules/calculator/calculator.router';
import deviceRouter from './modules/device/device.router';
import modelRouter from './modules/model/model.router';
import modelStorageRouter from './modules/model-storage/model-storage.router';
import orderRouter from './modules/order/order.router';
import questionRouter from './modules/question/question.router';
import questionOptionRouter from './modules/question-option/question-option.router';
import storageRouter from './modules/storage/storage.router';
import userRouter from './modules/user/user.router';

const router = Router();

router.use('/admin', adminRouter);
router.use('/user', userRouter);
router.use('/device', deviceRouter);
router.use('/brand', brandRouter);
router.use('/storage', storageRouter);
router.use('/model', modelRouter);
router.use('/model-storages', modelStorageRouter);
router.use('/calculator', calculatorRouter);
router.use('/question', questionRouter);
router.use('/question-option', questionOptionRouter);
router.use('/order', orderRouter);
router.use('/blog', blogRouter);

export default router;
