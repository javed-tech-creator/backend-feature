import { Request, Response } from 'express';
import { ResponseHandler } from '../helper/response.handler';

export const notFoundHandler = (req: Request, res: Response): void => {
  ResponseHandler.error(res, `Route not found: ${req.method} ${req.originalUrl}`, 404);
};
