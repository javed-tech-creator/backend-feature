import { NextFunction, Request, Response } from 'express';
import { ApiError } from '../utils/api-error';
import { UserRole } from '../lib/enum';

const roleRank: Record<UserRole, number> = {
  [UserRole.CUSTOMER]: 0,
  [UserRole.ADMIN]: 1,
};

/**
 * Restricts a route to the given role or any role above it in the hierarchy
 * customer -> admin.
 * Expects `req.user` to be set by an authentication middleware.
 * Usage: router.get('/', authorize(UserRole.ADMIN), handler)
 *        // admin passes; customer gets 403
 */
export const authorize =
  (minRole: UserRole) =>
  (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.user) {
      next(ApiError.unauthorized());
      return;
    }

    const userRoleRank = roleRank[req.user.role as UserRole] ?? -1;
    const requiredRoleRank = roleRank[minRole];

    if (userRoleRank < requiredRoleRank) {
      next(ApiError.forbidden());
      return;
    }

    next();
  };
