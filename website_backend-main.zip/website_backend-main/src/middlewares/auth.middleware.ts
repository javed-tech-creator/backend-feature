// import { NextFunction, Request, Response } from 'express';
// import { firebaseAdminAuth } from '../config/firebase';
// import { UserRole } from '../lib/enum';
// import { ApiError } from '../utils/api-error';

// export type AuthRequest = Request;

// export const authenticate = async (
//   req: AuthRequest,
//   _res: Response,
//   next: NextFunction,
// ): Promise<void> => {
//   try {
//     const authHeader = req.headers.authorization;

//     if (!authHeader) {
//       next(ApiError.unauthorized('Authorization header is required.'));
//       return;
//     }

//     if (!authHeader.startsWith('Bearer ')) {
//       next(ApiError.unauthorized('Invalid authorization format.'));
//       return;
//     }

//     const token = authHeader.slice(7).trim();

//     if (!token) {
//       next(ApiError.unauthorized('Authentication token is missing.'));
//       return;
//     }

//     const decodedToken = await firebaseAdminAuth.verifyIdToken(token);

//     req.user = {
//       id: decodedToken.uid,
//       role: UserRole.CUSTOMER,
//       uid: decodedToken.uid,
//       phoneNumber: decodedToken.phone_number ?? undefined,
//     };

//     next();
//   } catch {
//     next(ApiError.unauthorized('Invalid or expired authentication token.'));
//   }
// };
