import { Request, Response } from 'express';
import rateLimit from 'express-rate-limit';
import { env } from '../config/env';
import { ResponseHandler } from '../helper/response.handler';

const handler = (req: Request, res: Response): void => {
  ResponseHandler.error(res, 'Too many requests', 429, {
    context: { path: req.path, method: req.method },
  });
};

/** Applied to the whole API. */
export const apiLimiter = rateLimit({
  windowMs: env.rateLimit.windowMs,
  limit: env.rateLimit.max,
  standardHeaders: true,
  legacyHeaders: false,
  handler,
});

/** Stricter limiter for sensitive routes (login, password reset, …). */
export const strictLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  handler,
});
