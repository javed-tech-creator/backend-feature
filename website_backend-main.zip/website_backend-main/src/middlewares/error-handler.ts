import { NextFunction, Request, Response } from 'express';
import { ZodError } from 'zod';
import { env } from '../config/env';
import { ResponseHandler } from '../helper/response.handler';
import { ApiError } from '../utils/api-error';

export const errorHandler = (
  err: Error,
  req: Request,
  res: Response,
  _next: NextFunction,
): void => {
  const context = { path: req.path, method: req.method };

  if (err instanceof ZodError) {
    ResponseHandler.error(res, 'Validation failed', 400, {
      context,
      details: err.issues.map((issue) => ({
        path: issue.path.join('.'),
        message: issue.message,
      })),
    });
    return;
  }

  const isApiError = err instanceof ApiError;
  const statusCode = isApiError ? err.statusCode : 500;
  const message = statusCode === 500 && env.isProduction ? 'Internal server error' : err.message;

  ResponseHandler.error(res, message, statusCode, {
    error: err,
    context,
    ...(isApiError && err.details ? { details: err.details } : {}),
  });
};
