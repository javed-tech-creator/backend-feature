import path from 'path';
import multer from 'multer';
import { env } from '../config/env';
import { ApiError } from '../utils/api-error';

const allowedExtensions = ['.csv', '.xls', '.xlsx'];
const allowedMimeTypes = [
  'text/csv',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
];

export const uploadFile = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: env.upload.maxFileSize, files: 1 },
  fileFilter: (_req, file, callback) => {
    const extension = path.extname(file.originalname).toLowerCase();
    const isAllowed = allowedMimeTypes.includes(file.mimetype) || allowedExtensions.includes(extension);

    if (!isAllowed) {
      callback(ApiError.badRequest('Only CSV and Excel files are allowed'));
      return;
    }

    callback(null, true);
  },
});
