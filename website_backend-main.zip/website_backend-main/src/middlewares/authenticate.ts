import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { AUTH_COOKIE_Admin, AUTH_COOKIE_User } from '../lib/constant';
import { UserRole } from '../lib/enum';
import { ApiError } from '../utils/api-error';

/**
 * Reads the JWT from the `Authorization: Bearer <token>` header or either auth cookie
 * and sets `req.user`. Pair with `authorize(role)` to guard a route.
 */
export const authenticate = (req: Request, _res: Response, next: NextFunction): void => {
  const header = req.headers.authorization;
  // `||` not `??`: an empty cookie must fall through instead of shadowing the next one.
  const token = header?.startsWith('Bearer ')
    ? header.slice(7)
    : req.cookies?.[AUTH_COOKIE_Admin] || req.cookies?.[AUTH_COOKIE_User];

  if (!token) {
    next(ApiError.unauthorized());
    return;
  }

  try {
    const payload = jwt.verify(token, env.jwt.secret) as {
      id: string;
      role: UserRole;
    };
    req.user = { id: payload.id, role: payload.role };
    next();
  } catch {
    next(ApiError.unauthorized('Invalid or expired token'));
  }
};
