import { FilterQuery, HydratedDocument, Model } from 'mongoose';
import { ApiError } from './api-error';

/** Soft-deleted records are invisible to the API — always look them up through this. */
export const findLiveById = async <T>(
  model: Model<T>,
  id: string,
  label: string,
): Promise<HydratedDocument<T>> => {
  const document = await model.findOne({ _id: id, isDeleted: false } as FilterQuery<T>);

  if (!document) {
    throw ApiError.notFound(`${label} not found`);
  }

  return document;
};

/** Same live-record rule as `findLiveById`, keyed by slug for storefront lookups. */
export const findLiveBySlug = async <T>(
  model: Model<T>,
  slug: string,
  label: string,
  extra: FilterQuery<T> = {},
): Promise<HydratedDocument<T>> => {
  const document = await model.findOne({ slug, isDeleted: false, ...extra } as FilterQuery<T>);

  if (!document) {
    throw ApiError.notFound(`${label} not found`);
  }

  return document;
};
