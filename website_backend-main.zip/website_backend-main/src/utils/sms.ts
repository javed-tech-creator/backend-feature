import { logger } from './logger';

/**
 * Only place that talks to the SMS provider — swap the body for Twilio/MSG91/etc.
 * Until then the message is written to the logs so the flow stays testable.
 */
export const sendSms = async (phone: string, message: string): Promise<void> => {
  logger.info(`SMS to ${phone}: ${message}`);
};
