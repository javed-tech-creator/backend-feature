import { z } from 'zod';

export const paginationQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(100),
  order: z.enum(['asc', 'desc']).default('desc'),
});

export type PaginationQuery = z.infer<typeof paginationQuerySchema>;

/** An empty `?search=` means "no filter", so it must collapse to undefined instead of failing. */
export const searchSchema = z
  .string()
  .trim()
  .optional()
  .transform((value) => value || undefined);

/** Case-insensitive `$or` regex filter, or nothing when there is no search term. */
export const buildSearchFilter = (search: string | undefined, fields: string[]) =>
  search ? { $or: fields.map((field) => ({ [field]: { $regex: search, $options: 'i' } })) } : {};

export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export const toSkipTake = (query: PaginationQuery): { skip: number; take: number } => ({
  skip: (query.page - 1) * query.limit,
  take: query.limit,
});

export const buildMeta = (query: PaginationQuery, total: number): PaginationMeta => ({
  page: query.page,
  limit: query.limit,
  total,
  totalPages: Math.max(Math.ceil(total / query.limit), 1),
});

export const cursorPaginationQuerySchema = z.object({
  limit: z.coerce.number().int().min(1).max(100).default(20),
  cursor: z
    .string()
    .trim()
    .optional()
    .transform((value) => value || undefined)
    .refine((value) => !value || /^[a-f\d]{24}$/i.test(value), 'Invalid cursor'),
});

export const modelSearchQuerySchema = cursorPaginationQuerySchema.extend({
  q: z.string().trim().min(2, 'Search query must be at least 2 characters'),
});
export type ModelSearchQuery = z.infer<typeof modelSearchQuerySchema>;
export type CursorPaginationQuery = z.infer<typeof cursorPaginationQuerySchema>;

export interface CursorPaginationMeta {
  nextCursor: string | null;
  hasMore: boolean;
  limit: number;
}

export const toCursorFilter = (
  cursor?: string,
): { _id: { $gt: string } } | Record<string, never> => (cursor ? { _id: { $gt: cursor } } : {});

export const paginateCursor = <T extends { _id: { toString(): string } }>(
  items: T[],
  limit: number,
): { data: T[] } & CursorPaginationMeta => {
  const hasMore = items.length > limit;
  const data = hasMore ? items.slice(0, limit) : items;
  const last = data[data.length - 1];

  return {
    data,
    nextCursor: hasMore && last ? last._id.toString() : null,
    hasMore,
    limit,
  };
};
