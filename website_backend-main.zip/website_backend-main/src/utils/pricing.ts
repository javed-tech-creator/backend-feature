import { AdjustmentOperation, AdjustmentType } from '../lib/enum';

export interface PricedAnswer {
  /** Labels for the breakdown the calculator returns; orders price without them. */
  question?: string;
  option?: string;
  type: AdjustmentType;
  /** Whether the amount is added to or subtracted from the base price. */
  operation: AdjustmentOperation | null;
  value: number;
}

export interface AdjustmentLine extends PricedAnswer {
  /** What `value` works out to in currency against this base price. */
  amount: number;
}

export interface PriceBreakdown {
  basePrice: number;
  adjustments: AdjustmentLine[];
  totalIncrease: number;
  totalDecrease: number;
  finalOffer: number;
}

/** Percentages are taken off the base price, never off the running total, so the
 * order the questions are answered in cannot change the final offer. */
const toAmount = (basePrice: number, { type, value }: PricedAnswer): number => {
  // NONE never moves the price; REJECT is handled by the caller.
  if (type === AdjustmentType.NONE || type === AdjustmentType.REJECT) {
    return 0;
  }

  const amount = type === AdjustmentType.PERCENTAGE ? (basePrice * value) / 100 : value;

  return Math.round(amount);
};

/** The single place a final offer is worked out — used by the calculator and by orders. */
export const buildPriceBreakdown = (
  basePrice: number,
  answers: PricedAnswer[],
): PriceBreakdown => {
  const adjustments = answers.map((answer) => ({
    ...answer,
    amount: toAmount(basePrice, answer),
  }));

  // Split the net change by direction so the caller can show them separately.
  const { totalIncrease, totalDecrease } = adjustments.reduce(
    (totals, line) => {
      if (line.type === AdjustmentType.NONE) return totals;

      if (line.operation === AdjustmentOperation.INCREASE) {
        totals.totalIncrease += line.amount;
      } else if (line.operation === AdjustmentOperation.DECREASE) {
        totals.totalDecrease += line.amount;
      }

      return totals;
    },
    { totalIncrease: 0, totalDecrease: 0 },
  );

  // A REJECT option (e.g. "phone won't turn on") disqualifies the device outright.
  const finalOffer = answers.some((answer) => answer.type === AdjustmentType.REJECT)
    ? 0
    : Math.max(basePrice + totalIncrease - totalDecrease, 0);

  return {
    basePrice,
    adjustments,
    totalIncrease,
    totalDecrease,
    finalOffer,
  };
};