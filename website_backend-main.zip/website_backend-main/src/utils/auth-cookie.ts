import { Response } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';

/** Sends the JWT as an httpOnly cookie that expires with the token itself. */
export const setAuthCookie = (res: Response, token: string, name: string): void => {
  const { exp } = jwt.decode(token) as { exp: number };

  res.cookie(name, token, {
    httpOnly: true,
    secure: env.isProduction,
    // Cross-site cookies require SameSite=None, which browsers only accept over HTTPS.
    sameSite: env.isProduction ? 'none' : 'lax',
    expires: new Date(exp * 1000),
    path: '/',
  });
};

export const clearAuthCookie = (res: Response, name: string): void => {
  res.clearCookie(name, {
    httpOnly: true,
    secure: env.isProduction,
    sameSite: env.isProduction ? "none" : "lax",
    path: "/",
  });
};