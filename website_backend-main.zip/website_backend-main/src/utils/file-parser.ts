import XLSX from 'xlsx';
import { ApiError } from './api-error';

export interface ParsedModelUploadRow {
  modelName: string;
  storage: string;
  price: number;
}

const normalizeHeader = (value: unknown): string =>
  String(value ?? '').trim().toLowerCase();

const findHeaderIndex = (headers: string[], candidates: string[]): number =>
  headers.findIndex((header) => candidates.includes(header));

const parsePriceValue = (value: unknown, rowIndex: number): number => {
  const raw = String(value ?? '').trim();
  if (raw === '') {
    throw ApiError.badRequest(`Price is required for row ${rowIndex + 2}`);
  }

  const normalized = raw.replace(/[^0-9.-]/g, '');
  const parsed = Number(normalized);

  if (!Number.isFinite(parsed) || parsed < 0) {
    throw ApiError.badRequest(`Invalid price value for row ${rowIndex + 2}`);
  }

  return parsed;
};

export const parseModelUploadFile = (file: Express.Multer.File): ParsedModelUploadRow[] => {
  if (!file || !file.buffer || file.buffer.length === 0) {
    throw ApiError.badRequest('Uploaded file is empty');
  }

  const workbook = XLSX.read(file.buffer, { type: 'buffer' });
  if (!workbook.SheetNames.length) {
    throw ApiError.badRequest('Uploaded file does not contain any sheets');
  }

  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const rawRows = XLSX.utils.sheet_to_json<(string | number | null)[]>(sheet, {
    header: 1,
    defval: null,
    blankrows: false,
  });

  if (!Array.isArray(rawRows) || rawRows.length < 2) {
    throw ApiError.badRequest('Uploaded file must contain a header row and at least one data row');
  }

  const headers = rawRows[0].map(normalizeHeader);
  const modelNameIndex = findHeaderIndex(headers, ['model name', 'model', 'name']);
  const storageIndex = findHeaderIndex(headers, ['storage', 'storage option', 'ram/rom', 'ram rom']);
  const priceIndex = findHeaderIndex(headers, ['price', 'cost', 'amount']);

  if (modelNameIndex === -1 || storageIndex === -1 || priceIndex === -1) {
    throw ApiError.badRequest(
      'Uploaded file must include headers: Model Name, Storage, and Price',
    );
  }

  return rawRows.slice(1).map((row, rowIndex) => {
    const modelName = String(row[modelNameIndex] ?? '').trim();
    const storage = String(row[storageIndex] ?? '').trim();

    if (!modelName) {
      throw ApiError.badRequest(`Model Name is required for row ${rowIndex + 2}`);
    }

    if (!storage) {
      throw ApiError.badRequest(`Storage is required for row ${rowIndex + 2}`);
    }

    return {
      modelName,
      storage,
      price: parsePriceValue(row[priceIndex], rowIndex),
    };
  });
};
