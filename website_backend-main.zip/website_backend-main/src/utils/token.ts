import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { UserRole } from '../lib/enum';
import { IUser } from '../types/types';

export const signToken = (id: string, role: UserRole): string =>
  jwt.sign({ id, role }, env.jwt.secret, {
    expiresIn: env.jwt.expiresIn,
  } as jwt.SignOptions);

/** The user shape every auth endpoint returns — never includes password or otp. */
export const toUserResponse = (user: IUser) => ({
  id: user.id,
  email: user.email,
  phone: user.phone,
  fullName: user.fullName,
  role: user.role,
});
