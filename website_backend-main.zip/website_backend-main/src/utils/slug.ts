import { FilterQuery, Model } from 'mongoose';
import { z } from 'zod';
import { ApiError } from './api-error';

export const slugSchema = z.string().trim().min(1, 'Slug is required');

export const deviceSlugParamSchema = z.object({ slug: slugSchema });
export const brandSlugParamSchema = z.object({ deviceSlug: slugSchema, brandSlug: slugSchema });
export const modelSlugParamSchema = z.object({ slug: slugSchema });

/** "Apple iPhone 15!" -> "apple-iphone-15"; accents are normalised away ("Café" -> "cafe"). */
export const toSlug = (value: string): string =>
  value
    .normalize('NFKD')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

/**
 * Slugs identify a record in URLs, so they must stay unique among live records.
 * `scope` narrows that uniqueness (e.g. brands are unique per device).
 */
export const buildUniqueSlug = async <T>(
  model: Model<T>,
  name: string,
  label: string,
  scope: FilterQuery<T> = {},
  excludeId?: string,
): Promise<string> => {
  const slug = toSlug(name);
  const clash = await model.findOne({
    ...scope,
    slug,
    isDeleted: false,
    ...(excludeId ? { _id: { $ne: excludeId } } : {}),
  } as FilterQuery<T>);

  if (clash) {
    throw ApiError.conflict(`A ${label.toLowerCase()} with this name already exists`);
  }

  return slug;
};
