import { UploadApiResponse } from 'cloudinary';
import { cloudinary } from '../config/cloudinary';
import { env } from '../config/env';
import { UploadedImage } from '../types/types';

export const uploadImage = (file: Express.Multer.File, folder: string): Promise<UploadedImage> =>
  new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(
      { folder: `${env.cloudinary.folder}/${folder}`, resource_type: 'image' },
      (error, result?: UploadApiResponse) => {
        if (error || !result) {
          reject(error ?? new Error('Cloudinary upload failed'));
          return;
        }
        resolve({ url: result.secure_url, publicId: result.public_id });
      },
    );

    stream.end(file.buffer);
  });

  export const deleteImage = async (publicId: string) => {
  if (!publicId) return;

  await cloudinary.uploader.destroy(publicId);
};
