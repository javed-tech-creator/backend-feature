import crypto from 'crypto';

export const hashOtp = (otp: string): string => {
  return crypto
    .createHash('sha256')
    .update(otp)
    .digest('hex');
};

export const compareOtp = (
  otp: string,
  hashedOtp: string,
): boolean => {
  const otpHash = hashOtp(otp);

  const actual = Buffer.from(otpHash, 'hex');
  const expected = Buffer.from(hashedOtp, 'hex');

  if (actual.length !== expected.length) {
    return false;
  }

  return crypto.timingSafeEqual(actual, expected);
};