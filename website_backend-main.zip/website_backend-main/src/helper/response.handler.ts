import { Response } from 'express';
import { env } from '../config/env';
import { CursorPaginationMeta, PaginationMeta } from '../utils/pagination';
import { logger } from '../utils/logger';

interface ErrorOptions {
  /** Field-level details, e.g. formatted ZodError issues. */
  details?: unknown;
  /** The original error — used for logging and the non-production stack. */
  error?: Error;
  /** Extra log context, e.g. { path, method }. */
  context?: Record<string, unknown>;
}

/** Builds every JSON response the API sends. */
export class ResponseHandler {
  static success(res: Response, message: string, data: unknown = null, status = 200): void {
    res.status(status).json({
      success: true,
      message,
      data,
    });
  }

  static paginated(
    res: Response,
    message: string,
    data: unknown[],
    meta: PaginationMeta,
    status = 200,
  ): void {
    res.status(status).json({
      success: true,
      message,
      data: { data, ...meta },
    });
  }

  static cursorPaginated(
    res: Response,
    message: string,
    data: unknown[],
    meta: CursorPaginationMeta,
    status = 200,
  ): void {
    res.status(status).json({
      success: true,
      message,
      data: { data, ...meta },
    });
  }

  // Central error logging — every error response is logged from here, so
  // controllers don't need to log in each catch block.
  static error(res: Response, message: string, status = 500, options: ErrorOptions = {}): void {
    const { details, error, context } = options;
    const meta = { statusCode: status, ...context, ...(error && { stack: error.stack }) };

    if (status >= 500) {
      logger.error(message, meta);
    } else {
      logger.warn(message, meta);
    }

    res.status(status).json({
      success: false,
      message,
      ...(details ? { details } : {}),
      ...(!env.isProduction && error?.stack ? { stack: error.stack } : {}),
    });
  }
}
