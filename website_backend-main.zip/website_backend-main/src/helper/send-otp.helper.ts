import axios from 'axios';
import { env } from '../config/env';

export const sendOtpSms = async (phone: string, otp: string): Promise<void> => {
  try {
    await axios.get('https://sms.renflair.in/V1.php', {
      params: {
        API: env.otp.apiKey,
        PHONE: phone,
        OTP: otp,
      },
      timeout: 10000, // 10 seconds
    });
  } catch {
    throw new Error('Failed to send OTP.');
  }
};
