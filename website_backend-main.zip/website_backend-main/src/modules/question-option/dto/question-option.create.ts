import { z } from 'zod';
import { AdjustmentOperation, AdjustmentType } from '../../../lib/enum';
import { objectIdSchema } from '../../../utils/object-id';
import { paginationQuerySchema } from '../../../utils/pagination';

export const questionOptionCreateSchema = z.object({
  questionId: objectIdSchema,
  title: z.string().trim().min(1, 'Title is required'),
  /** Iconify icon name, e.g. "mdi:cellphone", rendered by the frontend. */
  icon: z.string().trim().min(1).optional(),
  /** A percent (0-100) or a flat amount, per AdjustmentType. */
  value: z.number().nonnegative().optional(),
  adjustmentType: z.enum(AdjustmentType).default(AdjustmentType.PERCENTAGE),
  operation: z.enum(AdjustmentOperation).optional(),
});

export const questionOptionUpdateSchema = questionOptionCreateSchema.partial();

export const questionOptionListQuerySchema = paginationQuerySchema.extend({
  search: z.string().trim().min(1).optional(),
  questionId: objectIdSchema.optional(),
  sortBy: z.enum(['title', 'value', 'createdAt']).default('createdAt'),
});

export type QuestionOptionCreateDto = z.infer<typeof questionOptionCreateSchema>;
export type QuestionOptionUpdateDto = z.infer<typeof questionOptionUpdateSchema>;
export type QuestionOptionListQuery = z.infer<typeof questionOptionListQuerySchema>;
