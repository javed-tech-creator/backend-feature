import { NextFunction, Request, Response } from 'express';
import { ResponseHandler } from '../../helper/response.handler';
import { QuestionOptionService } from './question-option.service';
import { questionOptionListQuerySchema } from './dto/index.dto';

export class QuestionOptionController {
  static async list(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = questionOptionListQuerySchema.parse(req.query);
      const { options, meta } = await QuestionOptionService.list(query);
      ResponseHandler.paginated(res, 'Question options fetched successfully', options, meta);
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const option = await QuestionOptionService.getById(req.params.id as string);
      ResponseHandler.success(res, 'Question option fetched successfully', option);
    } catch (error) {
      next(error);
    }
  }
}
