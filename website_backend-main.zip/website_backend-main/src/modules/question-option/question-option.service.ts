import { Types } from 'mongoose';
import { Question } from '../../model/question.model';
import { QuestionOption } from '../../model/question-option.model';
import { buildMeta, toSkipTake } from '../../utils/pagination';
import { findLiveById } from '../../utils/query';
import {
  QuestionOptionCreateDto,
  QuestionOptionListQuery,
  QuestionOptionUpdateDto,
} from './dto/index.dto';
import { AdjustmentType } from '../../lib/enum';

const LABEL = 'Question option';

export class QuestionOptionService {
  static async create({
    questionId,
    title,
    icon,
    value,
    adjustmentType,
    operation,
  }: QuestionOptionCreateDto) {
    await findLiveById(Question, questionId, 'Question');
    const isNeutral =
      adjustmentType === AdjustmentType.NONE || adjustmentType === AdjustmentType.REJECT;

    return QuestionOption.create({
      questionId,
      title,
      icon,
      value: isNeutral ? null : value,
      adjustmentType,
      operation: isNeutral ? null : operation,
    });
  }

  static async list(query: QuestionOptionListQuery) {
    const { skip, take } = toSkipTake(query);
    const filter = {
      isDeleted: false,
      ...(query.questionId ? { questionId: query.questionId } : {}),
      ...(query.search ? { title: { $regex: query.search, $options: 'i' } } : {}),
    };

    const [options, total] = await Promise.all([
      QuestionOption.find(filter)
        .sort({ [query.sortBy]: query.order === 'asc' ? 1 : -1 })
        .skip(skip)
        .limit(take),
      QuestionOption.countDocuments(filter),
    ]);

    return { options, meta: buildMeta(query, total) };
  }

  static async getById(id: string) {
    return findLiveById(QuestionOption, id, LABEL);
  }

  static async update(
    id: string,
    { questionId, title, icon, value, adjustmentType, operation }: QuestionOptionUpdateDto,
  ) {
    const option = await findLiveById(QuestionOption, id, LABEL);

    if (questionId) {
      await findLiveById(Question, questionId, 'Question');
      option.questionId = new Types.ObjectId(questionId);
    }

    option.title = title ?? option.title;
    option.icon = icon ?? option.icon;

    if (adjustmentType !== undefined) {
      option.adjustmentType = adjustmentType;

      // For "none" and "reject", clear operation & value
      if (adjustmentType === AdjustmentType.NONE || adjustmentType === AdjustmentType.REJECT) {
        option.operation = null;
        option.value = null;
      }
    }

    // Only update these when applicable
    if (
      option.adjustmentType !== AdjustmentType.NONE &&
      option.adjustmentType !== AdjustmentType.REJECT
    ) {
      option.operation = operation ?? option.operation;
      option.value = value ?? option.value;
    }

    return option.save();
  }

  static async remove(id: string) {
    const option = await findLiveById(QuestionOption, id, LABEL);
    option.isDeleted = true;
    await option.save();
  }
}
