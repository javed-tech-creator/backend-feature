import { Router } from 'express';
import { validate } from '../../middlewares/validate';
import { idParamSchema } from '../../utils/object-id';
import { QuestionOptionController } from './question-option.controller';

const router = Router();

router.get('/', QuestionOptionController.list);
router.get('/:id', validate({ params: idParamSchema }), QuestionOptionController.getById);

export default router;
