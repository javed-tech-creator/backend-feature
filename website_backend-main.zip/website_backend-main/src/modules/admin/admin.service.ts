import bcrypt from 'bcryptjs';
import { UserRole } from '../../lib/enum';
import { User } from '../../model/user.model';
import { ApiError } from '../../utils/api-error';
import { signToken, toUserResponse } from '../../utils/token';
import { AdminLoginDto, AdminSignupDto } from './dto/index.dto';
import { PASSWORD_SALT_ROUNDS } from '../../lib/constant';


const isEmail = (value: string): boolean => value.includes('@');

export class AdminService {
  static async signup({ phone, email, password, fullName }: AdminSignupDto) {
    const existing = await User.findOne({
      $or: [{ phone }, ...(email ? [{ email }] : [])],
      isDeleted: false,
    });

    if (existing) {
      throw ApiError.conflict('An account with this phone or email already exists');
    }

    const admin = await User.create({
      phone,
      email,
      password: await bcrypt.hash(password, PASSWORD_SALT_ROUNDS),
      fullName,
      role: UserRole.ADMIN,
    });

    return toUserResponse(admin);
  }

  static async login({ identifier, password }: AdminLoginDto) {
    const admin = await User.findOne({
      ...(isEmail(identifier)
        ? { email: identifier.toLowerCase() }
        : { phone: identifier }),
      role: UserRole.ADMIN,
      isDeleted: false,
    }).select('+password');

    if (!admin || !admin.password) {
      throw ApiError.unauthorized('Invalid credentials');
    }

    const passwordMatches = await bcrypt.compare(password, admin.password);
    if (!passwordMatches) {
      throw ApiError.unauthorized('Invalid credentials');
    }

    return {
      token: signToken(admin.id, admin.role),
      admin: toUserResponse(admin),
    };
  }
}
