import { z } from 'zod';

/** Admin accounts are created by the seeder only — there is no signup route. */
export const adminSignupSchema = z.object({
  phone: z.string().trim().min(1, 'Phone is required'),
  email: z.string().trim().toLowerCase().email('A valid email is required').optional(),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  fullName: z.string().trim().min(1).optional(),
});

export type AdminSignupDto = z.infer<typeof adminSignupSchema>;
