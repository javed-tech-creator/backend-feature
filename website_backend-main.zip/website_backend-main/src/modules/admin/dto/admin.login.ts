import { z } from 'zod';

/** Admin logs in with either a phone number or an email in the same field. */
export const adminLoginSchema = z.object({
  identifier: z.string().trim().min(1, 'Phone or email is required'),
  password: z.string().min(1, 'Password is required'),
});

export type AdminLoginDto = z.infer<typeof adminLoginSchema>;