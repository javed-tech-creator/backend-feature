import { z } from 'zod';
import { cursorPaginationQuerySchema } from '../../../utils/pagination';

export const modelStorageListQuerySchema = cursorPaginationQuerySchema;

export type ModelStorageListQuery = z.infer<typeof modelStorageListQuerySchema>;
