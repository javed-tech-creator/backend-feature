import { NextFunction, Request, Response } from 'express';
import { ResponseHandler } from '../../helper/response.handler';
import { ModelStorageService } from './model-storage.service';

export class ModelStorageController {
  static async listByModelSlug(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { model,data } = await ModelStorageService.listByModelSlug(
        req.params.slug as string
      );
      ResponseHandler.success(res, 'Model storages fetched successfully', {data, model});
    } catch (error) {
      next(error);
    }
  }
}
