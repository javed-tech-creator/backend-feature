import { Model } from '../../model/model.model';
import { ModelStorage } from '../../model/model-storage.model';
import { findLiveBySlug } from '../../utils/query';

const STORAGE_POPULATE = {
  path: 'storageId',
  match: { isDeleted: false },
  select: '_id ram rom slug',
};

export class ModelStorageService {
  static async listByModelSlug(modelSlug: string) {
    const deviceModel = await findLiveBySlug(Model, modelSlug, 'Model');
    const filter = {
      modelId: deviceModel._id,
    };

    const storages = await ModelStorage.find(filter)
      .select('_id storageId basePrice')
      .populate(STORAGE_POPULATE)
      .sort({ _id: 1 })
      .lean();


    return {
      model: {
      _id: deviceModel._id,
      name: deviceModel.name,
      logo: deviceModel.logo,
    },
      data: storages.filter((storage) => storage.storageId),
    };
  }
}
