import { Router } from 'express';
import { validate } from '../../middlewares/validate';
import { modelSlugParamSchema } from '../../utils/slug';
import { ModelStorageController } from './model-storage.controller';

const router = Router();

router.get('/all/:slug', validate({ params: modelSlugParamSchema }),ModelStorageController.listByModelSlug);

export default router;
