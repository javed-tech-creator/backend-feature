import { NextFunction, Request, Response } from 'express';
import { ResponseHandler } from '../../helper/response.handler';
import { QuestionService } from './question.service';
import { questionListQuerySchema } from './dto/index.dto';

export class QuestionController {
  static async list(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = questionListQuerySchema.parse(req.query);
      const { questions, meta } = await QuestionService.list(query);
      ResponseHandler.paginated(res, 'Questions fetched successfully', questions, meta);
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const question = await QuestionService.getById(req.params.id as string);
      ResponseHandler.success(res, 'Question fetched successfully', question);
    } catch (error) {
      next(error);
    }
  }

  static async getByDevice(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const questionnaire = await QuestionService.questionnaireByDevice(
        req.params.deviceId as string,
      );
      ResponseHandler.success(res, 'Questionnaire fetched successfully', questionnaire);
    } catch (error) {
      next(error);
    }
  }
}
