import { Router } from 'express';
import { validate } from '../../middlewares/validate';
import { idParamSchema } from '../../utils/object-id';
import { QuestionController } from './question.controller';
import { questionDeviceParamSchema } from './dto/index.dto';

const router = Router();

router.get('/', QuestionController.list);
router.get(
  '/device/:deviceId',
  validate({ params: questionDeviceParamSchema }),
  QuestionController.getByDevice,
);
router.get('/:id', validate({ params: idParamSchema }), QuestionController.getById);

export default router;
