import { Types } from 'mongoose';
import { Brand } from '../../model/brand.model';
import { Device } from '../../model/device.model';
import {
  buildMeta,
  buildSearchFilter,
  CursorPaginationQuery,
  paginateCursor,
  toCursorFilter,
  toSkipTake,
} from '../../utils/pagination';
import { findLiveById, findLiveBySlug } from '../../utils/query';
import { buildUniqueSlug } from '../../utils/slug';
import { deleteImage, uploadImage } from '../../utils/upload';
import { BrandCreateDto, BrandListQuery, BrandUpdateDto } from './dto/index.dto';

export const LABEL = 'Brand';
export const CLOUDINARY_FOLDER = 'brands';

export class BrandService {
  static async create({ deviceId, name }: BrandCreateDto, file?: Express.Multer.File) {
    await findLiveById(Device, deviceId, 'Device');
    const uploadedImage = file ? await uploadImage(file, CLOUDINARY_FOLDER) : null;

    return Brand.create({
      deviceId,
      name,
      slug: await buildUniqueSlug(Brand, name, LABEL, { deviceId }),
      logo: uploadedImage?.url,
      logoPublicId: uploadedImage?.publicId,
    });
  }

  static async list(query: BrandListQuery) {
    const { skip, take } = toSkipTake(query);
    const filter = {
      isDeleted: false,
      ...(query.deviceId ? { deviceId: query.deviceId } : {}),
      ...buildSearchFilter(query.search, ['name']),
    };

    const [brands, total] = await Promise.all([
      Brand.find(filter)
        .populate({
          path: 'deviceId',
          select: '_id name',
        })
        .sort({ [query.sortBy]: query.order === 'asc' ? 1 : -1 })
        .skip(skip)
        .limit(take),
      Brand.countDocuments(filter),
    ]);

    return { brands, meta: buildMeta(query, total) };
  }

  /** Feeds a dropdown, so it returns every brand of the device — no pagination. */
  static async listByDevice(deviceId: string) {
    await findLiveById(Device, deviceId, 'Device');
    return Brand.find({ deviceId, isDeleted: false }).sort({ name: 1 });
  }

  static async listByDeviceSlug(deviceSlug: string, query: CursorPaginationQuery) {
    const device = await findLiveBySlug(Device, deviceSlug, 'Device');
    const filter = {
      deviceId: device._id,
      isDeleted: false,
      ...toCursorFilter(query.cursor),
    };

    const brands = await Brand.find(filter)
      .select('_id name slug logo')
      .sort({ _id: 1 })
      .limit(query.limit + 1)
      .lean();

    return paginateCursor(brands, query.limit);
  }

  static async getById(id: string) {
    return findLiveById(Brand, id, LABEL);
  }

  static async update(id: string, { deviceId, name }: BrandUpdateDto, file?: Express.Multer.File) {
    const brand = await findLiveById(Brand, id, LABEL);

    if (deviceId) {
      await findLiveById(Device, deviceId, 'Device');
      brand.deviceId = new Types.ObjectId(deviceId);
    }

    // The slug must stay unique inside whichever device the brand ends up under.
    if (deviceId || name) {
      brand.name = name ?? brand.name;
      brand.slug = await buildUniqueSlug(
        Brand,
        brand.name,
        LABEL,
        { deviceId: brand.deviceId },
        id,
      );
    }

    if (file) {
      if (brand.logoPublicId) {
        await deleteImage(brand.logoPublicId);
      }
      const uploadedImage = await uploadImage(file, CLOUDINARY_FOLDER);
      brand.logo = uploadedImage.url;
      brand.logoPublicId = uploadedImage.publicId;
    }

    return brand.save();
  }

  static async remove(id: string) {
    const brand = await findLiveById(Brand, id, LABEL);
    brand.isDeleted = true;
    await brand.save();
  }
}
