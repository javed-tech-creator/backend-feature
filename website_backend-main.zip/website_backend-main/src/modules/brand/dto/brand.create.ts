import { z } from 'zod';
import { objectIdSchema } from '../../../utils/object-id';
import { paginationQuerySchema, searchSchema } from '../../../utils/pagination';

export const brandCreateSchema = z.object({
  deviceId: objectIdSchema,
  name: z.string().trim().min(1, 'Name is required'),
});

export const brandUpdateSchema = brandCreateSchema.partial();

export const brandDeviceParamSchema = z.object({ deviceId: objectIdSchema });

export const brandListQuerySchema = paginationQuerySchema.extend({
  search: searchSchema,
  deviceId: objectIdSchema.optional(),
  sortBy: z.enum(['name', 'createdAt']).default('createdAt'),
});

export type BrandCreateDto = z.infer<typeof brandCreateSchema>;
export type BrandUpdateDto = z.infer<typeof brandUpdateSchema>;
export type BrandListQuery = z.infer<typeof brandListQuerySchema>;
