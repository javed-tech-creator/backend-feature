import { NextFunction, Request, Response } from 'express';
import { ResponseHandler } from '../../helper/response.handler';
import { cursorPaginationQuerySchema } from '../../utils/pagination';
import { BrandService } from './brand.service';
import { brandListQuerySchema } from './dto/index.dto';

export class BrandController {
  static async list(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = brandListQuerySchema.parse(req.query);
      const { brands, meta } = await BrandService.list(query);
      ResponseHandler.paginated(res, 'Brands fetched successfully', brands, meta);
    } catch (error) {
      next(error);
    }
  }

  static async listByDevice(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const brands = await BrandService.listByDevice(req.params.deviceId as string);
      ResponseHandler.success(res, 'Brands fetched successfully', brands);
    } catch (error) {
      next(error);
    }
  }

  static async listByDeviceSlug(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = cursorPaginationQuerySchema.parse(req.query);
      const { data, ...meta } = await BrandService.listByDeviceSlug(
        req.params.slug as string,
        query,
      );
      ResponseHandler.cursorPaginated(res, 'Brands fetched successfully', data, meta);
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const brand = await BrandService.getById(req.params.id as string);
      ResponseHandler.success(res, 'Brand fetched successfully', brand);
    } catch (error) {
      next(error);
    }
  }
}
