import { Router } from 'express';
import { validate } from '../../middlewares/validate';
import { idParamSchema } from '../../utils/object-id';
import { BrandController } from './brand.controller';
import { brandDeviceParamSchema } from './dto/index.dto';
import { deviceSlugParamSchema } from '../../utils/slug';

const router = Router();

router.get('/', BrandController.list);
router.get(
  '/device/:deviceId',
  validate({ params: brandDeviceParamSchema }),
  BrandController.listByDevice,
);
router.get('/:id', validate({ params: idParamSchema }), BrandController.getById);
router.get('/all/:slug', validate({ params: deviceSlugParamSchema }), BrandController.listByDeviceSlug);

export default router;
