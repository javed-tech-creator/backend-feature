import { Router } from 'express';
import { validate } from '../../middlewares/validate';
import { idParamSchema } from '../../utils/object-id';
import { ModelController } from './model.controller';
import { brandSlugParamSchema } from '../../utils/slug';

const router = Router();

router.get('/', ModelController.list);
router.get('/search-query',ModelController.search);
router.get('/:id', validate({ params: idParamSchema }), ModelController.getById);
router.get('/all/:deviceSlug/:brandSlug', validate({ params: brandSlugParamSchema }), ModelController.listByBrandSlug);
export default router;
