import { z } from 'zod';
import { objectIdSchema } from '../../../utils/object-id';

export const modelBulkUploadSchema = z.object({
  deviceId: objectIdSchema,
  brandId: objectIdSchema,
});

export type ModelBulkUploadDto = z.infer<typeof modelBulkUploadSchema>;
