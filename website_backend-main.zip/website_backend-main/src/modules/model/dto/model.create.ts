import { z } from 'zod';
import { objectIdSchema } from '../../../utils/object-id';
import { paginationQuerySchema, searchSchema } from '../../../utils/pagination';

// The admin model form is submitted as multipart/form-data (because of the logo
// file upload), so every field arrives as a string. Numeric fields must be
// coerced, otherwise Zod rejects "1000" as not being a number.

export const modelStorageSchema = z.object({
  storageId: objectIdSchema,
  basePrice: z.coerce.number().nonnegative(),
});

/** multipart/form-data cannot carry an array of objects, so the rows arrive JSON-encoded. */
const parseStorages = (value: unknown): unknown => {
  if (typeof value !== 'string') {
    return value;
  }

  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
};

export const modelStoragesSchema = z.preprocess(
  parseStorages,
  z
    .array(modelStorageSchema)
    .min(1, 'At least one storage is required')
    // The same storage twice would give the model two prices for one option.
    .refine(
      (storages) => new Set(storages.map((storage) => storage.storageId)).size === storages.length,
      'Each storage can be added only once',
    ),
);

export const modelCreateSchema = z.object({
  brandId: objectIdSchema,
  name: z.string().trim().min(1, 'Name is required'),
  storages: modelStoragesSchema,
});

export const modelUpdateSchema = modelCreateSchema.partial();

export const modelListQuerySchema = paginationQuerySchema.extend({
  search: searchSchema,
  brandId: objectIdSchema.optional(),
  storageId: objectIdSchema.optional(),
  sortBy: z.enum(['name', 'createdAt']).default('createdAt'),
});

export type ModelStorageDto = z.infer<typeof modelStorageSchema>;
export type ModelCreateDto = z.infer<typeof modelCreateSchema>;
export type ModelUpdateDto = z.infer<typeof modelUpdateSchema>;
export type ModelListQuery = z.infer<typeof modelListQuerySchema>;
