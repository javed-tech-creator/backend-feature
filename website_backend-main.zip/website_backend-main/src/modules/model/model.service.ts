import { Types } from 'mongoose';
import { Brand } from '../../model/brand.model';
import { Device } from '../../model/device.model';
import { Model } from '../../model/model.model';
import { ModelStorage } from '../../model/model-storage.model';
import { Storage } from '../../model/storage.model';
import {
  buildMeta,
  buildSearchFilter,
  CursorPaginationQuery,
  ModelSearchQuery,
  paginateCursor,
  toCursorFilter,
  toSkipTake,
} from '../../utils/pagination';
import { findLiveById, findLiveBySlug } from '../../utils/query';
import { buildUniqueSlug } from '../../utils/slug';
import { deleteImage, uploadImage } from '../../utils/upload';
import { parseModelUploadFile, ParsedModelUploadRow } from '../../utils/file-parser';
import {
  ModelBulkUploadDto,
  ModelCreateDto,
  ModelListQuery,
  ModelStorageDto,
  ModelUpdateDto,
} from './dto/index.dto';
import { ApiError } from '../../utils/api-error';

const LABEL = 'Model';
const CLOUDINARY_FOLDER = 'models';

const BRAND_POPULATE = {
  path: 'brandId',
  select: '_id name deviceId',
  populate: { path: 'deviceId', select: '_id name' },
};

const CATALOG_MODEL_SELECT = '_id name slug logo';

/** A model's storages are a full replacement: whatever the admin submits is the new set. */
const replaceStorages = async (
  modelId: Types.ObjectId,
  storages: ModelStorageDto[],
): Promise<void> => {
  for (const { storageId } of storages) {
    await findLiveById(Storage, storageId, 'Storage');
  }

  await ModelStorage.deleteMany({ modelId });
  await ModelStorage.insertMany(storages.map((storage) => ({ ...storage, modelId })));
};

/** A storage deleted after it was priced must not resurface, hence the `match` + filter. */
const withStorages = async <T extends { _id: Types.ObjectId; toObject(): object }>(model: T) => {
  const storages = await ModelStorage.find({ modelId: model._id })
    .populate({ path: 'storageId', match: { isDeleted: false }, select: '_id ram rom slug' })
    .sort({ basePrice: 1 });

  return { ...model.toObject(), storages: storages.filter((storage) => storage.storageId) };
};

export class ModelService {
  static async create({ brandId, name, storages }: ModelCreateDto, file?: Express.Multer.File) {
    await findLiveById(Brand, brandId, 'Brand');
    const uploadedImage = file ? await uploadImage(file, CLOUDINARY_FOLDER) : null;

    const model = await Model.create({
      brandId,
      name,
      slug: await buildUniqueSlug(Model, name, LABEL, { brandId }),
      logo: uploadedImage?.url,
      logoPublicId: uploadedImage?.publicId,
    });

    await replaceStorages(model._id, storages);

    return withStorages(model);
  }

  static async list(query: ModelListQuery) {
    const { skip, take } = toSkipTake(query);

    // Filtering by storage means "models offering this storage", which only the join knows.
    const storageMatches = query.storageId
      ? await ModelStorage.find({ storageId: query.storageId }).distinct('modelId')
      : null;

    const filter = {
      isDeleted: false,
      ...(query.brandId ? { brandId: query.brandId } : {}),
      ...(storageMatches ? { _id: { $in: storageMatches } } : {}),
      ...buildSearchFilter(query.search, ['name']),
    };

    const [models, total] = await Promise.all([
      Model.find(filter)
        .populate(BRAND_POPULATE)
        .sort({ [query.sortBy]: query.order === 'asc' ? 1 : -1 })
        .skip(skip)
        .limit(take),
      Model.countDocuments(filter),
    ]);

    return {
      models: await Promise.all(models.map(withStorages)),
      meta: buildMeta(query, total),
    };
  }

  static async listByDeviceSlug(deviceSlug: string, query: CursorPaginationQuery) {
    const device = await findLiveBySlug(Device, deviceSlug, 'Device');
    // Model belongs to Brand, not Device — resolve children through the device's brands.
    const brandIds = await Brand.find({ deviceId: device._id, isDeleted: false }).distinct('_id');
    const filter = {
      brandId: { $in: brandIds },
      isDeleted: false,
      ...toCursorFilter(query.cursor),
    };

    const models = await Model.find(filter)
      .select(CATALOG_MODEL_SELECT)
      .sort({ _id: 1 })
      .limit(query.limit + 1)
      .lean();

    return paginateCursor(models, query.limit);
  }

  static async listByBrandSlug(
    deviceSlug: string,
    brandSlug: string,
    query: CursorPaginationQuery,
  ) {
    // Step 1: Find device
    const device = await findLiveBySlug(Device, deviceSlug, 'Device');
    
    // Step 2: Find brand using BOTH brandSlug and deviceId
    const brand = await findLiveBySlug(Brand, brandSlug, 'Brand', {
      deviceId: device._id,
    });

    const filter = {
      brandId: brand._id,
      isDeleted: false,
      ...toCursorFilter(query.cursor),
    };

    const models = await Model.find(filter)
      .select(CATALOG_MODEL_SELECT)
      .sort({ _id: 1 })
      .limit(query.limit + 1)
      .lean();

    return paginateCursor(models, query.limit);
  }

  static async search(query: ModelSearchQuery) {
  const { q, limit, cursor } = query;

  const filter = {
    name: {
      $regex: q,
      $options: 'i',
    },

    isDeleted: false,

    ...toCursorFilter(cursor),
  };

  const models = await Model.find(filter)
    .select(CATALOG_MODEL_SELECT)
    .sort({ _id: 1 })
    .limit(limit + 1)
    .populate({
      path: 'brandId',
      select: 'name slug deviceId',
      match: {
        isDeleted: false,
      },
      populate: {
        path: 'deviceId',
        select: 'name slug',
        match: {
          isDeleted: false,
        },
      },
    })
    .lean();

 const { data, ...meta } = paginateCursor(models, limit);

  // Then format response
  const result = data
    .filter((item) => {
      const brand = item.brandId as unknown as {
        slug: string;
        logo?: string;
        deviceId?: {
          slug: string;
        };
      };

      return brand?.deviceId;
    })
    .map((item) => {
      const brand = item.brandId as unknown as {
        slug: string;
        logo?: string;
        deviceId: {
          slug: string;
        };
      };

      return {
        id: item._id,
        modelName: item.name,
        logo: item.logo || brand.logo || '',
        route: `/sell/${brand.deviceId.slug}/${brand.slug}/${item.slug}`,
      };
    });

  return {
    data: result,
    ...meta,
  };
}

  static async getById(id: string) {
    const model = await findLiveById(Model, id, LABEL);
    await model.populate(BRAND_POPULATE);

    return withStorages(model);
  }

  static async bulkUpload({ deviceId, brandId }: ModelBulkUploadDto, file?: Express.Multer.File) {
    const brand = await findLiveById(Brand, brandId, 'Brand');
    if (brand.deviceId.toString() !== deviceId) {
      throw ApiError.badRequest('Selected brand does not belong to the selected device');
    }

    if (!file) {
      throw ApiError.badRequest('A file must be uploaded');
    }

    const rows = parseModelUploadFile(file);
    if (rows.length === 0) {
      throw ApiError.badRequest('Uploaded file must contain at least one model row');
    }

    const modelsByName = new Map<
      string,
      { storageMap: Map<string, number>; rows: ParsedModelUploadRow[] }
    >();

    for (const row of rows) {
      const key = row.modelName.trim();
      const normalizedStorage = row.storage.trim();
      const existing = modelsByName.get(key);

      if (!existing) {
        modelsByName.set(key, {
          storageMap: new Map([[normalizedStorage, row.price]]),
          rows: [row],
        });
        continue;
      }

      const previous = existing.storageMap.get(normalizedStorage);
      if (previous !== undefined && previous !== row.price) {
        throw ApiError.badRequest(
          `Conflicting price for model "${key}" and storage "${normalizedStorage}"`,
        );
      }

      existing.storageMap.set(normalizedStorage, row.price);
      existing.rows.push(row);
    }

    const createStorage = async (storageLabel: string) => {
      const [rawRam, rawRom] = storageLabel
        .split('/')
        .map((part) => part.trim())
        .filter(Boolean);
      const ram = rawRom ? rawRam : undefined;
      const rom = rawRom ?? rawRam;

      if (!rom) {
        throw ApiError.badRequest(`Invalid storage value: ${storageLabel}`);
      }

      const storageFilter = ram
        ? { ram, rom, isDeleted: false }
        : { rom, isDeleted: false, ram: { $in: [null, ''] } };

      let storage = await Storage.findOne(storageFilter as Record<string, unknown>);
      if (!storage) {
        const slug = await buildUniqueSlug(Storage, ram ? `${ram}-${rom}` : rom, 'Storage');
        storage = await Storage.create({ ram, rom, slug });
      }

      return storage;
    };

    const createdModels = [] as Awaited<ReturnType<typeof withStorages>>[];

    for (const [name, group] of modelsByName.entries()) {
      const model = await Model.create({
        brandId,
        name,
        slug: await buildUniqueSlug(Model, name, LABEL, { brandId }),
      });

      const storages = [] as { storageId: Types.ObjectId; basePrice: number }[];
      for (const [storageLabel, basePrice] of group.storageMap.entries()) {
        const storage = await createStorage(storageLabel);
        storages.push({ storageId: storage._id, basePrice });
      }

      await ModelStorage.insertMany(
        storages.map((storage) => ({ ...storage, modelId: model._id })),
      );
      await model.populate(BRAND_POPULATE);
      createdModels.push(await withStorages(model));
    }

    return createdModels;
  }

  static async update(
    id: string,
    { brandId, name, storages }: ModelUpdateDto,
    file?: Express.Multer.File,
  ) {
    const model = await findLiveById(Model, id, LABEL);

    if (brandId) {
      await findLiveById(Brand, brandId, 'Brand');
      model.brandId = new Types.ObjectId(brandId);
    }

    // The slug must stay unique inside whichever brand the model ends up under.
    if (brandId || name) {
      model.name = name ?? model.name;
      model.slug = await buildUniqueSlug(Model, model.name, LABEL, { brandId: model.brandId }, id);
    }

    if (file) {
      // Delete previous image if exists
      if (model.logoPublicId) {
        await deleteImage(model.logoPublicId);
      }
      const uploadedImage = await uploadImage(file, CLOUDINARY_FOLDER);
      model.logo = uploadedImage.url;
      model.logoPublicId = uploadedImage.publicId;
    }

    await model.save();

    if (storages) {
      await replaceStorages(model._id, storages);
    }

    await model.populate(BRAND_POPULATE);

    return withStorages(model);
  }

  static async remove(id: string) {
    const model = await findLiveById(Model, id, LABEL);
    model.isDeleted = true;
    await model.save();
  }
}
