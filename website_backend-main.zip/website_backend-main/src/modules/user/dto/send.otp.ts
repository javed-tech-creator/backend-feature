import { z } from 'zod';

export const userSendOtpSchema = z.object({
  phone: z.string().trim().min(1, 'Phone is required'),

  fullName: z
    .string()
    .trim()
    .min(1, 'Full name is required')
    .optional(),

  email: z
    .string()
    .trim()
    .email('Invalid email address')
    .optional(),
});

export type UserSendOtpDto = z.infer<typeof userSendOtpSchema>;
