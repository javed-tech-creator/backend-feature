import { z } from 'zod';

export const userLoginSchema = z.object({
  phone: z.string().trim().min(1, 'Phone is required'),
});

export const userVerifyOtpSchema = z.object({
  phone: z.string().trim().min(1, 'Phone is required'),
  otp: z.string().trim().regex(/^\d{6}$/, 'OTP must be 6 digits'),
});

export type UserLoginDto = z.infer<typeof userLoginSchema>;
export type UserVerifyOtpDto = z.infer<typeof userVerifyOtpSchema>;
