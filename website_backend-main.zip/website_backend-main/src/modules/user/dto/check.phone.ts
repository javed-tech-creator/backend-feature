import { z } from 'zod';

export const userCheckPhoneSchema = z.object({
  phone: z.string().trim().min(1, 'Phone is required'),
});

export type UserCheckPhoneDto = z.infer<typeof userCheckPhoneSchema>;
