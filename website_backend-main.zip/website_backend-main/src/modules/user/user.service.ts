// import bcrypt from 'bcryptjs';
// import { randomInt } from 'crypto';
// import { env } from '../../config/env';
// import { UserRole } from '../../lib/enum';
// import { User } from '../../model/user.model';
// import { ApiError } from '../../utils/api-error';
// import { sendSms } from '../../utils/sms';
// import { signToken, toUserResponse } from '../../utils/token';
// import { UserLoginDto, UserVerifyOtpDto } from './dto/index.dto';
// import { OTP_SALT_ROUNDS } from '../../lib/constant';


// const generateOtp = (): string => randomInt(100_000, 1_000_000).toString();

// export class UserService {
// }
