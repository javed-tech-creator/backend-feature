import { Router } from 'express';
// import { authenticate } from '../../middlewares/auth.middleware'; // this firebase setup for otp uid verification
import { UserController } from './user.controller';

const router = Router();

router.post('/exist-phone', UserController.checkPhone);
router.post('/send-otp', UserController.sendOtp);
router.post('/verify-otp', UserController.verifyOtp);

export default router;
