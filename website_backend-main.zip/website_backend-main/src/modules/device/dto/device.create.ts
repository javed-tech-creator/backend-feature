import { z } from 'zod';
import { paginationQuerySchema, searchSchema } from '../../../utils/pagination';

export const deviceCreateSchema = z.object({
  name: z.string().trim().min(1, 'Name is required'),
});

export const deviceUpdateSchema = deviceCreateSchema.partial();

export const deviceListQuerySchema = paginationQuerySchema.extend({
  search: searchSchema,
  sortBy: z.enum(['name', 'createdAt']).default('createdAt'),
});

export type DeviceCreateDto = z.infer<typeof deviceCreateSchema>;
export type DeviceUpdateDto = z.infer<typeof deviceUpdateSchema>;
export type DeviceListQuery = z.infer<typeof deviceListQuerySchema>;
