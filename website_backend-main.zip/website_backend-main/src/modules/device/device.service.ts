import { Device } from '../../model/device.model';
import { buildMeta, buildSearchFilter, toSkipTake } from '../../utils/pagination';
import { findLiveById } from '../../utils/query';
import { buildUniqueSlug } from '../../utils/slug';
import { deleteImage, uploadImage } from '../../utils/upload';
import { DeviceCreateDto, DeviceListQuery, DeviceUpdateDto } from './dto/index.dto';

const LABEL = 'Device';
const CLOUDINARY_FOLDER = 'devices';

export class DeviceService {
  static async create({ name }: DeviceCreateDto, file?: Express.Multer.File) {
    const uploadedImage = file ? await uploadImage(file, CLOUDINARY_FOLDER) : null;

    return Device.create({
      name,
      slug: await buildUniqueSlug(Device, name, LABEL),
      logo: uploadedImage?.url,
      logoPublicId: uploadedImage?.publicId,
    });
  }

  static async list(query: DeviceListQuery) {
    const { skip, take } = toSkipTake(query);
    const filter = {
      isDeleted: false,
      ...buildSearchFilter(query.search, ['name']),
    };

    const [devices, total] = await Promise.all([
      Device.find(filter)
        .sort({ [query.sortBy]: query.order === 'asc' ? 1 : -1 })
        .skip(skip)
        .limit(take),
      Device.countDocuments(filter),
    ]);

    return { devices, meta: buildMeta(query, total) };
  }

  static async getById(id: string) {
    return findLiveById(Device, id, LABEL);
  }

  static async update(id: string, { name }: DeviceUpdateDto, file?: Express.Multer.File) {
    const device = await findLiveById(Device, id, LABEL);

    if (name) {
      device.name = name;
      device.slug = await buildUniqueSlug(Device, name, LABEL, {}, id);
    }

    if (file) {
      // Delete previous image if exists
      if (device.logoPublicId) {
        await deleteImage(device.logoPublicId);
      }
      const uploadedImage = await uploadImage(file, CLOUDINARY_FOLDER);
      device.logo = uploadedImage.url;
      device.logoPublicId = uploadedImage.publicId;
    }

    return device.save();
  }

  static async remove(id: string) {
    const device = await findLiveById(Device, id, LABEL);
    device.isDeleted = true;
    await device.save();
  }
}
