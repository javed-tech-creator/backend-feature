import { Router } from 'express';
import { validate } from '../../middlewares/validate';
import { idParamSchema } from '../../utils/object-id';
import { DeviceController } from './device.controller';

const router = Router();

router.get('/', DeviceController.list);
router.get('/:id', validate({ params: idParamSchema }), DeviceController.getById);

export default router;
