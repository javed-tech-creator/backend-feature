import { NextFunction, Request, Response } from 'express';
import { ResponseHandler } from '../../helper/response.handler';
import { DeviceService } from './device.service';
import { deviceListQuerySchema } from './dto/index.dto';

export class DeviceController {
  static async list(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = deviceListQuerySchema.parse(req.query);
      const { devices, meta } = await DeviceService.list(query);
      ResponseHandler.paginated(res, 'Devices fetched successfully', devices, meta);
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const device = await DeviceService.getById(req.params.id as string);
      ResponseHandler.success(res, 'Device fetched successfully', device);
    } catch (error) {
      next(error);
    }
  }
}
