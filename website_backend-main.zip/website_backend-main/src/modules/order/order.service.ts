import { UserRole } from '../../lib/enum';
import { Model } from '../../model/model.model';
import { ModelStorage } from '../../model/model-storage.model';
import { Order } from '../../model/order.model';
import { Question } from '../../model/question.model';
import { QuestionOption } from '../../model/question-option.model';
import { UserAnswer } from '../../model/user-answer.model';
import { ApiError } from '../../utils/api-error';
import { buildMeta, toSkipTake } from '../../utils/pagination';
import { buildPriceBreakdown } from '../../utils/pricing';
import { findLiveById } from '../../utils/query';
import {
  OrderAnswerDto,
  OrderCreateDto,
  OrderListQuery,
  OrderStatusUpdateDto,
} from './dto/index.dto';

const LABEL = 'Order';

interface RequestUser {
  id: string;
  role: UserRole;
}

/** Customers only ever reach their own orders; admins reach every order. */
const assertVisible = (orderUserId: string, user: RequestUser) => {
  if (user.role !== UserRole.ADMIN && orderUserId !== user.id) {
    throw ApiError.forbidden();
  }
};

const resolveOptions = (answers: OrderAnswerDto[]) =>
  Promise.all(
    answers.map(async ({ questionId, selectedOptionId }) => {
      await findLiveById(Question, questionId, 'Question');
      const option = await findLiveById(QuestionOption, selectedOptionId, 'Question option');

      if (option.questionId.toString() !== questionId) {
        throw ApiError.badRequest('Selected option does not belong to the question');
      }

      return option;
    }),
  );

export class OrderService {
  static async create(userId: string, { modelId, storageId, orderType, answers }: OrderCreateDto) {
    await findLiveById(Model, modelId, 'Model');

    // The base price now belongs to the model/storage pair, not to the model.
    const modelStorage = await ModelStorage.findOne({ modelId, storageId });

    if (!modelStorage) {
      throw ApiError.badRequest('This storage is not available for the selected model');
    }

    const basePrice = modelStorage.basePrice;

    // Priced through the same engine as the calculator, so the offer a customer
    // was quoted is the offer their order is created with.
    const options = await resolveOptions(answers);
    const { finalOffer: finalPrice } = buildPriceBreakdown(
      basePrice,
      options.map((option) => ({
        type: option.adjustmentType,
        operation: option.operation,
        value: option.value ?? 0,
      })),
    );

    const order = await Order.create({
      userId,
      modelId,
      storageId,
      orderType,
      basePrice,
      finalPrice,
    });
    await UserAnswer.insertMany(answers.map((answer) => ({ ...answer, orderId: order._id })));

    return order;
  }

  private static async findMany(query: OrderListQuery, userId?: string) {
    const { skip, take } = toSkipTake(query);
    const filter = {
      isDeleted: false,
      ...(userId ? { userId } : {}),
      ...(query.status ? { status: query.status } : {}),
      ...(query.orderType ? { orderType: query.orderType } : {}),
      ...(query.modelId ? { modelId: query.modelId } : {}),
    };

    const [orders, total] = await Promise.all([
      Order.find(filter)
        .populate('modelId', 'name slug')
        .populate('storageId', 'ram rom slug')
        .sort({ [query.sortBy]: query.order === 'asc' ? 1 : -1 })
        .skip(skip)
        .limit(take),
      Order.countDocuments(filter),
    ]);

    return { orders, meta: buildMeta(query, total) };
  }

  static async list(query: OrderListQuery, user: RequestUser) {
    // Only an admin may filter by userId; a customer is pinned to their own orders.
    const userId = user.role === UserRole.ADMIN ? query.userId : user.id;

    return OrderService.findMany(query, userId);
  }

  /** The caller's own orders, whatever their role. */
  static async listMine(query: OrderListQuery, userId: string) {
    return OrderService.findMany(query, userId);
  }

  static async getById(id: string, user: RequestUser) {
    const order = await findLiveById(Order, id, LABEL);
    assertVisible(order.userId.toString(), user);

    const answers = await UserAnswer.find({ orderId: order._id, isDeleted: false });

    return { ...order.toObject(), answers };
  }

  static async updateStatus(id: string, { status }: OrderStatusUpdateDto) {
    const order = await findLiveById(Order, id, LABEL);
    order.status = status;

    return order.save();
  }

  static async remove(id: string, user: RequestUser) {
    const order = await findLiveById(Order, id, LABEL);
    assertVisible(order.userId.toString(), user);

    order.isDeleted = true;
    await order.save();
  }
}
