import { NextFunction, Request, Response } from 'express';
import { ResponseHandler } from '../../helper/response.handler';
import { OrderService } from './order.service';
import { orderListQuerySchema } from './dto/index.dto';

export class OrderController {
  static async create(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const order = await OrderService.create(req.user!.id, req.body);
      ResponseHandler.success(res, 'Order created successfully', order, 201);
    } catch (error) {
      next(error);
    }
  }

  static async list(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = orderListQuerySchema.parse(req.query);
      const { orders, meta } = await OrderService.list(query, req.user!);
      ResponseHandler.paginated(res, 'Orders fetched successfully', orders, meta);
    } catch (error) {
      next(error);
    }
  }

  static async listMine(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = orderListQuerySchema.parse(req.query);
      const { orders, meta } = await OrderService.listMine(query, req.user!.id);
      ResponseHandler.paginated(res, 'Your orders fetched successfully', orders, meta);
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const order = await OrderService.getById(req.params.id as string, req.user!);
      ResponseHandler.success(res, 'Order fetched successfully', order);
    } catch (error) {
      next(error);
    }
  }

  static async remove(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await OrderService.remove(req.params.id as string, req.user!);
      ResponseHandler.success(res, 'Order deleted successfully');
    } catch (error) {
      next(error);
    }
  }
}
