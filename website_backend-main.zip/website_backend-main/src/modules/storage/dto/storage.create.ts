import { z } from 'zod';
import { paginationQuerySchema, searchSchema } from '../../../utils/pagination';

export const storageCreateSchema = z.object({
  // RAM is optional — devices such as the iPhone are sold by ROM alone.
  ram: z
    .string()
    .trim()
    .optional()
    .transform((value) => value || undefined),

  rom: z.string().trim().min(1, 'ROM is required'),
});

export const storageUpdateSchema = storageCreateSchema.partial();

export const storageListQuerySchema = paginationQuerySchema.extend({
  search: searchSchema,
  ram: z.string().trim().optional(),
  rom: z.string().trim().optional(),
  sortBy: z.enum(['ram', 'rom', 'createdAt']).default('createdAt'),
});

export type StorageCreateDto = z.infer<typeof storageCreateSchema>;
export type StorageUpdateDto = z.infer<typeof storageUpdateSchema>;
export type StorageListQuery = z.infer<typeof storageListQuerySchema>;
