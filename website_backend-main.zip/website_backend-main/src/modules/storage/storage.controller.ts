import { NextFunction, Request, Response } from 'express';
import { ResponseHandler } from '../../helper/response.handler';
import { StorageService } from './storage.service';
import { storageListQuerySchema } from './dto/index.dto';

export class StorageController {
  static async list(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = storageListQuerySchema.parse(req.query);
      const { storages, meta } = await StorageService.list(query);
      ResponseHandler.paginated(res, 'Storages fetched successfully', storages, meta);
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const storage = await StorageService.getById(req.params.id as string);
      ResponseHandler.success(res, 'Storage fetched successfully', storage);
    } catch (error) {
      next(error);
    }
  }
}
