import { Router } from 'express';
import { validate } from '../../middlewares/validate';
import { idParamSchema } from '../../utils/object-id';
import { StorageController } from './storage.controller';

const router = Router();

router.get('/', StorageController.list);
router.get('/:id', validate({ params: idParamSchema }), StorageController.getById);

export default router;
