import { Storage } from '../../model/storage.model';
import { ApiError } from '../../utils/api-error';
import { buildMeta, buildSearchFilter, toSkipTake } from '../../utils/pagination';
import { findLiveById } from '../../utils/query';
import { buildUniqueSlug } from '../../utils/slug';
import { StorageCreateDto, StorageListQuery, StorageUpdateDto } from './dto/index.dto';

const LABEL = 'Storage';

/** RAM-less storages (iPhone and friends) are identified by their ROM alone. */
const buildStorageName = (ram: string | undefined, rom: string): string =>
  ram ? `${ram}-${rom}` : rom;

/** The same RAM/ROM pair twice would give orders two identical options to pick from. */
const ensureCombinationIsFree = async (
  ram: string | undefined,
  rom: string,
  excludeId?: string,
): Promise<void> => {
  const clash = await Storage.findOne({
    // A missing RAM is stored as no field at all, so it cannot be matched by equality.
    ...(ram ? { ram } : { ram: { $in: [null, ''] } }),
    rom,
    isDeleted: false,
    ...(excludeId ? { _id: { $ne: excludeId } } : {}),
  });

  if (clash) {
    throw ApiError.conflict('A storage with this RAM and ROM already exists');
  }
};

export class StorageService {
  static async create({ ram, rom }: StorageCreateDto) {
    await ensureCombinationIsFree(ram, rom);
    const slug = await buildUniqueSlug(Storage, buildStorageName(ram, rom), LABEL);

    return Storage.create({ ram, rom, slug });
  }

  static async list(query: StorageListQuery) {
    const { skip, take } = toSkipTake(query);
    const filter = {
      isDeleted: false,
      ...(query.ram ? { ram: query.ram } : {}),
      ...(query.rom ? { rom: query.rom } : {}),
      ...buildSearchFilter(query.search, ['ram', 'rom']),
    };

    const [storages, total] = await Promise.all([
      Storage.find(filter)
        .sort({ [query.sortBy]: query.order === 'asc' ? 1 : -1 })
        .skip(skip)
        .limit(take),
      Storage.countDocuments(filter),
    ]);

    return { storages, meta: buildMeta(query, total) };
  }

  static async getById(id: string) {
    return findLiveById(Storage, id, LABEL);
  }

  static async update(id: string, payload: StorageUpdateDto) {
    const storage = await findLiveById(Storage, id, LABEL);

    // Sending `ram: ''` clears the RAM; leaving the key out is what keeps it.
    if ('ram' in payload) {
      storage.ram = payload.ram;
    }
    storage.rom = payload.rom ?? storage.rom;

    await ensureCombinationIsFree(storage.ram, storage.rom, id);
    storage.slug = await buildUniqueSlug(
      Storage,
      buildStorageName(storage.ram, storage.rom),
      LABEL,
      {},
      id,
    );

    return storage.save();
  }

  static async remove(id: string) {
    const storage = await findLiveById(Storage, id, LABEL);
    storage.isDeleted = true;
    await storage.save();
  }
}
