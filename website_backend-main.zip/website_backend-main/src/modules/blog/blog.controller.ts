import { NextFunction, Request, Response } from 'express';
import { ApiError } from '../../utils/api-error';
import { ResponseHandler } from '../../helper/response.handler';
import { BlogService } from './blog.service';
import { blogCreateSchema, blogListQuerySchema, blogUpdateSchema } from './dto/index.dto';

export class BlogController {
  static async create(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.file) {
        throw ApiError.badRequest('Blog image is required');
      }

      const body = blogCreateSchema.parse(req.body);
      const blog = await BlogService.create(body, req.file);
      ResponseHandler.success(res, 'Blog created successfully', blog, 201);
    } catch (error) {
      next(error);
    }
  }

  static async list(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = blogListQuerySchema.parse(req.query);
      const { blogs, meta } = await BlogService.list(query);
      ResponseHandler.paginated(res, 'Blogs fetched successfully', blogs, meta);
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const blog = await BlogService.getById(req.params.id as string);
      ResponseHandler.success(res, 'Blog fetched successfully', blog);
    } catch (error) {
      next(error);
    }
  }

  static async update(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const body = blogUpdateSchema.parse(req.body);
      const blog = await BlogService.update(req.params.id as string, body, req.file);
      ResponseHandler.success(res, 'Blog updated successfully', blog);
    } catch (error) {
      next(error);
    }
  }

  static async remove(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await BlogService.remove(req.params.id as string);
      ResponseHandler.success(res, 'Blog deleted successfully');
    } catch (error) {
      next(error);
    }
  }
}

