import { Router } from 'express';
import { uploadImageFile } from '../../middlewares/upload-image';
import { validate } from '../../middlewares/validate';
import { idParamSchema } from '../../utils/object-id';
import { BlogController } from './blog.controller';
import { blogCreateSchema, blogUpdateSchema } from './dto/index.dto';

const router = Router();

router.post(
  '/',
  uploadImageFile.single('image'),
  validate({ body: blogCreateSchema }),
  BlogController.create,
);

router.get('/', BlogController.list);
router.get('/:id', validate({ params: idParamSchema }), BlogController.getById);
router.put(
  '/:id',
  uploadImageFile.single('image'),
  validate({ params: idParamSchema, body: blogUpdateSchema }),
  BlogController.update,
);
router.delete('/:id', validate({ params: idParamSchema }), BlogController.remove);

export default router;

