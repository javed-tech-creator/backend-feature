import { Blog } from '../../model/blog.model';
import { buildMeta, toSkipTake } from '../../utils/pagination';
import { findLiveById } from '../../utils/query';
import { uploadImage } from '../../utils/upload';
import { BlogCreateDto, BlogListQuery, BlogUpdateDto } from './dto/index.dto';

export const BLOG_LABEL = 'Blog';
export const BLOG_FOLDER = 'blogs';

export class BlogService {
  static async create(data: BlogCreateDto, file?: Express.Multer.File) {
    const blog = new Blog({
      ...data,
      image: file ? await uploadImage(file, BLOG_FOLDER) : undefined,
    });
    return blog.save();
  }

  static async list(query: BlogListQuery) {
    const { skip, take } = toSkipTake(query);
    const filter = {
      isDeleted: false,
      ...(query.search ? { title: { $regex: query.search, $options: 'i' } } : {}),
    };

    const [blogs, total] = await Promise.all([
      Blog.find(filter)
        .sort({ [query.sortBy]: query.order === 'asc' ? 1 : -1 })
        .skip(skip)
        .limit(take),
      Blog.countDocuments(filter),
    ]);

    return { blogs, meta: buildMeta(query, total) };
  }

  static async getById(id: string) {
    return findLiveById(Blog, id, BLOG_LABEL);
  }

  static async update(id: string, data: BlogUpdateDto, file?: Express.Multer.File) {
    const blog = await findLiveById(Blog, id, BLOG_LABEL);

    if (data.title) blog.title = data.title;
    if (data.description) blog.description = data.description;
    if (data.category) blog.category = data.category;
    if (data.tags) blog.tags = data.tags;

    if (file) {
      blog.image = await uploadImage(file, BLOG_FOLDER);
    }

    return blog.save();
  }

  static async remove(id: string) {
    const blog = await findLiveById(Blog, id, BLOG_LABEL);
    blog.isDeleted = true;
    await blog.save();
  }
}
