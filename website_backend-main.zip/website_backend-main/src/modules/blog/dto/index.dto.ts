import { z } from 'zod';
import { paginationQuerySchema } from '../../../utils/pagination';

export const blogCreateSchema = z.object({
  title: z.string().min(1),
  description: z.string().min(1),
  category: z.string().min(1),
  tags: z.array(z.string()).optional(),
});

export const blogUpdateSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().min(1).optional(),
  category: z.string().min(1).optional(),
  tags: z.array(z.string()).optional(),
});

export const blogListQuerySchema = paginationQuerySchema.extend({
  search: z.string().optional(),
  sortBy: z.enum(['createdAt', 'title']).default('createdAt'),
});

export type BlogCreateDto = z.infer<typeof blogCreateSchema>;
export type BlogUpdateDto = z.infer<typeof blogUpdateSchema>;
export type BlogListQuery = z.infer<typeof blogListQuerySchema>;