import { z } from 'zod';
import { objectIdSchema } from '../../../utils/object-id';

export const calculatorQuestionsQuerySchema = z.object({
  deviceId: objectIdSchema,
});

export const calculatorCalculateSchema = z.object({
  modelId: objectIdSchema,
  storageId: objectIdSchema,
  answers: z
    .array(
      z.object({
        questionId: objectIdSchema,
        optionId: objectIdSchema,
      }),
    )
    // Answering the same question twice would deduct for it twice.
    .refine(
      (answers) => new Set(answers.map((answer) => answer.questionId)).size === answers.length,
      'Each question can be answered only once',
    ),
});

export type CalculatorQuestionsQuery = z.infer<typeof calculatorQuestionsQuerySchema>;
export type CalculatorCalculateDto = z.infer<typeof calculatorCalculateSchema>;
