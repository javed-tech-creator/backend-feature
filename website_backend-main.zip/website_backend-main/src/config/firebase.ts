// import { cert, getApps, initializeApp } from 'firebase-admin/app';
// import { getAuth } from 'firebase-admin/auth';

// const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');

// if (!privateKey || !process.env.FIREBASE_PROJECT_ID || !process.env.FIREBASE_CLIENT_EMAIL) {
//   throw new Error('Missing Firebase Admin credentials in environment variables.');
// }

// if (!getApps().length) {
//   initializeApp({
//     credential: cert({
//       projectId: process.env.FIREBASE_PROJECT_ID,
//       clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
//       privateKey,
//     }),
//   });
// }

// export const firebaseAdminAuth = getAuth();
