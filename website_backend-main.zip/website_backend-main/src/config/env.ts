import dotenv from 'dotenv';
import path from 'path';
import { z } from 'zod';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(4000),
  API_PREFIX: z.string().default('/api/v1'),
  CORS_ORIGINS: z.string().default('http://localhost:3000'),
  BODY_LIMIT: z.string().default('1mb'),
  DB_URI: z.string().default('mongodb://127.0.0.1:27017/phonecash'),
  DB_NAME: z.string().default('phonecash'),
  LOG_LEVEL: z
    .enum(['error', 'warn', 'info', 'http', 'verbose', 'debug', 'silly'])
    .default('debug'),
  LOG_DIR: z.string().default('logs'),
  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(60000),
  RATE_LIMIT_MAX: z.coerce.number().int().positive().default(100),
  JWT_SECRET: z.string().min(32),
  JWT_EXPIRES_IN: z.string().default('7d'),
  SEED_ADMIN_PHONE: z.string().optional(),
  SEED_ADMIN_EMAIL: z.string().optional(),
  SEED_ADMIN_PASSWORD: z.string().optional(),
  SEED_ADMIN_FIRST_NAME: z.string().optional(),
  SEED_ADMIN_LAST_NAME: z.string().optional(),
  OTP_EXPIRY_MINUTES: z.coerce.number().int().positive().default(5),
  RENFLAIR_API_KEY: z.string().min(1),
  CLOUDINARY_CLOUD_NAME: z.string().min(1),
  CLOUDINARY_API_KEY: z.string().min(1),
  CLOUDINARY_API_SECRET: z.string().min(1),
  CLOUDINARY_FOLDER: z.string().default('phonecash'),
  UPLOAD_MAX_FILE_SIZE: z.coerce.number().int().positive().default(2_000_000),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  const details = parsed.error.issues
    .map((issue) => `  ${issue.path.join('.')}: ${issue.message}`)
    .join('\n');
  throw new Error(`Invalid environment variables:\n${details}`);
}

const raw = parsed.data;

export const env = {
  nodeEnv: raw.NODE_ENV,
  isProduction: raw.NODE_ENV === 'production',
  port: raw.PORT,
  apiPrefix: raw.API_PREFIX,
  bodyLimit: raw.BODY_LIMIT,
  corsOrigins: raw.CORS_ORIGINS.split(',')
    .map((origin) => origin.trim())
    .filter(Boolean),
  db: {
    uri: raw.DB_URI,
    name: raw.DB_NAME,
  },
  log: {
    level: raw.LOG_LEVEL,
    dir: raw.LOG_DIR,
  },
  rateLimit: {
    windowMs: raw.RATE_LIMIT_WINDOW_MS,
    max: raw.RATE_LIMIT_MAX,
  },
  jwt: {
    secret: raw.JWT_SECRET,
    expiresIn: raw.JWT_EXPIRES_IN,
  },
  otp: {
    expiryMinutes: raw.OTP_EXPIRY_MINUTES,
    apiKey: raw.RENFLAIR_API_KEY
  },
  cloudinary: {
    cloudName: raw.CLOUDINARY_CLOUD_NAME,
    apiKey: raw.CLOUDINARY_API_KEY,
    apiSecret: raw.CLOUDINARY_API_SECRET,
    folder: raw.CLOUDINARY_FOLDER,
  },
  upload: {
    maxFileSize: raw.UPLOAD_MAX_FILE_SIZE,
  },
  // Validated by adminSignupSchema in the seeder — only the seeder needs them.
  seedAdmin: {
    phone: raw.SEED_ADMIN_PHONE,
    email: raw.SEED_ADMIN_EMAIL,
    password: raw.SEED_ADMIN_PASSWORD,
    firstName: raw.SEED_ADMIN_FIRST_NAME,
    lastName: raw.SEED_ADMIN_LAST_NAME,
  },
} as const;
