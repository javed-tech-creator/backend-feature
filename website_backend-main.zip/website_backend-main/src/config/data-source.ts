import mongoose from 'mongoose';
import { env } from './env';

export const connectDatabase = async (): Promise<typeof mongoose> => {
  await mongoose.connect(env.db.uri, {
    dbName: env.db.name,
  });

  return mongoose;
};

export const disconnectDatabase = async (): Promise<void> => {
  await mongoose.disconnect();
};

export const AppDataSource = mongoose;
