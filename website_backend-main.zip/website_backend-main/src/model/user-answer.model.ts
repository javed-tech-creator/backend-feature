import { Schema, model } from 'mongoose';
import { baseSchemaOptions } from './base.model';
import { IUserAnswer } from '../types/types';

const userAnswerSchema = new Schema<IUserAnswer>(
  {
    orderId: { type: Schema.Types.ObjectId, required: true, ref: 'Order' },
    selectedOptionId: { type: Schema.Types.ObjectId, required: true, ref: 'QuestionOption' },
    questionId: { type: Schema.Types.ObjectId, required: true, ref: 'Question' },
    isDeleted: { type: Boolean, default: false },
  },
  baseSchemaOptions,
);

export const UserAnswer = model<IUserAnswer>('UserAnswer', userAnswerSchema);
