import { Schema, model } from 'mongoose';
import { baseSchemaOptions } from './base.model';
import { IQuestion } from '../types/types';
import { QuestionType } from '../lib/enum';

const questionSchema = new Schema<IQuestion>(
  {
    // Every device (phone, tablet, laptop, camera, watch...) owns its own steps and questions.
    deviceId: { type: Schema.Types.ObjectId, required: true, ref: 'Device' },
    title: { type: String, required: true },
    type: { type: String, enum: Object.values(QuestionType) },
    step: { type: Number },
    sortOrder: { type: Number, default: 0 },
    isActive: { type: Boolean, default: true },
    isDeleted: { type: Boolean, default: false },
  },
  baseSchemaOptions,
);

export const Question = model<IQuestion>('Question', questionSchema);
