import { Schema, model } from 'mongoose';
import { baseSchemaOptions } from './base.model';
import { IModelStorage } from '../types/types';

const modelStorageSchema = new Schema<IModelStorage>(
  {
    modelId: { type: Schema.Types.ObjectId, required: true, ref: 'Model' },
    storageId: { type: Schema.Types.ObjectId, required: true, ref: 'Storage' },
    basePrice: { type: Number, required: true },
  },
  baseSchemaOptions,
);

/** A model must not offer the same storage twice — orders price off this pair. */
modelStorageSchema.index({ modelId: 1, storageId: 1 }, { unique: true });
modelStorageSchema.index({ modelId: 1, _id: 1 });

export const ModelStorage = model<IModelStorage>('ModelStorage', modelStorageSchema);
