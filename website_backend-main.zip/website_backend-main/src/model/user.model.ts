import { Schema, model } from 'mongoose';
import { baseSchemaOptions } from './base.model';
import { IUser } from '../types/types';
import { UserRole } from '../lib/enum';

const userSchema = new Schema<IUser>(
  {
    email: { type: String, default: null },
    phone: { type: String, required: true, unique: true, index: true, trim: true },
    password: {type: String, default: null, select: false},
    fullName: { type: String, trim: true },
    role: { type: String, enum: Object.values(UserRole), default: UserRole.CUSTOMER },
    otp: { type: String, default: null}, 
    otpExpiresAt: { type: Date, default: null},
    otpAttempts: { type: Number, default: 0},
    isVerified: { type: Boolean, default: false },
    isDeleted: { type: Boolean, default: false },
  },
  baseSchemaOptions,
);

export const User = model<IUser>('User', userSchema);
