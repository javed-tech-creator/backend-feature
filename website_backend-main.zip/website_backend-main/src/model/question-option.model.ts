import { Schema, model } from 'mongoose';
import { baseSchemaOptions } from './base.model';
import { IQuestionOption } from '../types/types';
import {  AdjustmentOperation, AdjustmentType } from '../lib/enum';

const questionOptionSchema = new Schema<IQuestionOption>(
  {
    title: { type: String, required: true },
    icon: { type: String },
    // The raw value; `AdjustmentType` decides whether it is a percent or an amount.
    value: {
      type: Number,
      default: null,
    },
    adjustmentType: {
      type: String,
      enum: Object.values(AdjustmentType),
      default: AdjustmentType.PERCENTAGE,
    },
    operation: {
      type: String,
      enum: Object.values(AdjustmentOperation),
      default: null,
      required: false,
    },
    questionId: { type: Schema.Types.ObjectId, required: true, ref: 'Question' },
    isDeleted: { type: Boolean, default: false },
  },
  baseSchemaOptions,
);

export const QuestionOption = model<IQuestionOption>('QuestionOption', questionOptionSchema);
