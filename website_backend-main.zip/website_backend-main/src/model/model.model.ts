import { Schema, model } from 'mongoose';
import { baseSchemaOptions } from './base.model';
import { IModel } from '../types/types';

const modelSchema = new Schema<IModel>(
  {
    brandId: { type: Schema.Types.ObjectId, required: true, ref: 'Brand' },
    name: { type: String, required: true },
    slug: { type: String },
    logo: { type: String },
    logoPublicId: { type: String },
    isDeleted: { type: Boolean, default: false },
  },
  baseSchemaOptions,
);

modelSchema.index({ slug: 1 });
modelSchema.index({ brandId: 1, _id: 1 });

export const Model = model<IModel>('Model', modelSchema);
