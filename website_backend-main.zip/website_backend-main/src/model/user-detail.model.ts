import { Schema, model } from 'mongoose';
import { baseSchemaOptions } from './base.model';
import { IUserDetail } from '../types/types';

const userDetailSchema = new Schema<IUserDetail>(
  {
    userId: { type: Schema.Types.ObjectId, required: true, ref: 'User' },
    address1: { type: String },
    address2: { type: String },
    city: { type: String },
    state: { type: String },
    pinCode: { type: String },
    isDeleted: { type: Boolean, default: false },
  },
  baseSchemaOptions,
);

export const UserDetail = model<IUserDetail>('UserDetail', userDetailSchema);
