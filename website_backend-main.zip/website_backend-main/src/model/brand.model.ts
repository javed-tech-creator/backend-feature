import { Schema, model } from 'mongoose';
import { baseSchemaOptions } from './base.model';
import { IBrand } from '../types/types';

const brandSchema = new Schema<IBrand>(
  {
    deviceId: { type: Schema.Types.ObjectId, required: true, ref: 'Device' },
    name: { type: String, required: true },
    slug: { type: String },
    logo: { type: String },
    logoPublicId: { type: String },
    isDeleted: { type: Boolean, default: false },
  },
  baseSchemaOptions,
);

brandSchema.index({ slug: 1 });
brandSchema.index({ deviceId: 1, _id: 1 });

export const Brand = model<IBrand>('Brand', brandSchema);
