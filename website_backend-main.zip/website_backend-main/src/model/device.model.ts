import { Schema, model } from 'mongoose';
import { baseSchemaOptions } from './base.model';
import { IDevice } from '../types/types';

const deviceSchema = new Schema<IDevice>(
  {
    name: { type: String, required: true },
    slug: { type: String },
    logo: { type: String },
    logoPublicId: { type: String },
    isDeleted: { type: Boolean, default: false },
  },
  baseSchemaOptions,
);

deviceSchema.index({ slug: 1 });

export const Device = model<IDevice>('Device', deviceSchema);
