import { Schema, model } from 'mongoose';
import { toSlug } from '../utils/slug';
import { baseSchemaOptions } from './base.model';
import { IBlog } from '../types/types';

const blogSchema = new Schema<IBlog>(
  {
    title: { type: String, required: true, unique: true, trim: true },
    slug: { type: String, unique: true, trim: true, lowercase: true, index: true },
    description: { type: String, required: true },
    image: {
      url: { type: String },
      publicId: { type: String },
    },
    category: { type: String, required: true },
    tags: { type: [String], default: [] },
    isDeleted: { type: Boolean, default: false },
  },
  baseSchemaOptions,
);

blogSchema.pre('save', function (next) {
  if (!this.isModified('title')) return next();
  this.slug = toSlug(this.title);
  next();
});

export const Blog = model<IBlog>('Blog', blogSchema);
