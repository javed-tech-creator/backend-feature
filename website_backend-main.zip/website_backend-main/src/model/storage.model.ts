import { Schema, model } from 'mongoose';
import { baseSchemaOptions } from './base.model';
import { IStorage } from '../types/types';

const storageSchema = new Schema<IStorage>(
  {
    // Optional: phones like the iPhone are sold by storage only, with no RAM choice.
    ram: { type: String },
    rom: { type: String, required: true },
    slug: { type: String, required: true, unique: true },
    isDeleted: { type: Boolean, default: false },
  },
  baseSchemaOptions,
);

export const Storage = model<IStorage>('Storage', storageSchema);
