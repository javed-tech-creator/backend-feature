# phonecash Backend

REST API for the phonecash platform — Swiss employment-contract reading and payslip generation (see `phonecash_ANALYSIS_1A_1B_1C_EN.pdf`).

## Stack

- **Node.js + Express 5** (TypeScript)
- **MongoDB + TypeORM** (entities, document storage)
- **Winston** logging (console + rotating files in `logs/`)
- **Husky + lint-staged + commitlint** (conventional commits, lint/format on commit)
- ESLint (flat config) + Prettier

## Getting started

```bash
cp .env.example .env   # adjust DB_URI if needed
npm install
npm run dev            # build + run ./dist, rebuilds & restarts on change — http://localhost:4000/api/v1
```

The app always runs from compiled output: every run (dev, start, prod) is `tsc` → `node ./dist/server.js`.

Health check: `GET /api/v1/health`

## Scripts

| Script                                              | Description                                      |
| --------------------------------------------------- | ------------------------------------------------ |
| `npm run dev`                                       | Watch mode: rebuild + restart `./dist` on change |
| `npm start`                                         | Build then run `./dist/server.js`                |
| `npm run start:prod`                                | Run `./dist/server.js` (assumes already built)   |
| `npm run build`                                     | Clean `dist/` and compile                        |
| `npm run lint` / `lint:fix`                         | ESLint                                           |
| `npm run format`                                    | Prettier                                         |
| `npm run typecheck`                                 | TypeScript no-emit check                         |
| `npm run migration:generate -- src/migrations/Name` | Generate a migration                             |
| `npm run migration:run` / `migration:revert`        | Apply / revert                                   |

## Structure

```
src/
  app.ts               # express app assembly (middleware, routes, errors)
  server.ts            # entrypoint: DB init + http server + graceful shutdown
  routes.ts            # mounts every module router under API_PREFIX
  config/              # env parsing, TypeORM DataSource
  entities/            # TypeORM entities (BaseEntity, User w/ platform roles)
  modules/             # one folder per feature module:
    health/            #   health.route.ts / health.controller.ts / health.service.ts / health.dto.ts
    users/             #   users.route.ts / users.controller.ts / users.service.ts / users.dto.ts (zod)
  i18n/                # it/en catalogs + t(); only `success` and `error` are objects, all other keys flat
  middlewares/         # error handler, 404, zod validation, locale detection, authorize(roles), rate limiting
  utils/               # winston logger, ApiError, pagination helpers
  migrations/          # TypeORM migrations
```

To add a module: create `src/modules/<name>/` with the four files (route, controller, service, dto) and mount its router in `src/routes.ts`.

Notes:

- `synchronize` is ON in development only; use migrations for production.
- User roles follow the analysis document: `employee`, `company` (1st-level admin), `fiduciary` (2nd-level admin), `super_admin`.
