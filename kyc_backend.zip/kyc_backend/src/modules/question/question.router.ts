import { Router } from 'express';
import { validate } from '../../middlewares/validate';
import { idParamSchema } from '../../utils/object-id';
import { QuestionController } from './question.controller';

const router = Router();

router.get('/', QuestionController.list);
router.get('/:id', validate({ params: idParamSchema }), QuestionController.getById);

export default router;
