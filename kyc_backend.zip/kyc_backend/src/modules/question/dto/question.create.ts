import { z } from 'zod';
import { QuestionType } from '../../../lib/enum';
import { objectIdSchema } from '../../../utils/object-id';
import { paginationQuerySchema } from '../../../utils/pagination';

export const questionCreateSchema = z.object({
  deviceId: objectIdSchema,
  title: z.string().trim().min(1, 'Title is required'),
  type: z.enum(QuestionType).optional(),
  step: z.number().int().positive().optional(),
  sortOrder: z.number().int().nonnegative().optional(),
  isActive: z.boolean().optional(),
});

export const questionUpdateSchema = questionCreateSchema.partial();

/** Drag-to-reorder sends the whole step back in its new order. */
export const questionReorderSchema = z.object({
  items: z
    .array(
      z.object({
        id: objectIdSchema,
        sortOrder: z.number().int().nonnegative(),
        step: z.number().int().positive().optional(),
      }),
    )
    .min(1, 'Nothing to reorder'),
});

export const questionListQuerySchema = paginationQuerySchema.extend({
  search: z.string().trim().min(1).optional(),
  deviceId: objectIdSchema.optional(),
  type: z.enum(QuestionType).optional(),
  // Query values arrive as strings, so "false" has to be coerced explicitly —
  // z.coerce.boolean() would read the string "false" as true.
  isActive: z
    .enum(['true', 'false'])
    .transform((value) => value === 'true')
    .optional(),
  sortBy: z.enum(['step', 'sortOrder', 'title', 'createdAt']).default('createdAt'),
});

export type QuestionCreateDto = z.infer<typeof questionCreateSchema>;
export type QuestionUpdateDto = z.infer<typeof questionUpdateSchema>;
export type QuestionReorderDto = z.infer<typeof questionReorderSchema>;
export type QuestionListQuery = z.infer<typeof questionListQuerySchema>;
