import { Model } from '../../model/model.model';
import { ModelStorage } from '../../model/model-storage.model';
import { CursorPaginationQuery, paginateCursor, toCursorFilter } from '../../utils/pagination';
import { findLiveBySlug } from '../../utils/query';

const STORAGE_POPULATE = {
  path: 'storageId',
  match: { isDeleted: false },
  select: '_id ram rom slug',
};

export class ModelStorageService {
  static async listByModelSlug(modelSlug: string, query: CursorPaginationQuery) {
    const deviceModel = await findLiveBySlug(Model, modelSlug, 'Model');
    const filter = {
      modelId: deviceModel._id,
      ...toCursorFilter(query.cursor),
    };

    const storages = await ModelStorage.find(filter)
      .select('_id storageId basePrice')
      .populate(STORAGE_POPULATE)
      .sort({ _id: 1 })
      .limit(query.limit + 1)
      .lean();

    const page = paginateCursor(storages, query.limit);

    return {
      ...page,
      data: page.data.filter((storage) => storage.storageId),
    };
  }
}
