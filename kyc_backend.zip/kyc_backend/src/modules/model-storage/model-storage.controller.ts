import { NextFunction, Request, Response } from 'express';
import { ResponseHandler } from '../../helper/response.handler';
import { ModelStorageService } from './model-storage.service';
import { modelStorageListQuerySchema } from './dto/index.dto';

export class ModelStorageController {
  static async listByModelSlug(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = modelStorageListQuerySchema.parse(req.query);
      const { data, ...meta } = await ModelStorageService.listByModelSlug(
        req.params.slug as string,
        query,
      );
      ResponseHandler.cursorPaginated(res, 'Model storages fetched successfully', data, meta);
    } catch (error) {
      next(error);
    }
  }
}
