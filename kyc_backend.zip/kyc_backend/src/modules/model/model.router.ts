import { Router } from 'express';
import { validate } from '../../middlewares/validate';
import { idParamSchema } from '../../utils/object-id';
import { ModelController } from './model.controller';
import { brandSlugParamSchema } from '../../utils/slug';

const router = Router();

router.get('/', ModelController.list);
router.get('/:id', validate({ params: idParamSchema }), ModelController.getById);
router.get('/all/:slug', validate({ params: brandSlugParamSchema }), ModelController.listByBrandSlug);

export default router;
