import { NextFunction, Request, Response } from 'express';
import { ResponseHandler } from '../../helper/response.handler';
import { cursorPaginationQuerySchema } from '../../utils/pagination';
import { ModelService } from './model.service';
import { modelListQuerySchema } from './dto/index.dto';

export class ModelController {
  static async list(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = modelListQuerySchema.parse(req.query);
      const { models, meta } = await ModelService.list(query);
      ResponseHandler.paginated(res, 'Models fetched successfully', models, meta);
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const model = await ModelService.getById(req.params.id as string);
      ResponseHandler.success(res, 'Model fetched successfully', model);
    } catch (error) {
      next(error);
    }
  }

  // static async listByBrandSlug(req: Request, res: Response, next: NextFunction): Promise<void> {
  //   try {
  //     const query = cursorPaginationQuerySchema.parse(req.query);
  //     const { data, ...meta } = await ModelService.listByDeviceSlug(
  //       req.params.deviceSlug as string,
  //       query,
  //     );
  //     ResponseHandler.cursorPaginated(res, 'Models fetched successfully', data, meta);
  //   } catch (error) {
  //     next(error);
  //   }
  // }

  static async listByBrandSlug(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = cursorPaginationQuerySchema.parse(req.query);
      const { data, ...meta } = await ModelService.listByBrandSlug(
        req.params.slug as string,
        query,
      );
      ResponseHandler.cursorPaginated(res, 'Models fetched successfully', data, meta);
    } catch (error) {
      next(error);
    }
  }
}
