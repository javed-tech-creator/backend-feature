import type { Metadata } from "next";
import { siteConfig } from "@/lib/seo";

export const metadata: Metadata = {
  title: "Contact Us",
  description: `Get in touch with ${siteConfig.name}. Call ${siteConfig.phone} for help selling your old phone, tablet, laptop or gadget, or to track a scheduled pickup.`,
  alternates: { canonical: "/contact-us" },
  openGraph: {
    title: `Contact Us | ${siteConfig.name}`,
    description: `Get in touch with ${siteConfig.name} for help selling your old device or tracking a pickup.`,
    url: "/contact-us",
  },
};

const Contact = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold text-heading">Contact Us</h1>
    </div>
  );
};

export default Contact;
