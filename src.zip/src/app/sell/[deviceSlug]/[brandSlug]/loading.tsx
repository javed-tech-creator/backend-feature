import Loading from "@/components/Loading";

export default function BrandLoading() {
  return <Loading message="Loading models..." />;
}
