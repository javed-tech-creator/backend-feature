import type { Metadata } from "next";
import { quickLinks } from "@/lib/constant";
import { siteConfig } from "@/lib/seo";
import { deviceLabel } from "@/helper/common.helper";
import { getBrandModels } from "@/api/device.api";
import ModelList from "@/components/BrandModels";

type BrandParams = {
  deviceSlug: string;
  brandSlug: string;
};

function label(device: string, brand: string) {
  const known = quickLinks.find(
    (item) =>
      item.device === device.toLowerCase() && item.name === brand.toLowerCase(),
  );
  if (known) {
    return known.name;
  }

  return brand
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

export async function generateMetadata({
  params,
}: {
  params: Promise<BrandParams>;
}): Promise<Metadata> {
  const { deviceSlug, brandSlug } = await params;

  const name = label(deviceSlug, brandSlug);
  const type = deviceLabel(deviceSlug);

  const title = `Sell Old ${name} ${type} Online for Instant Cash`;

  const description = `Sell your old ${name} ${type.toLowerCase()} at the best price with ${siteConfig.name}. Get an instant quote, free doorstep pickup and instant payment.`;

  const canonical = `/sell/${type}/${brandSlug}`;

  return {
    title,
    description,
    alternates: {
      canonical,
    },
    openGraph: {
      title: `${title} | ${siteConfig.name}`,
      description,
      url: canonical,
    },
  };
}

const BrandPage = async ({ params }: { params: Promise<BrandParams> }) => {
  const { deviceSlug, brandSlug } = await params;

  const response = await getBrandModels({
    device: deviceSlug,
    brand: brandSlug,
    limit: 24,
  });

  return (
    <div>
      {/* Later you can show devices here */}
      {!response.success ? (
        <div className="flex min-h-50 items-center justify-center px-4">
          <p className="text-center text-sm text-red-500 sm:text-base">
            No Data Available
          </p>
        </div>
      ) : (
        <ModelList
          models={response.data.data}
          hasMore={response.data.hasMore}
          nextCursor={response.data.nextCursor}
          deviceSlug={deviceSlug}
          brandSlug={brandSlug}
        />
      )}
    </div>
  );
};

export default BrandPage;
