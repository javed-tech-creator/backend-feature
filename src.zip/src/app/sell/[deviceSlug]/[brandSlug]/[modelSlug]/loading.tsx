import Loading from "@/components/Loading";

export default function ModelLoading() {
  return <Loading message="Loading variants..." />;
}
