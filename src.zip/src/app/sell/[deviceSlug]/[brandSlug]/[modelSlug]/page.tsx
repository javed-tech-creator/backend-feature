import type { Metadata } from "next";
import { siteConfig } from "@/lib/seo";
import { label, deviceLabel } from "@/helper/common.helper";
import { getModelDetails } from "@/api/device.api";
import type { ModelParams } from "@/lib/types";
import StorageList from "@/components/StorageList";

export async function generateMetadata({
  params,
}: {
  params: Promise<ModelParams>;
}): Promise<Metadata> {
  const { deviceSlug, brandSlug, modelSlug } = await params;

  const type = deviceLabel(deviceSlug);
  const brand = label(brandSlug);
  const model = label(modelSlug);

  const title = `Sell Old ${brand} ${model} Online for Instant Cash`;

  const description = `Sell your old ${brand} ${model} ${type.toLowerCase()} at the best price with ${siteConfig.name}. Get an instant quote, free doorstep pickup and instant payment.`;

  const canonical = `/sell/${deviceSlug}/${brandSlug}/${modelSlug}`;

  return {
    title,
    description,
    alternates: {
      canonical,
    },
    openGraph: {
      title: `${title} | ${siteConfig.name}`,
      description,
      url: canonical,
    },
  };
}

const ModelPage = async ({ params }: { params: Promise<ModelParams> }) => {
  const { deviceSlug, brandSlug, modelSlug } = await params;


  const response = await getModelDetails({
    model: modelSlug,
  });

  if (!response.success || !response.data) {
    return (
      <div className="flex min-h-50 items-center justify-center px-4">
        <p className="text-center text-sm text-red-500 sm:text-base">
          Model data not found.
        </p>
      </div>
    );
  }

 return (
    <StorageList
      model={response.data.model}
      storages={response.data.data}
      deviceSlug={deviceSlug}
      brandSlug={brandSlug}
      modelSlug={modelSlug}
    />
  );
};

export default ModelPage;
