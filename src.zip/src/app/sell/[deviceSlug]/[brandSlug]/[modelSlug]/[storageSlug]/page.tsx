import type { Metadata } from "next";
import { siteConfig } from "@/lib/seo";
import { deviceLabel, label } from "@/helper/common.helper";
import type { StorageParams } from "@/lib/types";
import { getModelDetails } from "@/api/device.api";
import { getDeviceIdBySlug } from "@/api/questionnaire.api";
import StorageComponent from "@/components/StorageComponent";

export async function generateMetadata({
  params,
}: {
  params: Promise<StorageParams>;
}): Promise<Metadata> {
  const { deviceSlug, brandSlug, modelSlug, storageSlug } = await params;

  const type = deviceLabel(deviceSlug);
  const brand = label(brandSlug);
  const model = label(modelSlug);
  const storage = label(storageSlug);

  const title = `Sell ${brand} ${model} ${storage} Online for Instant Cash`;

  const description = `Sell your ${brand} ${model} ${storage} ${type.toLowerCase()} at the best price with ${siteConfig.name}. Get an instant quote, free doorstep pickup and instant payment.`;

  const canonical = `/sell/${deviceSlug}/${brandSlug}/${modelSlug}/${storageSlug}`;

  return {
    title,
    description,
    alternates: {
      canonical,
    },
    openGraph: {
      title: `${title} | ${siteConfig.name}`,
      description,
      url: canonical,
    },
  };
}

const StoragePage = async ({ params }: { params: Promise<StorageParams> }) => {
  const { deviceSlug, brandSlug, modelSlug, storageSlug } = await params;

  // const type = deviceLabel(deviceSlug);
  const brand = label(brandSlug);
  const model = label(modelSlug);
  // const storage = label(storageSlug);

  const response = await getModelDetails({
    model: modelSlug,
  });

  const deviceId = await getDeviceIdBySlug(deviceSlug);

  if (!response.success || !response.data) {
    return (
      <div className="flex min-h-50 items-center justify-center px-4">
        <p className="text-center text-sm text-red-500 sm:text-base">
          Phone variant not found.
        </p>
      </div>
    );
  }

  if (!deviceId) {
    return (
      <div className="flex min-h-50 items-center justify-center px-4">
        <p className="text-center text-sm text-red-500 sm:text-base">
          Device category not found.
        </p>
      </div>
    );
  }

  return (
    <StorageComponent
      modelData={response.data.model}
      storages={response.data.data}
      brand={brand}
      model={model}
      storageSlug={storageSlug}
      deviceSlug={deviceSlug}
      brandSlug={brandSlug}
      modelSlug={modelSlug}
      deviceId={deviceId}
    />
  );
};

export default StoragePage;
