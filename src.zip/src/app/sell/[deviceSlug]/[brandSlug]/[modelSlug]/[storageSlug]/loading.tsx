import Loading from "@/components/Loading";

export default function StorageLoading() {
  return <Loading message="Loading device details..." />;
}
