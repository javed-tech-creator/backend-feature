import type { Metadata } from "next";
import { siteConfig } from "@/lib/seo";
import { deviceLabel } from "@/helper/common.helper";
import { getBrands } from "@/api/device.api";
import BrandList from "@/components/DeviceBrands";

type DeviceParams = {
  deviceSlug: string;
};

export async function generateMetadata({
  params,
}: {
  params: Promise<DeviceParams>;
}): Promise<Metadata> {
  const { deviceSlug } = await params;

  const name = deviceLabel(deviceSlug);

  const title = `Sell Old ${name} Online for Instant Cash`;

  const description = `Sell your old ${name.toLowerCase()} at the best price with ${siteConfig.name}. Get an instant quote, free doorstep pickup and instant payment.`;

  const canonical = `/sell/${name}`;

  return {
    title,
    description,
    alternates: {
      canonical,
    },
    openGraph: {
      title: `${title} | ${siteConfig.name}`,
      description,
      url: canonical,
    },
  };
}

const DevicePage = async ({ params }: { params: Promise<DeviceParams> }) => {
  const { deviceSlug } = await params;
  const response = await getBrands({
    slug: deviceSlug,
    limit: 24,
  });

  return (
    <div>
      {/* Later you can show brands here */}
      {!response.success ? (
        <div className="flex min-h-50 items-center justify-center px-4">
          <p className="text-center text-sm text-red-500 sm:text-base">
            No Data Available
          </p>
        </div>
      ) : (
        <BrandList
          brands={response.data.data}
          hasMore={response.data.hasMore}
          nextCursor={response.data.nextCursor}
          deviceSlug={deviceSlug}
        />
      )}
    </div>
  );
};

export default DevicePage;
