import Loading from "@/components/Loading";

export default function DeviceLoading() {
  return <Loading message="Loading brands..." />;
}
