import type { Metadata } from "next";
import Questionnaire from "@/components/Questionnaire";
import { siteConfig } from "@/lib/seo";
import { getSession } from "@/services/session";

export const metadata: Metadata = {
  title: "Device Condition Check",
  description: `Answer a few questions about your device to get an assured selling price from ${siteConfig.name}.`,
  alternates: {
    canonical: "/sell/questionnaire",
  },
  openGraph: {
    title: `Device Condition Check | ${siteConfig.name}`,
    description: `Answer a few questions about your device to get an assured selling price from ${siteConfig.name}.`,
    url: "/sell/questionnaire",
  },
};

const QuestionnairePage = async () => {
  const session = await getSession();

  return <Questionnaire isLoggedIn={!!session?.token} />;
};

export default QuestionnairePage;
