import Loading from "@/components/Loading";

export default function QuestionnaireLoading() {
  return <Loading message="Loading questions..." />;
}
