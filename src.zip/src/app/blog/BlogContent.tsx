"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";
import {
  ArrowRight,
  Tag,
  Home,
  ChevronRight,
  BookOpen,
  CalendarDays,
} from "lucide-react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import formatDate from "@/utils/FormateDate";

// Register GSAP
gsap.registerPlugin(ScrollTrigger);

function BlogContent() {
  const blob1Ref = useRef(null);
  const blob2Ref = useRef(null);

  // --- API CALL ---
  const blogData = [
    {
      id: 1,
      title: "How to Sell Your Old Phone at the Best Price",
      slug: "how-to-sell-your-old-phone",
      image: "https://picsum.photos/id/180/800/500",
      device: "Mobile",
      author: "MobiZoo Team",
      updatedAt: "2026-07-12T10:30:00.000Z",
      createdAt: "2026-07-12T10:30:00.000Z",
      readTime: "5 min read",
      views: 2450,
      likes: 185,
      featured: true,
      description: `
      <p>Selling your old smartphone doesn't have to be difficult. Learn how to prepare your phone, compare offers, erase your personal data safely, and maximize its resale value with expert tips.</p>
    `,
    },

    {
      id: 2,
      title: "7 Things to Do Before Selling Your Laptop",
      slug: "things-to-do-before-selling-laptop",
      image: "https://picsum.photos/id/48/800/500",
      device: "Laptop",
      author: "MobiZoo Team",
      updatedAt: "2026-07-10T09:00:00.000Z",
      createdAt: "2026-07-10T09:00:00.000Z",
      readTime: "6 min read",
      views: 1820,
      likes: 124,
      featured: false,
      description: `
      <p>Before selling your laptop, back up important files, remove personal information, reset the operating system, and clean the device to increase its resale price.</p>
    `,
    },

    {
      id: 3,
      title: "Online vs Offline: Which is Better for Selling Devices?",
      slug: "online-vs-offline-device-selling",
      image: "https://picsum.photos/id/20/800/500",
      device: "Guide",
      author: "MobiZoo Team",
      updatedAt: "2026-07-08T12:00:00.000Z",
      createdAt: "2026-07-08T12:00:00.000Z",
      readTime: "4 min read",
      views: 1560,
      likes: 98,
      featured: false,
      description: `
      <p>Discover the advantages of selling your old gadgets online compared to local mobile shops. Compare pricing, convenience, pickup services, and payment options.</p>
    `,
    },

    {
      id: 4,
      title: "How Secure Data Wiping Protects Your Privacy",
      slug: "secure-data-wiping-guide",
      image: "https://picsum.photos/id/119/800/500",
      device: "Security",
      author: "MobiZoo Team",
      updatedAt: "2026-07-05T15:15:00.000Z",
      createdAt: "2026-07-05T15:15:00.000Z",
      readTime: "7 min read",
      views: 1980,
      likes: 145,
      featured: true,
      description: `
      <p>Protect your personal information by securely erasing your phone, laptop, or tablet before selling. Learn the safest methods for complete data removal.</p>
    `,
    },

    {
      id: 5,
      title: "Top Smartphones With the Best Resale Value",
      slug: "best-resale-smartphones-2026",
      image: "https://picsum.photos/id/160/800/500",
      device: "Resale Value",
      author: "MobiZoo Team",
      updatedAt: "2026-07-03T11:20:00.000Z",
      createdAt: "2026-07-03T11:20:00.000Z",
      readTime: "5 min read",
      views: 3150,
      likes: 276,
      featured: true,
      description: `
      <p>Explore the smartphones that offer the highest resale value in 2026, including iPhone, Samsung Galaxy, OnePlus, Google Pixel, and more.</p>
    `,
    },

    {
      id: 6,
      title: "Complete Checklist Before Selling Any Gadget",
      slug: "device-selling-checklist",
      image: "https://picsum.photos/id/250/800/500",
      device: "Tips",
      author: "MobiZoo Team",
      updatedAt: "2026-07-01T08:45:00.000Z",
      createdAt: "2026-07-01T08:45:00.000Z",
      readTime: "8 min read",
      views: 2740,
      likes: 192,
      featured: false,
      description: `
      <p>From removing accounts to cleaning accessories and checking warranty status, follow this complete checklist to sell your gadget quickly and at the best price.</p>
    `,
    },
  ];

  // --- Optimized Background Mouse Effect ---
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      if (blob1Ref.current) {
        gsap.to(blob1Ref.current, {
          x: clientX * 0.05,
          y: clientY * 0.05,
          duration: 2,
          ease: "power2.out",
        });
      }
      if (blob2Ref.current) {
        gsap.to(blob2Ref.current, {
          x: -clientX * 0.05,
          y: -clientY * 0.05,
          duration: 3,
          ease: "power2.out",
        });
      }
    };
    window.addEventListener("mousemove", handleMouseMove as EventListener);
    return () =>
      window.removeEventListener("mousemove", handleMouseMove as EventListener);
  }, []);

  // --- Animations ---
  useEffect(() => {
    // Header Animation
    gsap.fromTo(
      ".hero-animate",
      { opacity: 0, y: 30 },
      { opacity: 1, y: 0, duration: 1, stagger: 0.1, ease: "power3.out" },
    );

    // Blog Grid Animation
    if (blogData) {
      gsap.fromTo(
        ".blog-card",
        { opacity: 0, y: 50 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          stagger: 0.1,
          ease: "power2.out",
          scrollTrigger: {
            trigger: ".blog-grid",
            start: "top 90%",
          },
        },
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Removed blogData dependency to run once with dummy data

  // if (isLoading) {
  //   return (
  //     <div className="min-h-screen bg-[#111111] flex items-center justify-center">
  //       <Loader />
  //     </div>
  //   );
  // }

  // if (isError) {
  //   return (
  //     <div className="min-h-screen bg-[#111111] flex flex-col items-center justify-center font-chakra text-black">
  //       <div className="text-xl font-bold text-red-500 mb-4 font-chakra">
  //         Failed to load blogs
  //       </div>
  //       <button
  //         onClick={() => window.location.reload()}
  //         className="px-6 py-2 bg-white/10 hover:bg-white/20 rounded-full transition-all font-chakra"
  //       >
  //         Retry
  //       </button>
  //     </div>
  //   );
  // }

  return (
    <div className="relative min-h-screen bg-background overflow-hidden text-text ">
      <div className="relative z-10 pt-8 pb-12 lg:pt-10 lg:pb-12">
        <div className=" px-6 lg:px-20">
          {/* Breadcrumb & Header */}
          <div className="text-center mb-10">
            <h1 className="hero-animate text-2xl md:text-3xl lg:text-4xl font-black mb-3 leading-tight text-heading">
              Latest <span className="text-primary">News</span> &{" "}
              <span className="text-primary">Updates</span>
            </h1>
            <div className="h-1 w-32 bg-accent mx-auto mb-5"></div>

            <nav className="hero-animate inline-flex items-center gap-2 px-4 py-2 mb-6 rounded-full bg-surface backdrop-blur-sm border border-border text-sm text-text-light hover:border-primary/40 transition-all">
              <Link
                href="/"
                className="hover:text-primary flex items-center gap-1 transition-colors"
              >
                <Home className="w-3.5 h-3.5" /> Home
              </Link>

              <ChevronRight className="w-3 h-3 text-text-light" />
              <span className="text-heading font-medium">Blog & Insights</span>
            </nav>
          </div>

          {/* Blog Grid */}
          <div className="blog-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogData.map((post) => (
              <div
                key={post.id}
                className="blog-card group relative flex flex-col h-full bg-surface border border-border rounded-2xl overflow-hidden hover:border-primary/40 transition-all duration-300 hover:-translate-y-2 hover:shadow-lg"
              >
                {/* Image Section */}
                <div className="relative h-60 overflow-hidden">
                  <div className="absolute inset-0  bg-linear-to-t from-heading via-transparent to-transparent opacity-60 z-10" />

                  {/* Floating Date Badge */}
                  <div className="absolute top-4 left-4 z-20 bg-heading/70 backdrop-blur-md rounded-lg px-3 py-1 flex items-center gap-2 text-xs font-medium text-white">
                    <CalendarDays className="w-3 h-3" />
                    {formatDate(post?.updatedAt)}
                  </div>

                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={post?.image}
                    alt={post.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    loading="lazy"
                  />
                </div>

                {/* Content Section */}
                <div className="flex flex-col grow p-6">
                  {/* Device */}
                  <div className="absolute top-4 right-3 z-20">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-surface border border-border text-xs font-medium text-text">
                      <Tag className="w-3 h-3" />
                      {post?.device || "Technology"}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-bold text-heading mb-1 line-clamp-2 leading-snug group-hover:text-primary transition-colors">
                    {post.title}
                  </h3>

                  {/* Description (Stripped/Clamped) */}
                  <div className="text-text-light text-sm line-clamp-3 mb-6 grow">
                    <div
                      dangerouslySetInnerHTML={{ __html: post.description }}
                    />
                  </div>

                  {/* Footer / Read More */}
                  <div className="pt-4 border-t border-border mt-auto">
                    <Link
                      href={`/blog-detail/${post.slug}`}
                      className="inline-flex items-center text-sm font-bold text-primary transition-colors"
                    >
                      Read Full Article
                      <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Empty State */}
          {(!blogData || blogData.length === 0) && (
            <div className="text-center py-20 bg-surface border border-border rounded-3xl">
              <div className="w-20 h-20 bg-surface-alt rounded-full flex items-center justify-center mx-auto mb-6">
                <BookOpen className="w-10 h-10 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-heading mb-2">
                No articles found
              </h3>
              <p className="text-text-light">
                Check back later for new updates.
              </p>
            </div>
          )}
        </div>
      </div>

      <style>{`
        .animate-gradient-x { background-size: 200% 200%; animation: gradient-move 5s ease infinite; }
        @keyframes gradient-move { 0% { background-position: 0% 50% } 50% { background-position: 100% 50% } 100% { background-position: 0% 50% } }
      `}</style>
    </div>
  );
}

export default BlogContent;
