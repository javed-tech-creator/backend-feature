import type { Metadata } from "next";
import BlogContent from "./BlogContent";
import { siteConfig } from "@/lib/seo";

const description =
  "Expert tips, resale guides and the latest insights to help you sell your old phones, laptops, tablets and gadgets for the best possible value.";

export const metadata: Metadata = {
  title: "Blog — News, Guides & Resale Tips",
  description,
  alternates: { canonical: "/blog" },
  openGraph: {
    type: "website",
    title: `Blog — News, Guides & Resale Tips | ${siteConfig.name}`,
    description,
    url: "/blog",
  },
};

// BlogContent is a client component (GSAP animations), so it can't export
// metadata itself — this server component supplies it.
export default function BlogPage() {
  return <BlogContent />;
}
