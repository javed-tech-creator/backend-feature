import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@/index.css";
import "@fontsource/poppins/300.css";
import "@fontsource/poppins/400.css";
import "@fontsource/poppins/500.css";
import "@fontsource/poppins/600.css";
import "@fontsource/poppins/700.css";
import "@fontsource/poppins/800.css";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Footer } from "@/components";
import { siteConfig } from "@/lib/seo";
import { Toaster } from "react-hot-toast";
import { getSession } from "@/services/session";
import { Navbar } from "@/components/Navbar";
import { logoutAction } from "@/api/api";
import QuickLinks from "@/components/QuickLinks";

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.url),
  title: {
    default: `${siteConfig.name} — ${siteConfig.title}`,
    // Pages set only their own title; the brand suffix is appended here.
    template: `%s | ${siteConfig.name}`,
  },
  description: siteConfig.description,
  applicationName: siteConfig.name,
  keywords: [
    "sell old phone",
    "sell mobile online",
    "sell old laptop",
    "sell tablet",
    "sell smartwatch",
    "instant cash for phone",
    "doorstep pickup",
    siteConfig.name,
  ],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    siteName: siteConfig.name,
    locale: siteConfig.locale,
    url: siteConfig.url,
    title: `${siteConfig.name} — ${siteConfig.title}`,
    description: siteConfig.description,
  },
  twitter: {
    card: "summary_large_image",
    title: `${siteConfig.name} — ${siteConfig.title}`,
    description: siteConfig.description,
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
  icons: { icon: "/favicon.svg" },
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const session = await getSession();
  const user = session?.user ?? null;

    const isLoggedIn = !!session?.token;
  
  return (
    <html lang="en">
      <body>
        <div className="min-h-screen flex flex-col">
          <Navbar isLoggedIn={isLoggedIn} logout={logoutAction} user={user} />

          <main className="flex-1 ">{children}</main>
          <QuickLinks/>
          <Footer />
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 3000,
            }}
          />
        </div>
      </body>
    </html>
  );
}
