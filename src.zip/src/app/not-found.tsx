import Link from "@/components/Link";

export default function NotFound() {
  return (
    <section className="bg-surface-alt py-20">
      <div className="px-4.5 md:px-0 max-w-xl mx-auto text-center">
        <p className="text-xs font-semibold tracking-[0.2em] text-primary">
          ERROR 404
        </p>

        <h1 className="mt-3 text-2xl md:text-4xl font-bold text-heading leading-tight">
          Page <span className="text-primary">not found</span>
        </h1>

        <p className="mt-2 text-text-light leading-relaxed">
          The page you are looking for doesn&apos;t exist or has been moved.
          Head back to the homepage to sell your phone, tablet, laptop or
          gadget.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/"
            title="Home"
            className="h-10 px-6 rounded-md flex items-center border border-primary cursor-pointer text-white bg-primary transition"
          >
            Back to Home
          </Link>

          <Link
            href="/login-with-otp"
            title="Login"
            className="h-10 px-6 rounded-md flex items-center border border-primary cursor-pointer text-primary hover:bg-primary hover:text-white transition"
          >
            Login
          </Link>
        </div>
      </div>
    </section>
  );
}
