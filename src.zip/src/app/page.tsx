import type { Metadata } from "next";
import ClientTestimonials from "@/components/ClientTestmonials";
import HeroSlider from "@/components/HeroSlider";
import LatestArticlesSection from "@/components/LatestArticle";
import ProductBrands from "@/components/ProductBrand";
// import QuickLinks from "@/components/QuickLinks";
import SellCategories from "@/components/SellCategories";
import HowItWorks from "@/components/StepProcess";
import WhatWeDoBest from "@/components/WeDoBest";
import WhyTrustUs from "@/components/WhyPeopleTrustUs";
import { absoluteUrl, siteConfig } from "@/lib/seo";

export const metadata: Metadata = {
  // Home keeps the full brand title rather than the "%s | MyPhoneCash" template.
  title: `${siteConfig.name} — ${siteConfig.title}`,
  description: siteConfig.description,
  alternates: { canonical: "/" },
};

// Organization + WebSite tell search engines who publishes the site and how the
// brand relates to its social profiles.
const jsonLd = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": absoluteUrl("/#organization"),
      name: siteConfig.name,
      url: siteConfig.url,
      description: siteConfig.description,
      sameAs: siteConfig.social,
      contactPoint: {
        "@type": "ContactPoint",
        telephone: siteConfig.phone,
        contactType: "customer service",
        areaServed: "IN",
        availableLanguage: ["en", "hi"],
      },
    },
    {
      "@type": "WebSite",
      "@id": absoluteUrl("/#website"),
      url: siteConfig.url,
      name: siteConfig.name,
      description: siteConfig.description,
      publisher: { "@id": absoluteUrl("/#organization") },
      inLanguage: "en-IN",
    },
  ],
};

export default function Home() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      {/*
        The banner artwork carries this message visually, so the h1 is exposed to
        screen readers and crawlers without changing the hero's design.
      */}
      <h1 className="sr-only">
        {siteConfig.name} — {siteConfig.title}
      </h1>

      {/* Banner */}
      <HeroSlider />
      <SellCategories />
      <HowItWorks />
      <WhyTrustUs />
      <WhatWeDoBest />
      <ProductBrands />
      <ClientTestimonials />
      <LatestArticlesSection />
      {/* <QuickLinks /> */}
    </>
  );
}
