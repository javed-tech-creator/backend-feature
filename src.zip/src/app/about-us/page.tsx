import type { Metadata } from "next";
import { siteConfig } from "@/lib/seo";
import Link from "next/link";
import {
  ShieldCheck,
  Truck,
  Wallet,
  Recycle,
  Clock,
  MapPin,
  BadgeIndianRupee,
  CheckCircle2,
  ArrowRight,
  Sparkles,
} from "lucide-react";

export const metadata: Metadata = {
  title: "About Us",
  description: `Learn about ${siteConfig.name} — India's trusted platform to sell old phones, tablets, laptops and gadgets for instant cash with free doorstep pickup.`,
  alternates: { canonical: "/about-us" },
  openGraph: {
    title: `About Us | ${siteConfig.name}`,
    description: `Learn about ${siteConfig.name} — India's trusted platform to sell old phones, tablets, laptops and gadgets for instant cash.`,
    url: "/about-us",
  },
};

// ---------------------------------------------------------------------------
// Static content — swap with real copy / CMS data as needed
// ---------------------------------------------------------------------------

const stats: { value: string; label: string }[] = [
  { value: "4.2L+", label: "Devices resold" },
  { value: "60 sec", label: "Avg. quote time" },
  { value: "120+", label: "Cities covered" },
  { value: "4.8/5", label: "Customer rating" },
];

const steps: { title: string; description: string; icon: React.ReactNode }[] = [
  {
    title: "Tell us about your device",
    description:
      "Answer a few quick questions about the brand, model, and condition. Our pricing engine gives you a fair quote in under a minute.",
    icon: <BadgeIndianRupee className="h-6 w-6" />,
  },
  {
    title: "We pick it up, free",
    description:
      "Book a pickup slot that works for you. Our verified agent inspects the device at your doorstep — no courier, no waiting in line.",
    icon: <Truck className="h-6 w-6" />,
  },
  {
    title: "Get paid instantly",
    description:
      "Once the device is verified, payment lands in your account on the spot. No follow-ups, no deductions you didn't agree to.",
    icon: <Wallet className="h-6 w-6" />,
  },
];

const values: { title: string; description: string; icon: React.ReactNode }[] =
  [
    {
      title: "Price you can trust",
      description:
        "Our quotes are built from live resale data, not guesswork — so the number you see is the number you get.",
      icon: <ShieldCheck className="h-6 w-6" />,
    },
    {
      title: "Your data, wiped clean",
      description:
        "Every device goes through certified, irreversible data erasure before it's resold or recycled. Nothing of yours travels with it.",
      icon: <CheckCircle2 className="h-6 w-6" />,
    },
    {
      title: "Less e-waste, more reuse",
      description:
        "Devices that can be refurbished get a second life. The rest are recycled responsibly through certified partners.",
      icon: <Recycle className="h-6 w-6" />,
    },
    {
      title: "We show up on time",
      description:
        "Pickup slots are real commitments. Our agents track ETAs so you're never left waiting around for a doorbell that doesn't ring.",
      icon: <Clock className="h-6 w-6" />,
    },
  ];

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function AboutPage() {
  return (
    <>
      {/* Hero     */}
      <section className="relative overflow-hidden bg-linear-to-br from-[#0A2E4D] via-[#0E4A78] to-[#1C7FBE]">
        {/* dotted texture, echoes homepage hero */}
        <div
          aria-hidden
          className="pointer-events-none absolute left-0 top-0 h-64 w-64 opacity-20 [background-image:radial-gradient(theme(colors.white)_1px,transparent_1px)] [background-size:22px_22px]"
        />
        <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 px-6 py-5 md:grid-cols-2 md:py-10">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wide text-blue-100 ring-1 ring-white/20">
              <Sparkles className="h-3.5 w-3.5" />
              Our story
            </span>
            <h1 className="mt-5 text-4xl font-extrabold leading-tight text-white sm:text-5xl">
              We built the reselling
              <br />
              experience we wished{" "}
              <span className="text-amber-400">existed</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-blue-100">
              MobiZoo started with one frustration: selling an old phone meant
              haggling with strangers or waiting weeks for a courier. So we
              built a service that gives you a fair price, picks up at your
              door, and pays you before the agent leaves.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link
                href="/sell-phone"
                className="inline-flex items-center gap-2 rounded-full bg-amber-400 px-6 py-2 font-semibold text-[#0A2E4D] transition hover:bg-amber-300"
              >
                Get Instant Quote
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                href="/contact-us"
                className="inline-flex items-center gap-2 rounded-full border border-white/30 px-6 py-2 font-semibold text-white transition hover:bg-white/10"
              >
                Talk to us
              </Link>
            </div>
          </div>

          {/* Signature element: a "promise ledger" card, echoing the
              homepage's floating value-card motif */}
          <div className="relative mx-auto w-full max-w-sm">
            <div className="rounded-2xl bg-white p-6 shadow-2xl">
              <p className="text-sm font-medium text-slate-500">
                Our promise, in numbers
              </p>
              <ul className="mt-4 divide-y divide-slate-100">
                {stats.map((s) => (
                  <li
                    key={s.label}
                    className="flex items-center justify-between py-3"
                  >
                    <span className="text-sm text-slate-500">{s.label}</span>
                    <span className="text-lg font-bold text-[#0E4A78]">
                      {s.value}
                    </span>
                  </li>
                ))}
              </ul>
              <div className="mt-4 flex items-center gap-2 rounded-xl bg-blue-50 px-3 py-2 text-xs font-medium text-[#0E4A78]">
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                Updated live from completed pickups
              </div>
            </div>
            {/* floating coin accent, matches homepage iconography */}
            <div className="absolute -right-4 -top-4 flex h-14 w-14 items-center justify-center rounded-full bg-amber-400 shadow-lg">
              <BadgeIndianRupee className="h-6 w-6 text-[#0A2E4D]" />
            </div>
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="bg-surface-alt  px-6 py-10 text-center">
        <div className="mx-auto max-w-4xl">
          <h2 className="text-3xl font-extrabold text-[#0A2E4D] sm:text-4xl">
            Sell for <span className="text-[#1C7FBE]">cash</span>, not for
            hassle
          </h2>
          <p className="mt-4 text-lg leading-relaxed text-slate-600">
            Every year, millions of usable phones sit in drawers because selling
            them felt like more trouble than it was worth. We exist to change
            that math — a fair quote in a minute, a pickup at your convenience,
            and payment before you've even closed the door.
          </p>
        </div>
      </section>

      {/* How it work*/}
      <section className="bg-background py-10">
        <div className="mx-auto max-w-7xl px-6">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-extrabold text-[#0A2E4D]">
              How MobiZoo works
            </h2>
            <p className="mt-3 text-slate-600">
              Three steps, start to payout — usually inside a day.
            </p>
          </div>

          <ol className="mt-14 grid grid-cols-1 gap-8 md:grid-cols-3">
            {steps.map((step, i) => (
              <li
                key={step.title}
                className="relative rounded-2xl bg-white p-8 shadow-sm ring-1 ring-slate-100"
              >
                <span className="absolute -top-4 left-8 flex h-8 w-8 items-center justify-center rounded-full bg-[#0E4A78] text-sm font-bold text-white">
                  {i + 1}
                </span>
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-[#0E4A78]">
                  {step.icon}
                </div>
                <h3 className="mt-5 text-lg font-bold text-[#0A2E4D]">
                  {step.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-600">
                  {step.description}
                </p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Values   */}
      <section className=" bg-surface-alt  px-6 py-10">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-extrabold text-[#0A2E4D]">
            What we hold ourselves to
          </h2>
          <p className="mt-3 text-slate-600">
            The parts of the experience we don't compromise on.
          </p>
        </div>

        <div className="mt-8 mx-auto max-w-7xl grid grid-cols-1 gap-6 sm:grid-cols-2">
          {values.map((v) => (
            <div
              key={v.title}
              className="flex gap-4 rounded-2xl border border-slate-100 p-6 transition hover:border-blue-100 hover:bg-blue-50/40"
            >
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#0E4A78] text-white">
                {v.icon}
              </div>
              <div>
                <h3 className="font-bold text-[#0A2E4D]">{v.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-slate-600">
                  {v.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Coverage */}

      <section className="bg-[#0A2E4D] py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-6 px-6 text-center md:flex-row md:text-left">
          <div className="flex items-center gap-3 text-white">
            <MapPin className="h-6 w-6 text-amber-400" />
            <p className="text-lg font-semibold">
              Free pickup available in 120+ cities across India
            </p>
          </div>
          <Link
            href="/sell-phone"
            className="inline-flex items-center gap-2 rounded-full bg-amber-400 px-6 py-2 font-semibold text-[#0A2E4D] transition hover:bg-amber-300"
          >
            Check my city
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* CTA      */}
      <section className="mx-auto max-w-4xl px-6 py-10 text-center">
        <h2 className="text-3xl font-extrabold text-[#0A2E4D] sm:text-4xl">
          Got a device sitting idle?
        </h2>
        <p className="mt-4 text-lg text-slate-600">
          Get your instant quote in under 60 seconds — no signup required to see
          the price.
        </p>
        <Link
          href="/sell-phone"
          className="mt-8 inline-flex items-center gap-2 rounded-full bg-amber-400 px-8 py-3 font-semibold text-[#0A2E4D]  transition hover:bg-amber-300"
        >
          Get Instant Quote
          <ArrowRight className="h-4 w-4" />
        </Link>
      </section>
    </>
  );
}
