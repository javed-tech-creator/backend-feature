import type { MetadataRoute } from "next";
import { absoluteUrl } from "@/lib/seo";

/**
 * Only pages with real content belong here.
 *
 * The ~70 /sell/[device]/[brand] URLs are deliberately excluded: they all
 * still render the same "Sell" stub, and submitting dozens of near-identical
 * thin pages invites duplicate-content demotion. Add them here (mapping over
 * `quickLinks` from lib/constant) once those pages render real content.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date();

  return [
    {
      url: absoluteUrl("/"),
      lastModified,
      changeFrequency: "weekly",
      priority: 1,
    },
    {
      url: absoluteUrl("/blog"),
      lastModified,
      changeFrequency: "weekly",
      priority: 0.8,
    },
    {
      url: absoluteUrl("/about-us"),
      lastModified,
      changeFrequency: "monthly",
      priority: 0.5,
    },
    {
      url: absoluteUrl("/contact-us"),
      lastModified,
      changeFrequency: "monthly",
      priority: 0.5,
    },
  ];
}
