import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { ImageResponse } from "next/og";
import { siteConfig } from "@/lib/seo";

// Placing this file in app/ makes Next emit og:image + twitter:image for every
// page that doesn't define its own. Rendered once at build time.
export const alt = `${siteConfig.name} — ${siteConfig.title}`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/**
 * Satori renders this at build time outside the browser, so it can't resolve the
 * CSS variables from index.css. These are literal copies of that @theme block and
 * must be updated alongside it.
 */
const theme = {
  primary: "#0284C7",
  secondary: "#FF6B35",
  accent: "#F6A94A",
  surfaceAlt: "#F0F9FF",
  heading: "#11135A",
  textLight: "#64748B",
};

/**
 * Match the site's Poppins. Satori reads woff (not woff2) and ignores
 * fontWeight unless the weight's own file is supplied. Falls back to the
 * built-in font rather than failing the build if the files ever move.
 */
async function poppins() {
  const file = (weight: number) =>
    join(
      process.cwd(),
      "node_modules/@fontsource/poppins/files",
      `poppins-latin-${weight}-normal.woff`,
    );

  try {
    const [regular, bold] = await Promise.all([
      readFile(file(400)),
      readFile(file(800)),
    ]);

    return [
      { name: "Poppins", data: regular, weight: 400 as const, style: "normal" as const },
      { name: "Poppins", data: bold, weight: 800 as const, style: "normal" as const },
    ];
  } catch {
    return undefined;
  }
}

export default async function OpengraphImage() {
  const fonts = await poppins();

  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          padding: "80px",
          background: theme.surfaceAlt,
          fontFamily: fonts ? "Poppins" : undefined,
        }}
      >
        <div
          style={{
            display: "flex",
            fontSize: 34,
            fontWeight: 700,
            color: theme.primary,
          }}
        >
          {siteConfig.name}
        </div>

        <div
          style={{
            display: "flex",
            marginTop: 24,
            fontSize: 68,
            fontWeight: 800,
            lineHeight: 1.15,
            color: theme.heading,
          }}
        >
          Sell Your Old Phone
        </div>

        <div
          style={{
            display: "flex",
            fontSize: 68,
            fontWeight: 800,
            lineHeight: 1.15,
            color: theme.accent,
          }}
        >
          For Instant Cash
        </div>

        <div
          style={{
            display: "flex",
            marginTop: 28,
            fontSize: 30,
            color: theme.textLight,
          }}
        >
          Best price · Free doorstep pickup · Instant payment
        </div>

        <div
          style={{
            display: "flex",
            marginTop: 44,
            height: 8,
            width: 220,
            background: theme.secondary,
          }}
        />
      </div>
    ),
    { ...size, fonts },
  );
}
