import type {
  CheckPhoneResponse,
  SendOtpResponse,
  VerifyOtpResponse,
} from "@/lib/types";
import { apiCall } from "./api";
import { setSession } from "@/services/session";

export async function checkPhone(phone: string) {
  return apiCall<CheckPhoneResponse>("/user/exist-phone", {
    method: "POST",
    body: JSON.stringify({
      phone,
    }),
    skipAuth: true,
  });
}

export async function sendOtp(data: {
  phone: string;
  fullName?: string;
  email?: string;
}) {
  return apiCall<SendOtpResponse>("/user/send-otp", {
    method: "POST",
    body: JSON.stringify(data),
    skipAuth: true,
  });
}

export async function verifyOtp(data: { phone: string; otp: string }) {
  try {
    const response = await apiCall<VerifyOtpResponse>("/user/verify-otp", {
      method: "POST",
      body: JSON.stringify(data),
      skipAuth: true,
    });

    // Backend returned error
    if (!response.success) {
      return {
        success: false,
        message: response.message || "OTP verification failed.",
        status: response.status || 400,
      };
    }

    // Backend response data
    const authData = response.data;

    // Token/user missing
    if (!authData?.token || !authData?.user) {
      return {
        success: false,
        message: "Invalid authentication response.",
        status: 500,
      };
    }

    // Store token + user in server-side cookies
    await setSession(authData.token, authData.user);

    // Only send success message to client
    return {
      success: true,
      message: response.message || "OTP verified successfully.",
      status: response.status || 200,
    };
  } catch (error) {
    console.error("Verify OTP route error:", error);

    return {
      success: false,
      message: "Something went wrong while verifying OTP.",
      status: 500,
    };
  }
}
