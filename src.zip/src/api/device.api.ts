import type {
  DeviceSearchData,
  DeviceSearchParams,
    GetBrandModelsData,
    GetBrandModelsParams,
    GetBrandModelsResponse,
    GetBrandsData,
    GetBrandsParams,
    GetBrandsResponse,
    GetModelDetailsData,
    GetModelDetailsParams,
} from "@/lib/types";
import { apiCall } from "./api";

export async function getBrands({ slug, limit = 24, cursor}: GetBrandsParams): Promise<GetBrandsResponse> {
  try {
    const params = new URLSearchParams({
      limit: String(limit),
    });

    if (cursor) {
      params.set("cursor", cursor);
    }

    const response = await apiCall<GetBrandsData>(
      `/brand/all/${encodeURIComponent(slug)}?${params.toString()}`,
      {
        method: "GET",
        skipAuth: true,
      }
    );

    if (!response.success) {
      return {
        success: false,
        message: response.message || "Failed to fetch brands.",
        status: response.status || 400,
        data: {
          data: [],
          nextCursor: null,
          hasMore: false,
        },
      };
    }

    return {
      success: true,
      message: response.message || "Brands fetched successfully.",
      status: response.status || 200,
      data: {
        data: response.data?.data || [],
        nextCursor: response.data?.nextCursor ?? null,
        hasMore: response.data?.hasMore ?? false,
      },
    };
  } catch (error) {
    console.error("Get brands error:", error);

    return {
      success: false,
      message: "Something went wrong while fetching brands.",
      status: 500,
      data: {
        data: [],
        nextCursor: null,
        hasMore: false,
      },
    };
  }
}

export async function getBrandModels({
    device,
    brand,
    limit = 24,
    cursor,
}: GetBrandModelsParams): Promise<GetBrandModelsResponse> {
    try {
        const params = new URLSearchParams({
            limit: String(limit),
        });

        if (cursor) {
            params.set("cursor", cursor);
        }

        const response = await apiCall<GetBrandModelsData>(
            `/model/all/${encodeURIComponent(device)}/${encodeURIComponent(brand)}?${params.toString()}`,
            {
                method: "GET",
                skipAuth: true,
            }
        );

        if (!response.success) {
            return {
                success: false,
                message: response.message || "Failed to fetch brand models.",
                status: response.status || 400,
                data: {
                    data: [],
                    nextCursor: null,
                    hasMore: false,
                },
            };
        }

        return {
            success: true,
            message:response.message || "Brand models fetched successfully.",
            status: response.status || 200,
            data: {
                data: response.data?.data || [],
                nextCursor: response.data?.nextCursor ?? null,
                hasMore: response.data?.hasMore ?? false,
            },
        };
    } catch (error) {
        console.error("Get brand models error:", error);

        return {
            success: false,
            message:"Something went wrong while fetching brand models.",
            status: 500,
            data: {
                data: [],
                nextCursor: null,
                hasMore: false,
            },
        };
    }
}

export async function getModelDetails({
  model,
}: GetModelDetailsParams) {
  return apiCall<GetModelDetailsData>(
    `/model-storages/all/${encodeURIComponent(model)}`,
    {
      method: "GET",
      skipAuth: true,
    },
  );
}

export async function getStorageDetails({
  device,
  brand,
  model,
  storage,
}: {
  device: string;
  brand: string;
  model: string;
  storage: string;
}) {
  return apiCall(
    `price/${encodeURIComponent(device)}/${encodeURIComponent(brand)}/${encodeURIComponent(model)}/${encodeURIComponent(storage)}`,
    {
      method: "GET",
    },
  );
}

export async function searchDevices({
  query,
}: DeviceSearchParams) {
  try {
    const params = new URLSearchParams({
      q: query,
    });

    const response = await apiCall<DeviceSearchData>(
      `/model/search?${params.toString()}`,
      {
        method: "GET",
        skipAuth: true,
      }
    );

    if (!response.success) {
      return {
        success: false,
        message: response.message || "Failed to search devices.",
        status: response.status || 400,
        data: {
          data: [],
        },
      };
    }

    return {
      success: true,
      message: response.message || "Devices fetched successfully.",
      status: response.status || 200,
      data: {
        data: response.data?.data || [],
      },
    };
  } catch (error) {
    console.error("Search devices error:", error);

    return {
      success: false,
      message: "Something went wrong while searching devices.",
      status: 500,
      data: {
        data: [],
      },
    };
  }
}