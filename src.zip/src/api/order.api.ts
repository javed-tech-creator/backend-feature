import type { CreateOrderPayload, Order } from "@/lib/types";
import { apiCall } from "./api";

export async function createSellOrder(payload: CreateOrderPayload) {
  return apiCall<Order>("/order", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}
