import type {
  CalculatePricePayload,
  GetDevicesData,
  PriceBreakdown,
  QuestionnaireData,
} from "@/lib/types";
import { apiCall } from "./api";

export async function getDevices() {
  return apiCall<GetDevicesData>("/device?limit=100", {
    method: "GET",
    skipAuth: true,
  });
}

export async function getDeviceIdBySlug(slug: string): Promise<string | null> {
  const response = await getDevices();

  if (!response.success || !response.data?.data) {
    return null;
  }

  const device = response.data.data.find((item) => item.slug === slug);
  return device?._id ?? null;
}

export async function getQuestionnaire(deviceId: string) {
  return apiCall<QuestionnaireData>(
    `/question/device/${encodeURIComponent(deviceId)}`,
    {
      method: "GET",
      skipAuth: true,
    },
  );
}

export async function calculatePrice(payload: CalculatePricePayload) {
  return apiCall<PriceBreakdown>("/calculator/calculate", {
    method: "POST",
    skipAuth: true,
    body: JSON.stringify(payload),
  });
}
