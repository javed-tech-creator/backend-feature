"use server";
import { SESSION_COOKIE } from "@/lib/constant";
import type { ApiCallOptions, ApiResponse } from "@/lib/types";
import { clearSession } from "@/services/session";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";

const API_URL = process.env.NEXT_PUBLIC_BACKEND_URL ?? "https://myphonecash.onrender.com";

export async function apiCall<T = unknown>(
  endpoint: string,
  options?: ApiCallOptions,
): Promise<ApiResponse<T>> {
  const cookieStore = await cookies();

  const token = cookieStore.get(SESSION_COOKIE)?.value;

  const apiEndpoint = [options?.basePath, endpoint]
    .filter(Boolean)
    .map((part) => String(part).replace(/^\/+|\/+$/g, ""))
    .join("/");

  const {
    basePath,
    skipAuth,
    headers: customHeaders,
    ...fetchOptions
  } = options || {};

  const headers = new Headers(customHeaders);

  headers.set("Content-Type", "application/json");

  if (!skipAuth && token) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  try {
    const response = await fetch(`${API_URL}/api/v1/${apiEndpoint}`, {
      ...fetchOptions,
      headers,
      cache: "no-store",
    });

    let result: any = null;

    try {
      result = await response.json();
    } catch {
      result = null;
    }

    if (!response.ok) {
      return {
        success: false,
        status: response.status,
        message: result?.message || result?.error || "Something went wrong",
        error: result?.message || result?.error || "Something went wrong",
      };
    }

    return {
      success: true,
      status: response.status,
      data: result?.data ?? result,
      message: result?.message,
    };
  } catch (error) {
    console.error("API Error:", error);

    return {
      success: false,
      message: error instanceof Error ? error.message : "Unknown error",
      error: "Unable to connect to the server",
    };
  }
}

export async function logoutAction() {
  await clearSession();
  redirect("/");
}
