"use server"
import { SESSION_COOKIE, SESSION_USER } from "@/lib/constant";
import type { AuthSession, SessionUser } from "@/lib/types";
import { cookies } from "next/headers";

export async function setSession(
  token: string,
  user: SessionUser
) {
  const cookieStore = await cookies();

  // Access token - HttpOnly
  cookieStore.set({
    name: SESSION_COOKIE,
    value: token,
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 7 * 24 * 60 * 60,
  });

  // User information - readable by client if required
  cookieStore.set({
    name: SESSION_USER,
    value: JSON.stringify(user),
    httpOnly: false,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 7 * 24 * 60 * 60,
  });
}

export async function getSession(): Promise<AuthSession | null> {
  const cookieStore = await cookies();

  const token = cookieStore.get(SESSION_COOKIE)?.value;
  const userRaw = cookieStore.get(SESSION_USER)?.value;

  if (!token || !userRaw) {
    return null;
  }

  try {
    const user = userRaw ? JSON.parse(userRaw) : null;

    return {
      token,
      user,
    };
  } catch {
    return null;
  }
}

export async function clearSession() {
  const cookieStore = await cookies();

  cookieStore.delete(SESSION_COOKIE);
  cookieStore.delete(SESSION_USER);
}
