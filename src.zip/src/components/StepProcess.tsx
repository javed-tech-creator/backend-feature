export default function HowItWorks() {
  const steps = [
    {
      number: "01",
      title: ["Search your device", "and get instant quote"],
      desc: "Find the item that you wish to sell/recycle then answer few questions on your device condition and get instant quote.",
    },
    {
      number: "02",
      title: ["Place pick up", "order and get pickup call"],
      desc: "Provide your details and choose a pick up date time slot to place an order with us. When you decide a pick up we will be there.",
    },
    {
      number: "03",
      title: ["Hurray - get cash", "and dont worry about it"],
      desc: "Get paid instantly on successful diagnosis of device and verification of your identity. Your device will go into safe hands.",
    },
  ];

  return (
    <section className="bg-background py-10 ">
      <div className="px-4.5 md:px-0 max-w-360 mx-auto text-center">
        {/* Heading with scribble accent */}
        <h2 className="relative inline-block text-2xl md:text-4xl font-bold text-heading leading-tight">
          Sell your device in just{" "}
          <span className="relative inline-block isolate">
            {/* 3 simple steps */}

            <svg
              viewBox="0 0 320 110"
              className="absolute -top-8 -right-6  w-[110%] inset-0 -z-10 h-auto pointer-events-none"
              fill="none"
            >
              <ellipse
                cx="160"
                cy="55"
                rx="150"
                ry="42"
                stroke="var(--color-primary)"
                strokeWidth="3"
                transform="rotate(-4 160 55)"
              />
              <ellipse
                cx="165"
                cy="58"
                rx="140"
                ry="36"
                stroke="var(--color-accent)"
                strokeWidth="3"
                transform="rotate(3 165 58)"
              />
            </svg>
            <span className="relative z-10 ">3 simple steps</span>
          </span>
        </h2>

        <p className="mt-2 text-text-light text-md max-w-xl mx-auto leading-relaxed">
          Book a free pickup from your home or work at a time slot as per your
          convenience
        </p>

        {/* Steps */}
        <div className="mt-10 grid md:grid-cols-3 gap-16 md:gap-10">
          {steps.map((step) => (
            <div key={step.number} className="flex flex-col items-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary text-white text-2xl font-bold shadow-lg shadow-primary/20">
                {step.number}
              </div>

              <h3 className="mt-4 text-xl font-normal text-heading leading-snug">
                {step.title[0]}
                <br />
                {step.title[1]}
              </h3>

              <p className="mt-3 text-text-light leading-relaxed max-w-xs">
                {step.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
