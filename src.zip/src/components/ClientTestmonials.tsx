"use client";

import { useState, useEffect } from "react";
import { Star } from "lucide-react";
import { FaArrowLeft, FaArrowRight } from "react-icons/fa";

export default function ClientTestimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials = [
    {
      id: 1,
      name: "Rahul Sharma",
      role: "Software Engineer",
      image: "https://i.pravatar.cc/150?img=12",
      rating: 5,
      text: "Selling my iPhone was incredibly easy. I received the quoted amount instantly after pickup.",
      device: "Sold iPhone 14",
    },
    {
      id: 2,
      name: "Priya Verma",
      role: "College Student",
      image: "https://i.pravatar.cc/150?img=47",
      rating: 5,
      text: "I sold my Dell laptop and got the best price with free doorstep pickup.",
      device: "Sold Dell Inspiron",
    },
    {
      id: 3,
      name: "Aman Khan",
      role: "Digital Marketer",
      image: "https://i.pravatar.cc/150?img=15",
      rating: 5,
      text: "Very transparent process. The evaluation matched the final payment.",
      device: "Sold Sumsung S23",
    },
    {
      id: 4,
      name: "Neha Singh",
      role: "Graphic Designer",
      image: "https://i.pravatar.cc/150?img=32",
      rating: 5,
      text: "Excellent service and fast payment. Highly recommended.",
      device: "Sold MacBook Air",
    },
    {
      id: 5,
      name: "Vikram Patel",
      role: "Business Owner",
      image: "https://i.pravatar.cc/150?img=67",
      rating: 5,
      text: "I've sold multiple devices here. Always a smooth experience.",
      device: "Sold OnePlus 12",
    },
    {
      id: 6,
      name: "Anjali Gupta",
      role: "Teacher",
      image: "https://i.pravatar.cc/150?img=49",
      rating: 5,
      text: "Their secure data wipe feature gave me complete peace of mind.",
      device: "Sold Vivo V30",
    },
  ];

  const nextSlide = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1,
    );
  };

  const prevSlide = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1,
    );
  };

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  //  Auto-slide added here
  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide();
    }, 4000); // Auto-slide every 4 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <section className=" bg-background py-10 overflow-hidden">
      <div className="px-4.5 md:px-0 max-w-360 mx-auto">
        <div className="text-center mb-6">
          <h2 className="text-2xl md:text-4xl font-bold text-heading leading-tight">
            What Our <span className="text-primary">Clients Say</span>
          </h2>
          <p className="mt-2 text-text-light max-w-2xl mx-auto">
            Thousands of customers trust MyPhoneCash to sell their old phones,
            laptops, tablets, smartwatches, and other gadgets with instant
            payment, free doorstep pickup, and secure data protection.
          </p>
        </div>
        {/* Testimonials Slider */}
        <div className="relative">
          <div className="relative overflow-hidden">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{
                transform: `translateX(-${currentIndex * (100 / 3)}%)`,
              }}
            >
              {testimonials.map((testimonial) => (
                <div
                  key={testimonial.id}
                  className="w-full md:w-1/2 lg:w-1/3 shrink-0 px-2 md:px-6"
                >
                  <div className="bg-surface border border-border rounded-2xl p-6 hover:border-primary hover:shadow-lg transition-all duration-300 h-full">
                    {/* Rating */}
                    <div className="flex mb-3">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star
                          key={i}
                          size={16}
                          className="fill-yellow-400 text-yellow-400"
                        />
                      ))}
                    </div>

                    {/* Review */}
                    <p className="text-sm text-text-light leading-6 line-clamp-4">
                      "{testimonial.text}"
                    </p>

                    {/* Device */}
                    <div className="mt-4">
                      <span className="inline-block rounded-full bg-primary/10 text-primary text-xs font-semibold px-3 py-1">
                        {testimonial.device}
                      </span>
                    </div>

                    {/* User */}
                    <div className="flex items-center gap-3 mt-5">
                      <img
                        src={testimonial.image}
                        alt={testimonial.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />

                      <div>
                        <h4 className="font-semibold text-heading text-sm">
                          {testimonial.name}
                        </h4>
                        <p className="text-xs text-text-light">
                          {testimonial.role}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Buttons */}
            {/* Navigation Buttons */}
            <button
              onClick={prevSlide}
              className="absolute left-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-primary/80 p-2 text-white shadow-md backdrop-blur-sm transition hover:bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white sm:left-4 sm:p-3"
            >
              <FaArrowLeft />
            </button>
            <button
              onClick={nextSlide}
              className=" absolute right-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-primary/80 p-2 text-white shadow-md backdrop-blur-sm transition hover:bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white sm:right-4 sm:p-3"
            >
              <FaArrowRight />
            </button>
          </div>
        </div>

        {/* Dots */}
        <div className="flex justify-center gap-2 mt-4">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`transition-all duration-300 rounded-full ${
                currentIndex === index
                  ? "bg-primary w-8 h-3"
                  : "bg-border w-3 h-3 hover:bg-text-light"
              }`}
              aria-label={`Go to testimonial ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
