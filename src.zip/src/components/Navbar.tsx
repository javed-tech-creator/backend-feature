"use client";

import { useState } from "react";
import { FaTimes, FaChevronDown } from "react-icons/fa";
import { IoSearchOutline } from "react-icons/io5";
import Link from "next/link";
import {
  Menu,
  Phone,
  Search,
  UserCircle,
  X,
  User,
  ShoppingBag,
  LogOut,
  ChevronDown,
} from "lucide-react";
import type { MenuItem } from "../lib/types";
import LoginOtpModal from "./LoginOtpModal";
import Image from "next/image";
import { useDeviceSearch } from "@/hooks/useDeviceSearch";

const menu: MenuItem[] = [
  {
    title: "Sell Phone",
    type: "mobile",
    items: [
      "Apple",
      "Samsung",
      "OnePlus",
      "Nothing",
      "Xiaomi",
      "Vivo",
      "Realme",
      "Oppo",
      "Other",
    ],
  },
  {
    title: "Sell Tablet",
    type: "tablet",
    items: ["Apple", "Samsung", "Micromax", "Asus"],
  },
  {
    title: "Sell Laptop",
    type: "laptop",
    items: ["Apple", "Samsung", "Xiaomi", "Micromax", "Lenovo"],
  },
  {
    title: "Sell Gadget",
    type: "gadget",
    items: ["Apple", "Samsung", "Xiaomi", "Realme"],
  },
  {
    title: "About Us",
    path: "/about-us",
  },
  {
    title: "Contact Us",
    path: "/contact-us",
  },
  {
    title: "Blog",
    path: "/blog",
  },
];

interface NavbarProps {
  user: {
    fullName: string;
    phone: string;
  } | null;
  isLoggedIn: boolean;
  logout: () => Promise<void>;
}

export function Navbar({ isLoggedIn, logout, user }: NavbarProps) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  const { results, loading, loadingMore, hasMore, loadMore } =
    useDeviceSearch(search);

  return (
    <>
      <header className="sticky top-0 z-50 bg-surface-alt shadow-sm">
        <div className="h-16 border-b border-border bg-surface-alt md:h-19">
          <div className="flex h-full items-center justify-between px-4 md:px-8 lg:px-10">
            {/* Left Side: Logo + Search */}
            <div className="flex items-center gap-6 lg:gap-25">
              {/* Logo */}
              <Link
                href="/"
                className="group flex shrink-0 items-center"
                aria-label="Mobizoo Home"
              >
                <div
                  className="
      relative
      h-16 w-36
      sm:h-14 sm:w-36
      md:h-14 md:w-40
      lg:h-15 lg:w-44
      xl:h-16 xl:w-48
      transition-transform duration-300
      group-hover:scale-[1.02]
    "
                >
                  <Image
                    src="/MobiZoo_logo.webp"
                    alt="Mobizoo - Buy, Sell & Upgrade"
                    fill
                    priority
                    sizes="(max-width: 640px) 128px, (max-width: 1024px) 176px, 192px"
                    className="object-contain"
                  />
                </div>
              </Link>

              {/* Search */}
              <div className="relative hidden md:flex h-10 w-72 lg:w-80 xl:w-96">
                <div className="flex h-full w-full items-center overflow-hidden rounded-sm border border-border bg-white">
                  <div className="flex h-full w-10 shrink-0 items-center justify-center">
                    <IoSearchOutline className="text-2xl text-primary" />
                  </div>

                  <input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="h-full min-w-0 flex-1 border-l border-border bg-white px-3 outline-none"
                    placeholder="Search your device..."
                  />

                  <button
                    type="button"
                    onClick={() => setSearch("")}
                    aria-label="Clear search"
                    className={`flex h-full w-10 shrink-0 items-center justify-center text-primary transition-opacity ${
                      search ? "visible opacity-100" : "invisible opacity-0"
                    }`}
                  >
                    <FaTimes className="text-sm" />
                  </button>
                </div>
                {/* Search Dropdown */}
                {search.trim().length >= 2 && (
                  <div className="absolute left-0 top-full z-9999 mt-2 w-full overflow-hidden rounded-md border border-border bg-white shadow-lg">
                    {loading ? (
                      <div className="px-4 py-3 text-center text-sm text-gray-500">
                        Searching...
                      </div>
                    ) : results.length > 0 ? (
                      <div
                        onScroll={(e) => {
                          const element = e.currentTarget;

                          const isNearBottom =
                            element.scrollHeight -
                              element.scrollTop -
                              element.clientHeight <
                            50;

                          if (isNearBottom && hasMore && !loadingMore) {
                            loadMore();
                          }
                        }}
                        className="max-h-80 overflow-y-auto"
                      >
                        {results.map((device) => (
                          <Link
                            key={device.id}
                            href={device.route}
                            onClick={() => setSearch("")}
                            className="flex items-center gap-3 border-b border-gray-100 px-4 py-3 transition hover:bg-gray-50"
                          >
                            <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-md border border-gray-200">
                              {device.logo ? (
                                <Image
                                  src={device.logo}
                                  alt={device.modelName}
                                  width={40}
                                  height={40}
                                  className="h-full w-full object-contain"
                                />
                              ) : (
                                <div className="flex h-full w-full items-center justify-center text-xs text-gray-400">
                                  No Image
                                </div>
                              )}
                            </div>

                            <div className="min-w-0 flex-1">
                              <p className="truncate text-sm font-medium text-gray-800">
                                {device.modelName}
                              </p>
                            </div>
                          </Link>
                        ))}

                        {loadingMore && (
                          <div className="px-4 py-3 text-center text-sm text-gray-500">
                            Loading more...
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="px-4 py-4 text-center text-sm text-gray-500">
                        No devices found
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Right Side */}
            <div className="hidden md:flex items-center gap-6">
              <div className="flex items-center gap-2 text-primary">
                <a href="tel:+917526074042" className="flex items-center gap-1">
                  <Phone size={18} />

                  <span className="font-semibold">+91 7526074042</span>
                </a>
              </div>

              {/* <button
                type="button"
                onClick={() => setIsLoginModalOpen(true)}
                title="Login"
                className="h-10 px-6 rounded-md flex items-center border border-primary cursor-pointer text-white bg-primary hover:text-white transition"
              >
                Login
              </button> */}
              {isLoggedIn ? (
                <div className="group relative">
                  {/* Profile Icon */}
                  <button
                    type="button"
                    title="My Account"
                    className="flex items-center gap-1 rounded-full border border-border bg-surface p-1 text-text transition hover:border-primary hover:bg-primary/5 cursor-pointer"
                  >
                    {/* Profile Icon */}
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white">
                      <UserCircle className="h-6 w-5" />
                    </div>

                    {/* User Name */}
                    {user && (
                      <span className="hidden max-w-15 truncate text-sm font-medium text-text md:block">
                        {user.fullName.split(" ")[0]}
                      </span>
                    )}
                    <ChevronDown />
                  </button>

                  {/* Dropdown */}
                  <div className="absolute right-0 top-full z-50 hidden w-52 pt-2 group-hover:block">
                    <div className="overflow-hidden rounded-lg border border-border bg-surface shadow-lg">
                      <Link
                        href="/profile"
                        className="flex items-center gap-3 px-4 py-2 text-text transition hover:bg-surface-alt hover:text-primary"
                      >
                        <User className="h-4 w-4" />
                        Profile
                      </Link>

                      <Link
                        href="/my-orders"
                        className="flex items-center gap-3 px-4 py-2 text-text transition hover:bg-surface-alt hover:text-primary"
                      >
                        <ShoppingBag className="h-4 w-4" />
                        My Orders
                      </Link>

                      <Link
                        href="/contact-us"
                        className="flex items-center gap-3 px-4 py-2 text-text transition hover:bg-surface-alt hover:text-primary"
                      >
                        <Phone className="h-4 w-4" />
                        Contact Us
                      </Link>

                      <div className="border-t border-border" />

                      <form action={logout}>
                        <button
                          type="submit"
                          className="flex w-full items-center gap-3 px-4 py-2 text-left text-red-500 hover:bg-red-100 cursor-pointer"
                        >
                          <LogOut className="h-4 w-4" />
                          Logout
                        </button>
                      </form>
                    </div>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsLoginModalOpen(true)}
                  title="Login"
                  className="h-10 px-6 rounded-md flex items-center border border-primary cursor-pointer text-white bg-primary hover:text-white transition"
                >
                  Login
                </button>
              )}
            </div>

            {/* Mobile Actions */}
            <div className="md:hidden flex items-center gap-2">
              {/* Call */}
              <a
                href="tel:+917526074042"
                aria-label="Call us"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-border bg-surface text-primary shadow-sm transition-all hover:bg-primary hover:text-white"
              >
                <Phone className="h-5 w-5" />
              </a>

              {/* Search Button */}
              <button
                type="button"
                onClick={() => setIsMobileSearchOpen((prev) => !prev)}
                className="flex h-10 w-10 items-center justify-center rounded-full border border-border bg-surface text-primary shadow-sm transition-all hover:bg-primary hover:text-white"
                aria-label="Search"
              >
                {isMobileSearchOpen ? (
                  <X className="h-5 w-5" />
                ) : (
                  <Search className="h-5 w-5" />
                )}
              </button>

              {/* Menu Button */}
              <button
                onClick={() => setOpen(!open)}
                className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-white shadow-md transition-all hover:scale-105 active:scale-95"
                aria-label="Menu"
              >
                {open ? (
                  <X className="h-5 w-5" />
                ) : (
                  <Menu className="h-5 w-5" />
                )}
              </button>
            </div>
          </div>

          {/* Mobile Search */}
          {isMobileSearchOpen && (
            <div className="md:hidden border-t border-border bg-surface-alt px-4 py-3">
              <div className="relative">
                {/* Search Input */}
                <div className="flex h-11 w-full items-center overflow-hidden rounded-md border border-border bg-white">
                  <div className="flex h-full w-10 shrink-0 items-center justify-center">
                    <IoSearchOutline className="text-xl text-primary" />
                  </div>

                  <input
                    autoFocus
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="h-full min-w-0 flex-1 border-l border-border bg-white px-3 text-sm outline-none"
                    placeholder="Search your device..."
                  />

                  {search && (
                    <button
                      type="button"
                      onClick={() => setSearch("")}
                      aria-label="Clear search"
                      className="flex h-full w-10 shrink-0 items-center justify-center text-primary"
                    >
                      <FaTimes className="text-sm" />
                    </button>
                  )}
                </div>

                {/* Mobile Search Results */}
                {search.trim().length >= 2 && (
                  <div className="absolute left-0 right-0 top-full z-9999 mt-2 overflow-hidden rounded-md border border-border bg-white shadow-lg">
                    {loading ? (
                      <div className="px-4 py-4 text-center text-sm text-gray-500">
                        Searching...
                      </div>
                    ) : results.length > 0 ? (
                      <div
                        onScroll={(e) => {
                          const element = e.currentTarget;

                          const isNearBottom =
                            element.scrollHeight -
                              element.scrollTop -
                              element.clientHeight <
                            50;

                          if (isNearBottom && hasMore && !loadingMore) {
                            loadMore();
                          }
                        }}
                        className="max-h-[60vh] overflow-y-auto"
                      >
                        {results.map((device) => (
                          <Link
                            key={device.id}
                            href={device.route}
                            onClick={() => {
                              setSearch("");
                              setIsMobileSearchOpen(false);
                            }}
                            className="flex items-center gap-3 border-b border-gray-100 px-4 py-3 transition hover:bg-gray-50"
                          >
                            {/* Device Logo */}
                            <div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-md border border-gray-200">
                              {device.logo ? (
                                <Image
                                  src={device.logo}
                                  alt={device.modelName}
                                  width={40}
                                  height={40}
                                  className="h-full w-full object-contain"
                                />
                              ) : (
                                <div className="flex h-full w-full items-center justify-center text-xs text-gray-400">
                                  No Image
                                </div>
                              )}
                            </div>

                            {/* Device Name */}
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-sm font-medium text-gray-800">
                                {device.modelName}
                              </p>
                            </div>
                          </Link>
                        ))}

                        {loadingMore && (
                          <div className="px-4 py-3 text-center text-sm text-gray-500">
                            Loading more...
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="px-4 py-4 text-center text-sm text-gray-500">
                        No devices found
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Desktop Menu */}
        <nav className="hidden md:block">
          <div className="mx-auto max-w-7xl">
            <ul className="flex justify-between">
              {menu.map((item) => (
                <li
                  key={item.title}
                  className="group relative py-3 font-medium"
                >
                  {item.items ? (
                    <>
                      <div className="flex cursor-pointer items-center gap-2 hover:text-primary">
                        {item.title}
                        <FaChevronDown size={12} />
                      </div>

                      <div className="absolute left-0 top-full z-50 hidden min-w-32 rounded-md border border-border bg-surface py-2 shadow-lg group-hover:block">
                        {item.items.map((brand) => (
                          <Link
                            key={brand}
                            href={`/sell/${item.type}/${brand.toLowerCase()}`}
                            className="block px-4 py-2 text-text hover:text-primary"
                          >
                            {brand}
                          </Link>
                        ))}
                      </div>
                    </>
                  ) : (
                    <Link
                      href={item.path!}
                      className="hover:text-primary transition-colors"
                    >
                      {item.title}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </nav>

        {/* Mobile Menu */}

        {open && (
          <div className="md:hidden border-t border-border bg-surface">
            <div className="space-y-4 p-5">
              {isLoggedIn ? (
                <>
                  {/* User Info Bar */}
                  <div className="border-b border-border bg-surface-alt px-4 py-3">
                    <p className="truncate text-sm font-semibold text-text">
                      {user?.fullName || "User"}
                    </p>

                    <p className="mt-1 truncate text-xs text-text-muted">
                      +91 {user?.phone}
                    </p>
                  </div>
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setIsProfileMenuOpen((prev) => !prev)}
                      className="flex h-10 w-full items-center justify-center gap-2 rounded-md border border-primary text-primary transition hover:bg-primary hover:text-white"
                    >
                      <UserCircle className="h-5 w-5" />
                      <span>My Account</span>
                      <FaChevronDown
                        className={`text-xs transition-transform ${
                          isProfileMenuOpen ? "rotate-180" : ""
                        }`}
                      />
                    </button>

                    {isProfileMenuOpen && (
                      <div className="mt-2 overflow-hidden rounded-md border border-border bg-surface-alt">
                        <Link
                          href="/profile"
                          onClick={() => setOpen(false)}
                          className="flex items-center gap-3 px-4 py-3 hover:text-primary"
                        >
                          <User className="h-4 w-4" />
                          Profile
                        </Link>

                        <Link
                          href="/my-orders"
                          onClick={() => setOpen(false)}
                          className="flex items-center gap-3 px-4 py-3 hover:text-primary"
                        >
                          <ShoppingBag className="h-4 w-4" />
                          My Orders
                        </Link>

                        <div className="border-t border-border" />

                        <form action={logout}>
                          <button
                            type="submit"
                            className="flex w-full items-center gap-3 px-4 py-3 text-left text-red-500"
                          >
                            <LogOut className="h-4 w-4" />
                            Logout
                          </button>
                        </form>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsLoginModalOpen(true)}
                  className="h-10 w-full rounded-md border border-primary bg-primary text-white"
                >
                  Login
                </button>
              )}

              {menu.map((item) => (
                <div key={item.title} className="border-b border-border">
                  {item.items ? (
                    <>
                      <div
                        onClick={() =>
                          setActiveMenu(
                            activeMenu === item.title ? null : item.title,
                          )
                        }
                        className="flex cursor-pointer items-center justify-between py-1.5 font-medium"
                      >
                        {item.title}

                        <FaChevronDown
                          className={`transition-transform ${
                            activeMenu === item.title ? "rotate-180" : ""
                          }`}
                        />
                      </div>

                      {activeMenu === item.title && (
                        <div className="pb-2 pl-4">
                          {item.items.map((brand) => (
                            <Link
                              key={brand}
                              href={`/sell/${item.type}/${brand.toLowerCase()}`}
                              onClick={() => setOpen(false)}
                              className="block py-2 text-text-light hover:text-primary"
                            >
                              {brand}
                            </Link>
                          ))}
                        </div>
                      )}
                    </>
                  ) : (
                    <Link
                      href={item.path!}
                      onClick={() => {
                        setOpen(false);
                        setActiveMenu(null);
                      }}
                      className="flex items-center justify-between py-1.5 font-medium hover:text-primary transition-colors"
                    >
                      {item.title}
                    </Link>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </header>

      <LoginOtpModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
      />
    </>
  );
}
