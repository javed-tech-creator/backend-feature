import type { ModelDetails, ModelStorage } from "@/lib/types";
import Image from "next/image";
import Link from "next/link";

type StorageListProps = {
  model: ModelDetails;
  storages: ModelStorage[];
  deviceSlug: string;
  brandSlug: string;
  modelSlug: string;
};

const StorageList = ({
  model,
  storages,
  deviceSlug,
  brandSlug,
  modelSlug,
}: StorageListProps) => {
  return (
    <section className="w-full px-3 py-5 sm:px-4 sm:py-6 md:px-6 lg:px-8">
      <div className="mx-auto w-full max-w-5xl">
        <div className="rounded-2xl border border-gray-200 bg-sky-50 p-4 sm:p-6 md:p-8">
          <div className="flex flex-col items-center gap-5 sm:flex-row sm:items-start sm:gap-8">
            {/* Model Image */}
            <div className="relative h-44 w-36 shrink-0 sm:h-52 sm:w-44">
              {model.logo ? (
                <Image
                  src={model?.logo}
                  alt={model?.name}
                  fill
                  sizes="(max-width: 640px) 144px, 176px"
                  className="object-contain"
                  priority
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center rounded-lg bg-gray-100 text-sm text-gray-500">
                  No Image
                </div>
              )}
            </div>

            {/* Storage Section */}
            <div className="w-full">
              <h1 className="text-center text-xl font-semibold text-heading sm:text-left sm:text-2xl md:text-3xl">
                {model?.name}
              </h1>

              <h2 className="mt-5 text-sm font-medium text-gray-700 sm:text-base">
                Select Variant
              </h2>

              {storages.length > 0 ? (
                <div className="mt-3 grid grid-cols-2 gap-3 sm:flex sm:flex-wrap">
                  {storages.map((item) => {
                    const storage = item?.storageId;
                    return (
                      <Link
                        key={item._id}
                        href={{
                          pathname: `/sell/${deviceSlug}/${brandSlug}/${modelSlug}/${storage?.slug}`,
                        }}
                        className="
                          flex
                          min-h-15
                          items-center
                          justify-center
                          rounded-lg
                          border
                          border-gray-300
                          bg-white
                          px-4
                          py-3
                          text-center
                          text-sm
                          font-medium
                          text-gray-800
                          transition
                          hover:border-primary
                          hover:bg-primary/5
                          hover:text-primary
                          sm:min-w-35
                        "
                      >
                        {storage?.ram} {storage?.ram ? "/" : ""} {storage?.rom}
                      </Link>
                    );
                  })}
                </div>
              ) : (
                <p className="mt-3 text-sm text-gray-500">
                  No variants available.
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StorageList;
