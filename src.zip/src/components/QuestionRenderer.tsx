"use client";

import type { Question } from "@/lib/types";
import Image from "next/image";

type QuestionRendererProps = {
  question: Question;
  value: string | string[] | undefined;
  onChange: (questionId: string, value: string | string[]) => void;
  error?: string;
};

function optionIconUrl(icon: string): string {
  const [prefix, name] = icon.split(":");
  if (!prefix || !name) return "";
  return `https://api.iconify.design/${prefix}/${name}.svg`;
}

function OptionIcon({ icon }: { icon: string | null }) {
  if (!icon) return null;

  const src = optionIconUrl(icon);
  if (!src) return null;

  return (
    <Image
      src={src}
      alt=""
      width={20}
      height={20}
      className="h-5 w-5 shrink-0 object-contain sm:h-6 sm:w-6"
      unoptimized
    />
  );
}

const QuestionRenderer = ({
  question,
  value,
  onChange,
  error,
}: QuestionRendererProps) => {
  const { _id, title, type, options } = question;

  const handleSingleSelect = (optionId: string) => {
    onChange(_id, optionId);
  };

  const handleCheckboxToggle = (optionId: string) => {
    const current = Array.isArray(value) ? value : [];
    const next = current.includes(optionId)
      ? current.filter((id) => id !== optionId)
      : [...current, optionId];
    onChange(_id, next);
  };

  const handleInputChange = (text: string) => {
    onChange(_id, text);
  };

  const renderBoolean = () => (
    <div className="mt-2 flex flex-wrap gap-2 lg:mt-3 lg:gap-3">
      {options.map((option) => {
        const selected = value === option._id;

        return (
          <button
            key={option._id}
            type="button"
            onClick={() => handleSingleSelect(option._id)}
            className={`
              h-8 min-w-[4.5rem] rounded-md border px-4
              text-xs font-medium transition
              lg:h-9 lg:min-w-[5rem] lg:px-5 lg:text-sm
              ${
                selected
                  ? "border-primary bg-primary text-white"
                  : "border-gray-200 bg-white text-gray-700 hover:border-primary/60 hover:bg-sky-50"
              }
            `}
          >
            {option.title}
          </button>
        );
      })}
    </div>
  );

  const renderRadio = () => (
    <div className="mt-2 space-y-1.5 lg:mt-3 lg:space-y-2.5">
      {options.map((option) => {
        const selected = value === option._id;

        return (
          <button
            key={option._id}
            type="button"
            onClick={() => handleSingleSelect(option._id)}
            className={`
              flex w-full items-center gap-2 rounded-lg border px-3 py-1.5 text-left
              text-xs font-medium transition
              sm:text-sm lg:gap-3 lg:px-4 lg:py-2.5
              ${
                selected
                  ? "border-primary bg-sky-50 text-heading"
                  : "border-gray-200 bg-white text-gray-700 hover:border-primary/60 hover:bg-sky-50/50"
              }
            `}
          >
            <span
              className={`
                flex h-4 w-4 shrink-0 items-center justify-center rounded-full border-2
                ${selected ? "border-primary" : "border-gray-400"}
              `}
            >
              {selected ? (
                <span className="h-2 w-2 rounded-full bg-primary" />
              ) : null}
            </span>
            <OptionIcon icon={option.icon} />
            <span>{option.title}</span>
          </button>
        );
      })}
    </div>
  );

  const renderCheckbox = () => {
    const selectedIds = Array.isArray(value) ? value : [];

    return (
      <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3 sm:gap-3 lg:grid-cols-4 lg:gap-4 xl:grid-cols-5 xl:gap-5">
        {options.map((option) => {
          const selected = selectedIds.includes(option._id);

          return (
            <button
              key={option._id}
              type="button"
              onClick={() => handleCheckboxToggle(option._id)}
              className={`
                flex min-h-[4rem] flex-col items-center justify-center gap-1
                rounded-lg border px-2 py-2 text-center text-[10px] font-medium
                transition sm:min-h-[4.25rem] sm:text-xs
                lg:min-h-[5rem] lg:gap-2 lg:px-3 lg:py-3 lg:text-sm
                xl:min-h-[5.5rem] xl:px-4
                ${
                  selected
                    ? "border-primary bg-sky-50 text-heading ring-1 ring-primary/20"
                    : "border-gray-200 bg-white text-gray-700 hover:border-primary/60 hover:bg-sky-50/50"
                }
              `}
            >
              <OptionIcon icon={option.icon} />
              <span className="line-clamp-2 leading-tight">{option.title}</span>
            </button>
          );
        })}
      </div>
    );
  };

  const renderInput = () => (
    <div className="mt-2 lg:mt-3">
      <input
        type="text"
        value={typeof value === "string" ? value : ""}
        onChange={(event) => handleInputChange(event.target.value)}
        className="
          w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm
          text-gray-800 outline-none transition
          focus:border-primary focus:ring-2 focus:ring-primary/20
          lg:px-4 lg:py-2.5
        "
        placeholder="Enter your answer"
      />
    </div>
  );

  return (
    <div className="h-full rounded-xl border border-gray-200 bg-white p-3 sm:p-4 lg:p-5">
      <h3 className="text-sm font-medium text-heading sm:text-base lg:text-[17px]">
        {title}
      </h3>

      {type === "boolean" && renderBoolean()}
      {type === "radio" && renderRadio()}
      {type === "checkbox" && renderCheckbox()}
      {type === "input" && renderInput()}

      {error ? <p className="mt-2 text-xs text-red-500">{error}</p> : null}
    </div>
  );
};

export default QuestionRenderer;
