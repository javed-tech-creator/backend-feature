"use client";

import Image from "next/image";
import type { Brand } from "@/lib/types";
import Link from "@/components/Link";
import { useCallback, useEffect, useRef, useState } from "react";
import { loadMoreModels } from "@/action/device.action";

type ModelListProps = {
  models: Brand[];
  hasMore?: boolean;
  nextCursor: string | null;
  deviceSlug: string;
  brandSlug: string;
};

const ModelList = ({
  models,
  hasMore = false,
  nextCursor = null,
  deviceSlug,
  brandSlug,
}: ModelListProps) => {
  const [modelList, setModelList] = useState(models);
  const [cursor, setCursor] = useState(nextCursor);
  const [hasMoreModels, setHasMoreModels] = useState(hasMore);
  const [loading, setLoading] = useState(false);
  const observerRef = useRef<HTMLDivElement | null>(null);

  const handleLoadMore = useCallback(async () => {
    if (!cursor || loading || !hasMoreModels) return;

    try {
      setLoading(true);

      const response = await loadMoreModels({
        device: deviceSlug,
        brand: brandSlug,
        limit: 24,
        cursor,
      });

      if (!response.success) {
        return;
      }

      setModelList((prev) => [...prev, ...response.data.data]);

      setCursor(response.data.nextCursor);
      setHasMoreModels(response.data.hasMore);
    } catch (error) {
      console.error("Load more models error:", error);
    } finally {
      setLoading(false);
    }
  }, [cursor, loading, hasMoreModels, deviceSlug, brandSlug]);

  useEffect(() => {
    const element = observerRef.current;

    if (!element || !hasMoreModels) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          handleLoadMore();
        }
      },
      {
        rootMargin: "200px",
      },
    );

    observer.observe(element);

    return () => observer.disconnect();
  }, [handleLoadMore, hasMoreModels]);

  return (
    <section className="w-full  px-3 py-5 sm:px-4 sm:py-6 md:px-6 lg:px-8">
      {/* Page title */}
      <div className="mx-auto mb-3 w-full max-w-7xl text-center sm:mb-4">
        <h1 className="text-base font-bold text-heading sm:text-lg md:text-2xl">
          Sell Used Phones
        </h1>

        <p className="mt-0.5 text-[11px] text-gray-500 sm:text-xs md:text-sm">
          Choose a model to get started
        </p>
      </div>

      {!modelList.length ? (
        <div className="flex min-h-50 items-center justify-center px-4">
          <p className="text-center text-sm text-gray-500 sm:text-base">
            No models found.
          </p>
        </div>
      ) : (
        <>
          <div
            className="
              mx-auto
              grid
              w-full
              max-w-7xl
              grid-cols-2
              gap-3
              sm:grid-cols-3
              sm:gap-4
              md:grid-cols-4
              lg:grid-cols-6
              xl:grid-cols-8
            "
          >
            {modelList.map((model) => (
              <Link
                key={model._id}
                href={`/sell/${deviceSlug}/${brandSlug}/${model.slug}`}
                className="group flex h-28 w-full flex-col items-center justify-center rounded-xl border border-gray-200 bg-surface-alt p-2.5 transition-all duration-200 hover:-translate-y-1 hover:border-gray-300 hover:shadow-md sm:h-32 sm:p-3"
              >
                <div className="relative mb-2 flex h-12 w-full items-center justify-center sm:h-14 sm:mb-3 md:h-16">
                  {model.logo ? (
                    <Image
                      src={model.logo}
                      alt={`${model.name} logo`}
                      fill
                      sizes="(max-width: 640px) 48px, (max-width: 768px) 56px, (max-width: 1024px) 54px, 50px"
                      className="object-contain transition-transform duration-200 group-hover:scale-105"
                    />
                  ) : (
                    <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-100 text-xs font-semibold text-gray-500 sm:h-10 sm:w-10">
                      {model.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>
                <div className="flex min-h-8 w-full items-start justify-center sm:min-h-10">
                  <h2 className="w-full whitespace-normal wrap-break-word text-center text-xs font-medium text-gray-800 sm:text-sm ">
                    {model.name}
                  </h2>
                </div>
              </Link>
            ))}
          </div>

          {hasMoreModels && (
            <div
              ref={observerRef}
              className="flex min-h-16 items-center justify-center py-6"
            >
              {loading && (
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <span className="h-5 w-5 animate-spin rounded-full border-2 border-gray-300 border-t-primary" />
                  Loading more models...
                </div>
              )}
            </div>
          )}
        </>
      )}
    </section>
  );
};

export default ModelList;
