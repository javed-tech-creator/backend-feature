type LoadingProps = {
  message?: string;
};

export default function Loading({ message = "Loading..." }: LoadingProps) {
  return (
    <div className="flex min-h-[50vh] w-full items-center justify-center px-4 sm:min-h-[60vh] md:min-h-[70vh] lg:min-h-[80vh]">
      <div className="flex flex-col items-center justify-center gap-3 sm:gap-4">
        <div
          className="
            h-8
            w-8
            animate-spin
            rounded-full
            border-[3px]
            border-gray-200
            border-t-primary
            sm:h-10
            sm:w-10
            sm:border-4
            md:h-12
            md:w-12
          "
        />

        <p className="text-xs text-gray-500 sm:text-sm md:text-base">
          {message}
        </p>
      </div>
    </div>
  );
}