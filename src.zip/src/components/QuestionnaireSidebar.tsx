import type { QuestionnaireSessionData, SelectedAnswerItem } from "@/lib/types";
import Image from "next/image";

type QuestionnaireSidebarProps = {
  session: QuestionnaireSessionData;
  selectedItems: SelectedAnswerItem[];
  currentStep: number;
  totalSteps: number;
  variant?: "default" | "compact";
};

const QuestionnaireSidebar = ({
  session,
  selectedItems,
  currentStep,
  totalSteps,
  variant = "default",
}: QuestionnaireSidebarProps) => {
  const { modelData, storageLabel, brandLabel, selectedStorage } = session;
  const basePrice = selectedStorage.basePrice;
  const isCompact = variant === "compact";
  const progressPercent =
    totalSteps > 0 ? Math.round(((currentStep + 1) / totalSteps) * 100) : 0;

  return (
    <aside
      className={`flex flex-col ${isCompact ? "gap-3" : "gap-4 lg:sticky lg:top-6"}`}
    >
      {totalSteps > 1 ? (
        <div
          className={`rounded-xl border border-gray-200 bg-white ${isCompact ? "p-3" : "p-4 sm:p-5"}`}
        >
          <div className="flex items-center justify-between gap-2">
            <p className="text-sm font-semibold text-heading">Progress</p>
            <span className="text-sm font-medium text-primary">
              {progressPercent}%
            </span>
          </div>

          <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-gray-100">
            <div
              className="h-full rounded-full bg-primary transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          <p className="mt-2 text-xs text-gray-500">
            Step {currentStep + 1} of {totalSteps}
          </p>

          <div className={`mt-3 flex ${isCompact ? "gap-2" : "gap-2.5"}`}>
            {Array.from({ length: totalSteps }).map((_, index) => {
              const isDone = index < currentStep;
              const isActive = index === currentStep;

              return (
                <div
                  key={index}
                  className={`
                    flex h-8 flex-1 items-center justify-center rounded-lg text-xs font-semibold
                    transition
                    ${
                      isActive
                        ? "bg-primary text-white"
                        : isDone
                          ? "bg-primary/15 text-primary"
                          : "bg-gray-100 text-gray-400"
                    }
                  `}
                >
                  {index + 1}
                </div>
              );
            })}
          </div>
        </div>
      ) : null}

      <div
        className={`rounded-xl border border-gray-200 bg-white ${isCompact ? "p-3" : "p-4 sm:p-5"}`}
      >
        <div
          className={
            isCompact
              ? "flex items-center gap-4"
              : "flex flex-col items-center text-center"
          }
        >
          <div
            className={
              isCompact
                ? "relative h-16 w-14 shrink-0"
                : "relative h-28 w-24 shrink-0 sm:h-32 sm:w-28"
            }
          >
            {modelData.logo ? (
              <Image
                src={modelData.logo}
                alt={modelData.name}
                fill
                sizes="112px"
                className="object-contain"
                priority
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center rounded-lg bg-gray-50 text-xs text-gray-400">
                No Image
              </div>
            )}
          </div>

          <div className={isCompact ? "min-w-0 flex-1 text-left" : "w-full"}>
            <h2
              className={`font-semibold text-heading ${isCompact ? "truncate text-base" : "mt-2 text-base sm:text-lg"}`}
            >
              {modelData.name}
            </h2>
            <p className="text-xs text-gray-500 sm:text-sm">
              {brandLabel} · {storageLabel}
            </p>

            {basePrice != null ? (
              <div
                className={`rounded-lg bg-sky-50 ${isCompact ? "mt-2 inline-block px-3 py-1.5" : "mt-3 w-full px-3 py-2.5"}`}
              >
                <p className="text-xs font-medium text-gray-500">Expected Price</p>
                <p
                  className={`font-bold text-primary ${isCompact ? "text-base" : "text-lg sm:text-xl"}`}
                >
                  ₹ {basePrice.toLocaleString()}
                </p>
              </div>
            ) : null}
          </div>
        </div>
      </div>

      <div
        className={`rounded-xl border border-gray-200 bg-white ${isCompact ? "p-3" : "p-4 sm:p-5"}`}
      >
        <h3 className="text-sm font-semibold text-heading">
          Your Selections
          {selectedItems.length > 0 ? (
            <span className="ml-1.5 font-normal text-gray-400">
              · {selectedItems.length}
            </span>
          ) : null}
        </h3>

        {selectedItems.length === 0 ? (
          <p className="mt-2 text-xs leading-relaxed text-gray-400 sm:text-sm">
            Answers will show up here as you go.
          </p>
        ) : (
          <ul
            className={`mt-3 space-y-2 overflow-y-auto ${isCompact ? "max-h-28" : "max-h-52 lg:max-h-64"}`}
          >
            {selectedItems.map((item, index) => (
              <li
                key={`${item.questionId}-${item.optionTitle}-${index}`}
                className="rounded-lg bg-gray-50 px-3 py-2"
              >
                <p className="truncate text-xs text-gray-400">
                  {item.questionTitle}
                </p>
                <p className="truncate text-sm font-medium text-heading">
                  {item.optionTitle}
                </p>
              </li>
            ))}
          </ul>
        )}
      </div>
    </aside>
  );
};

export default QuestionnaireSidebar;
