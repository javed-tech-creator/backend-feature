"use client";

import type { ModelDetails, ModelStorage, QuestionnaireSessionData } from "@/lib/types";
import { saveQuestionnaireSession } from "@/lib/questionnaire-session";
import { useRouter } from "next/navigation";

type FindAssuredPriceLinkProps = {
  modelData: ModelDetails;
  selectedStorage: ModelStorage;
  deviceId: string;
  deviceSlug: string;
  brandSlug: string;
  modelSlug: string;
  storageSlug: string;
  brandLabel: string;
  storageLabel: string;
};

const FindAssuredPriceLink = ({
  modelData,
  selectedStorage,
  deviceId,
  deviceSlug,
  brandSlug,
  modelSlug,
  storageSlug,
  brandLabel,
  storageLabel,
}: FindAssuredPriceLinkProps) => {
  const router = useRouter();

  const handleClick = () => {
    const session: QuestionnaireSessionData = {
      modelData: { ...modelData, deviceId },
      selectedStorage,
      deviceSlug,
      brandSlug,
      modelSlug,
      storageSlug,
      brandLabel,
      storageLabel,
    };

    saveQuestionnaireSession(session);
    router.push("/sell/questionnaire", { scroll: false });
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      className="
        mt-5
        w-full
        rounded-lg
        bg-primary
        px-5
        py-3
        text-sm
        font-semibold
        text-white
        transition
        hover:opacity-90
        sm:text-base
        cursor-pointer
      "
    >
      Find Assured Selling Price
    </button>
  );
};

export default FindAssuredPriceLink;
