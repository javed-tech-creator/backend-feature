import Link from "next/link";
import { sellCategories } from "../lib/constant";
export default function SellCategories() {
  return (
    <section className="bg-surface-alt  py-5">
      <div className="px-4.5 md:px-0 max-w-360 mx-auto relative z-10">
        <div className="text-center mb-10">
          <h2 className="text-4xl font-bold text-heading">
            Sell for <span className="text-primary">cash</span>
          </h2>
          <p className="text-text-light mt-2">
            Let's get started. What are you selling today?
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-6">
          {sellCategories.map((item) => (
            <Link
              key={item.id}
              href={item.link}
              className="bg-surface rounded-lg border border-border shadow-md hover:shadow-lg transition duration-300 p-6 flex flex-col items-center group"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={item.image.src}
                alt={item.title}
                className="h-28 object-contain group-hover:scale-105 transition"
              />

              <h4 className="mt-6 text-md font-normal text-primary">
                {item.title}
              </h4>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
