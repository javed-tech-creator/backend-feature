import Link from "next/link";
import { sellCategories } from "../lib/constant";
export default function SellCategories() {
  return (
    <section className="bg-surface-alt  py-5">
      <div className="px-4.5 md:px-0 max-w-360 mx-auto relative z-10">
        <div className="text-center mb-5">
          <h2 className="text-2xl md:text-4xl font-bold text-heading leading-tight">
            Sell for <span className="text-primary">cash</span>
          </h2>
          <p className="text-text-light mt-2">
            Let's get started. What are you selling today?
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:gap-5 lg:grid-cols-5 lg:gap-6">
          {sellCategories.map((item) => (
            <Link
              key={item.id}
              href={item.link}
              className="
        group flex flex-col items-center
        rounded-xl border border-border
        bg-surface
        p-3 sm:p-4 md:p-5 lg:p-6
        shadow-sm
        transition-all duration-300
        hover:-translate-y-1 hover:shadow-lg
      "
            >
              {/* Device Image */}
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={item.image.src}
                alt={item.title}
                className="
          h-24 w-full
          object-contain
          transition-transform duration-300
          group-hover:scale-105
          sm:h-28
          md:h-32
          lg:h-36
        "
              />

              {/* Device Name */}
              <h4
                className="
          mt-3 text-center
          text-sm font-medium
          text-primary
          sm:mt-4 sm:text-base
        "
              >
                {item.title}
              </h4>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
