"use client";

import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type KeyboardEvent,
  type TouchEvent,
} from "react";
import type { StaticImageData } from "next/image";
import { FaArrowLeft, FaArrowRight } from "react-icons/fa";
import banner1 from "../assets/banner/banner-1.webp";
import banner1Mobile from "../assets/banner/banner-1-mobile.webp";
import banner2 from "../assets/banner/banner-2.webp";
import banner2Mobile from "../assets/banner/banner-2-mobile.webp";

interface Slide {
  id: number;
  /** Desktop / wide crop — 1920x600 (16:5, lg container se exact match) */
  image: StaticImageData;
  /**
   * Mobile crop — 1080x608 (16:9, phone container se exact match).
   * <=639px screens par yehi serve hota hai -> text kabhi crop nahi hota.
   */
  imageMobile?: StaticImageData;
  title: string;
}

const slides: Slide[] = [
  {
    id: 2,
    image: banner2,
    imageMobile: banner2Mobile,
    title: "Turn Your Old Phone Into Cash",
  },
  {
    id: 3,
    image: banner1,
    imageMobile: banner1Mobile,
    title: "Sell Your Old Phone",
  },
];

const AUTOPLAY_MS = 3000;
const SWIPE_THRESHOLD = 50; // px

export default function HeroSlider() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const touchStartX = useRef<number | null>(null);
  const touchDeltaX = useRef(0);

  const goTo = useCallback((index: number) => {
    setActiveIndex(((index % slides.length) + slides.length) % slides.length);
  }, []);

  const goToNext = useCallback(
    () => goTo(activeIndex + 1),
    [activeIndex, goTo],
  );
  const goToPrev = useCallback(
    () => goTo(activeIndex - 1),
    [activeIndex, goTo],
  );

  // Autoplay: har slide change par timer reset hota hai, isliye manual click ke
  // turant baad slide jump nahi karegi. Reduced-motion par autoplay band.
  useEffect(() => {
    if (isPaused || slides.length < 2) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const timer = window.setTimeout(() => {
      setActiveIndex((prev) => (prev + 1) % slides.length);
    }, AUTOPLAY_MS);

    return () => window.clearTimeout(timer);
  }, [activeIndex, isPaused]);

  const onTouchStart = (e: TouchEvent<HTMLElement>) => {
    touchStartX.current = e.touches[0].clientX;
    touchDeltaX.current = 0;
    setIsPaused(true);
  };

  const onTouchMove = (e: TouchEvent<HTMLElement>) => {
    if (touchStartX.current === null) return;
    touchDeltaX.current = e.touches[0].clientX - touchStartX.current;
  };

  const onTouchEnd = () => {
    if (Math.abs(touchDeltaX.current) > SWIPE_THRESHOLD) {
      if (touchDeltaX.current < 0) goToNext();
      else goToPrev();
    }
    touchStartX.current = null;
    touchDeltaX.current = 0;
    setIsPaused(false);
  };

  const onKeyDown = (e: KeyboardEvent<HTMLElement>) => {
    if (e.key === "ArrowRight") {
      e.preventDefault();
      goToNext();
    }
    if (e.key === "ArrowLeft") {
      e.preventDefault();
      goToPrev();
    }
  };

  return (
    <section
      role="region"
      aria-roledescription="carousel"
      aria-label="Offers"
      tabIndex={0}
      onKeyDown={onKeyDown}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      className="relative w-full select-none outline-none"
    >
      {/*
        Height ab aspect-ratio se aati hai -> zero layout shift (CLS).
        Phone par thoda taller, desktop par wide. Bade screens par max-height cap
        taki banner poori screen na kha jaye.
      */}
      <div className="relative w-full overflow-hidden bg-primary-hover aspect-[16/9] sm:aspect-[16/7] lg:aspect-[16/5] lg:max-h-[600px]">
        {slides.map((slide, index) => {
          const isActive = index === activeIndex;

          return (
            <div
              key={slide.id}
              role="group"
              aria-roledescription="slide"
              aria-label={`${index + 1} of ${slides.length}`}
              aria-hidden={!isActive}
              className={`absolute inset-0 transition-opacity duration-700 ease-out ${
                isActive ? "opacity-100" : "pointer-events-none opacity-0"
              }`}
            >
              <picture>
                {slide.imageMobile && (
                  <source
                    /* 639px -> Tailwind ke sm:(640px) breakpoint se exactly align,
                       taki mobile image aur mobile aspect-[16/9] hamesha saath chalein */
                    media="(max-width: 639px)"
                    srcSet={slide.imageMobile.src}
                    width={1080}
                    height={608}
                  />
                )}
                <img
                  src={slide.image.src}
                  alt={slide.title}
                  /* desktop image ki real dimensions — CLS aur decode dono ke liye */
                  width={1920}
                  height={600}
                  /* hero image kabhi lazy nahi: pehli slide eager, LCP bachta hai */
                  loading={index === 0 ? "eager" : "lazy"}
                  decoding="async"
                  draggable={false}
                  className="block h-full w-full object-cover object-center"
                />
              </picture>
            </div>
          );
        })}
      </div>

      {/* Arrows: phone par chhote, desktop par bade. Hover ab actually dikhta hai. */}
      <button
        type="button"
        aria-label="Previous slide"
        title="Previous"
        onClick={goToPrev}
        className="hidden md:block absolute left-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-primary/80 p-2 text-white shadow-md backdrop-blur-sm transition hover:bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white sm:left-4 sm:p-3"
      >
        <FaArrowLeft className="h-3.5 w-3.5 sm:h-5 sm:w-5" />
      </button>

      <button
        type="button"
        aria-label="Next slide"
        title="Next"
        onClick={goToNext}
        className="hidden md:block absolute right-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-primary/80 p-2 text-white shadow-md backdrop-blur-sm transition hover:bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white sm:right-4 sm:p-3"
      >
        <FaArrowRight className="h-3.5 w-3.5 sm:h-5 sm:w-5" />
      </button>

      {/* Dots: tap target ab 40px (padding se), active dot pill ban jaata hai */}
      <div className="absolute bottom-1 left-1/2 z-10 flex -translate-x-1/2 items-center gap-1 sm:bottom-2">
        {slides.map((slide, index) => (
          <button
            key={slide.id}
            type="button"
            aria-label={`Go to slide ${index + 1}`}
            aria-current={index === activeIndex}
            onClick={() => goTo(index)}
            className="group p-2 focus-visible:outline-none"
          >
            <span
              className={`block h-2 rounded-full transition-all duration-300 ${
                index === activeIndex
                  ? "w-6 bg-white"
                  : "w-2 bg-white/60 group-hover:bg-white/90"
              }`}
            />
          </button>
        ))}
      </div>
    </section>
  );
}
