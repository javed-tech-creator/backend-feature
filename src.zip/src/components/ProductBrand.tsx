import Link from "next/link";
import apple from "../assets/brandlogo/apple.png";
import dell from "../assets/brandlogo/dell.png";
import hp from "../assets/brandlogo/hp.png";
import motorola from "../assets/brandlogo/motorola.png";
import oneplus from "../assets/brandlogo/oneplus.png";
import oppo from "../assets/brandlogo/oppo.png";
import sumsung from "../assets/brandlogo/sumsung.png";
import vivo from "../assets/brandlogo/vivo.png";

export default function ProductBrands() {
  const productBrands = [
    {
      name: "Apple",
      logo: apple,
      type: "phone",
    },
    {
      name: "Dell",
      logo: dell,
      type: "laptop",
    },
    {
      name: "OnePlus",
      logo: oneplus,
      type: "phone",
    },
    {
      name: "Oppo",
      logo: oppo,
      type: "phone",
    },
    {
      name: "Motorola",
      logo: motorola,
      type: "phone",
    },
    {
      name: "Vivo",
      logo: vivo,
      type: "phone",
    },
    {
      name: "HP",
      logo: hp,
      type: "laptop",
    },
    {
      name: "Sumsung",
      logo: sumsung,
      type: "phone",
    },
  ];
  // Double the brands array for seamless infinite loop
  const duplicatedBrands = [...productBrands, ...productBrands];

  return (
    <section className="w-full bg-surface-alt overflow-hidden relative py-5 ">
      <div className="px-4.5 md:px-0 md:max-w-360 mx-auto relative z-10">
        <div className="text-center">
          <h2 className="text-2xl md:text-4xl font-bold text-heading leading-tight py-2 mt-2">
            Sell your device from{" "}
            <span className="text-primary">any brand</span>
          </h2>
          <p className=" text-text-light max-w-2xl mx-auto">
            Choose your device brand and receive an instant price estimate with
            free doorstep pickup and secure payment.
          </p>
        </div>
        {/* Brands Slider Container */}
        <div className="relative">
          {/* Sliding Track */}
          <div className="flex overflow-hidden py-2">
            <div className="flex animate-scroll">
              {duplicatedBrands.map((brand, index) => (
                <Link
                  key={index}
                  href={`/sell/${brand.type}/${brand.name.toLowerCase()}`}
                  className="shrink-0 mx-6 w-34 h-34 flex items-center justify-center bg-surface-alt  rounded-2xl transition-all duration-300  group hover:scale-105 cursor-pointer"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={brand.logo.src}
                    alt={brand.name}
                    className="w-22 h-22 object-contain opacity-90 group-hover:opacity-100 transition-all duration-300 group-hover:scale-110"
                  />
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }

        .animate-scroll {
          animation: scroll 40s linear infinite;
        }

        .animate-scroll:hover {
          animation-play-state: paused;
        }
      `}</style>
    </section>
  );
}
