import { label } from "@/helper/common.helper";
import type { ModelDetails, ModelStorage } from "@/lib/types";
import Image from "next/image";

type StorageListProps = {
  modelData: ModelDetails;
  storages: ModelStorage[];
  brand: string;
  model: string;
  storageSlug: string;
};

const StorageComponent = ({
  modelData,
  storages,
  brand,
  model,
  storageSlug,
}: StorageListProps) => {
  const storage = label(storageSlug);

  const selectedStorage = storages.find(
    (item) => item.storageId?.slug === storageSlug,
  );
  const basePrice = selectedStorage?.basePrice;

  return (
    <div className="w-full px-3 py-5 sm:px-4 sm:py-6 md:px-6 lg:px-8">
      <div className="mx-auto w-full max-w-5xl">
        <div className="rounded-2xl border border-gray-200 bg-sky-50 p-4 sm:p-6 md:p-8">
          <div className="flex flex-col items-center gap-5 sm:flex-row sm:items-start sm:gap-8">
            {/* Phone Image */}
            <div className="relative h-44 w-36 shrink-0 sm:h-52 sm:w-44">
              {modelData.logo ? (
                <Image
                  src={modelData.logo}
                  alt={modelData.name || `${brand} ${model}`}
                  fill
                  sizes="(max-width: 640px) 144px, 176px"
                  className="object-contain"
                  priority
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center rounded-lg bg-gray-100 text-sm text-gray-500">
                  No Image
                </div>
              )}
            </div>

            {/* Price Section */}
            <div className="w-full">
              <h1 className="text-center text-xl font-semibold text-heading sm:text-left sm:text-2xl md:text-3xl">
                {modelData.name} {storage}
              </h1>

              {/* Expected Price */}
              <div className="mt-5">
                <h2 className="text-sm font-medium text-gray-700 sm:text-base">
                  Expected Price
                </h2>

                <div className="mt-3 rounded-xl border border-gray-200 bg-white p-4 sm:p-4">
                  <p className="text-center text-2xl font-bold text-primary sm:text-3xl">
                    ₹ {basePrice != null ? basePrice.toLocaleString() : "N/A"}
                  </p>
                </div>
              </div>

              {/* Find Assured Final Price */}
              <button
                type="button"
                className="
                  mt-5
                  w-full
                  rounded-lg
                  bg-primary
                  px-5
                  py-3
                  text-sm
                  font-semibold
                  text-white
                  transition
                  hover:opacity-90
                  sm:text-base
                  cursor-pointer
                "
              >
                Find Assured Selling Price
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StorageComponent;
