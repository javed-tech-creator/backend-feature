import doBest from "../assets/images/do-best.png";
export default function WhatWeDoBest() {
  const stats = [
    {
      label: "1m+",
      title: "Building Trust- 1 Million Plus Downloads",
      desc: "Over 1 million plus app downloaded had been done by our valuable customer in a short span that shows their trust on us.",
    },
    {
      label: "∞",
      title: "Continuous Improvement",
      desc: "Our process helped new customers start and rump up their partnership with us at a place that is customised to their needs.",
    },
    {
      label: "24/7",
      title: "Customer Centric",
      desc: "Our main priority is to exceed our customers expectations. We are open 24/7. We get it done on your schedule, not ours.",
    },
  ];

  return (
    <section className="bg-background py-10">
      <div className=" px-4.5 md:px-0 max-w-360 mx-auto grid lg:grid-cols-2 gap-5 items-center">
        {/* Left: image with decorative rings */}
        <div className="relative flex justify-center items-end">
          <div className="relative flex items-end justify-center w-[320px] h-105 md:w-90 md:h-120 lg:w-100 lg:h-130">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={doBest.src}
              alt="Let us do what we do best"
              className="w-full h-full object-contain object-bottom"
            />
          </div>
        </div>

        {/* Right: content */}
        <div className="text-center md:text-start">
          <h2 className="text-2xl md:text-4xl font-bold text-heading leading-tight ">
            Let us do what <span className="text-primary">we do best</span>
          </h2>
          <p className="text-text-light mt-2">
            Our main focus is the satisfaction of the user&apos;s needs so this
            is why you can 100 % trust us with your devices.
          </p>

          <div className="mt-10 space-y-10">
            {stats.map((s) => (
              <div
                key={s.title}
                className="flex flex-col md:flex-row items-center md:items-start gap-6"
              >
                <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full bg-linear-to-br from-accent to-secondary shadow-lg shadow-secondary/20">
                  <span className="text-white text-lg font-bold">
                    {s.label}
                  </span>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-heading">{s.title}</h3>
                  <p className="mt-2 text-text-light leading-relaxed">
                    {s.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
