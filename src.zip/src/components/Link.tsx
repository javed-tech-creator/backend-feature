import NextLink from "next/link";
import type { ComponentProps } from "react";

export default function Link({
  scroll = false,
  ...props
}: ComponentProps<typeof NextLink>) {
  return <NextLink scroll={scroll} {...props} />;
}
