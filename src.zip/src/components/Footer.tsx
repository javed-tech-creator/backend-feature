import Link from "next/link";
import { services, siteLinks, socialLinks, terms } from "../lib/constant";
import mylogo from "../assets/my-logo.png";

export function Footer() {
  return (
    <footer className="bg-surface-alt border-t border-border mb-0">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Section */}
          <div className="lg:col-span-6">
            <Link
              href="/"
              className="inline-flex items-center transition-transform duration-300 hover:scale-[1.02]"
              aria-label="Mobizoo Home"
            >
              <div className="relative h-10 w-64 sm:h-14 sm:w-62 lg:h-15 lg:w-65">
                <img
                  src="/mobi-logo.webp"
                  alt="Mobizoo - Buy, Sell & Upgrade"
                  className="h-full w-full object-contain object-left"
                />
              </div>
            </Link>

            <p className=" text-text-light leading-8 max-w-lg">
              India's most trusted platform to sell your old mobile phones,
              tablets, laptops and gadgets. Get the best price and instant cash
              at your doorstep with MobiZoo.
            </p>

            <div className="flex items-center gap-4 mt-4">
              {socialLinks.map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="w-8 h-8 rounded-full border border-border flex items-center justify-center text-text-light hover:bg-primary hover:text-white hover:border-primary transition-all duration-300"
                >
                  <Icon size={14} />
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div className="lg:col-span-2">
            <h6 className="text-md font-semibold text-heading">Services</h6>

            <ul className="mt-2 space-y-2 text-text-light">
              {services.map((item) => (
                <li key={item.title}>
                  <Link
                    href={item.path}
                    className="hover:text-primary transition-colors"
                  >
                    {item.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Site Links */}
          <div className="lg:col-span-2">
            <h6 className="text-md font-semibold text-heading">Site Links</h6>

            <ul className="mt-2 space-y-2 text-text-light">
              {siteLinks.map((item) => (
                <li key={item.title}>
                  <Link
                    href={item.path}
                    className="hover:text-primary transition-colors"
                  >
                    {item.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Terms */}
          <div className="lg:col-span-2">
            <h6 className="text-md font-semibold text-heading">Terms</h6>

            <ul className="mt-2 space-y-2 text-text-light">
              {terms.map((item) => (
                <li key={item.title}>
                  <Link
                    href={item.path}
                    className="hover:text-primary transition-colors"
                  >
                    {item.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-border mt-10 pt-4">
          <div className="flex flex-col sm:flex-row justify-between sm:justify-start items-center text-center gap-1">
            <p className="text-xs lg:text-sm text-heading">
              © {2026} MobiZoo. All rights reserved.
            </p>
            <div className="flex flex-row items-center gap-2">
              <span className="text-primary text-xs lg:text-sm">
                Designed & Developed By
              </span>
              <img
                src={mylogo.src}
                className="w-8 h-8 sm:w-10 sm:h-10 object-contain transition-transform hover:scale-105"
                alt="company Logo"
              />
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
