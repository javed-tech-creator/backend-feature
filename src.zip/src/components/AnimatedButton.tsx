
const AnimatedButton = ({
  text = "+91 752 60 74 042",

  // Colors — theme tokens, override with any CSS colour
  bgColor = "var(--color-secondary)",
  textColor = "var(--color-surface)",

  // Size & spacing
  width = "30%",
  height = "50px",
  paddingX = "px-7",
  paddingY = "py-1.5",
  textSize = "text-[14px]",
  margintop = "0px",
  duration = 300,
  className = "",
  onClick = () => {},
}) => {
  return (
    <button
      onClick={onClick}
      className={`
         group flex relative uppercase tracking-tight rounded-md
        font-semibold items-center justify-center transition-all duration-500 ease-out hover:scale-105 hover:shadow-lg
        ${paddingX} ${paddingY} ${textSize} ${className}
      `}
      style={{
        color: textColor,
        width,
        height,
        marginTop: margintop,
        backgroundColor: bgColor,
        border: "1px solid transparent",
        transitionDuration: `${duration}ms`,
      }}
    >
      {/* TEXT (changes to white on hover) */}
      <span className="relative z-10 transition-colors duration-500 group-hover:text-white">
        {text}
      </span>
    </button>
  );
};

export default AnimatedButton;
