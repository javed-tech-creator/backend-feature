"use client";

import type { PriceBreakdown, QuestionnaireSessionData } from "@/lib/types";
import { Loader2 } from "lucide-react";
import Image from "next/image";

type FinalPriceCardProps = {
  session: QuestionnaireSessionData;
  priceResult: PriceBreakdown;
  state: string;
  city: string;
  onSellNow: () => void;
  sellLoading?: boolean;
};

const FinalPriceCard = ({
  session,
  priceResult,
  state,
  city,
  onSellNow,
  sellLoading = false,
}: FinalPriceCardProps) => {
  const { modelData, brandLabel, storageLabel, selectedStorage } = session;

  return (
    <div className="mx-auto w-full max-w-lg">
      <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
        <div className="bg-sky-50 px-5 py-4 text-center sm:px-6">
          <p className="text-sm font-medium text-gray-600">Your Final Assured Price</p>
          <p className="mt-1 text-3xl font-bold text-primary sm:text-4xl">
            ₹ {priceResult.finalOffer.toLocaleString()}
          </p>
        </div>

        <div className="flex flex-col items-center px-5 py-5 sm:px-6 sm:py-6">
          <div className="relative h-32 w-28 sm:h-36 sm:w-32">
            {modelData.logo ? (
              <Image
                src={modelData.logo}
                alt={modelData.name}
                fill
                sizes="128px"
                className="object-contain"
                priority
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center rounded-lg bg-gray-100 text-sm text-gray-400">
                No Image
              </div>
            )}
          </div>

          <h2 className="mt-4 text-center text-lg font-semibold text-heading sm:text-xl">
            {modelData.name}
          </h2>
          <p className="mt-1 text-sm text-gray-500">{brandLabel}</p>
          <p className="text-sm font-medium text-gray-700">{storageLabel}</p>

          <div className="mt-4 w-full space-y-2 rounded-xl bg-gray-50 p-4 text-sm">
            <div className="flex justify-between gap-4">
              <span className="text-gray-500">Expected Price</span>
              <span className="font-medium text-gray-800">
                ₹ {selectedStorage.basePrice.toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-gray-500">Pickup Location</span>
              <span className="text-right font-medium text-gray-800">
                {city}, {state}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onSellNow}
            disabled={sellLoading}
            className="
              mt-5 w-full rounded-lg bg-primary px-5 py-3 text-sm font-semibold text-white
              transition hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-60
              sm:text-base
            "
          >
            {sellLoading ? (
              <span className="inline-flex items-center justify-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                Processing...
              </span>
            ) : (
              "Sell Now"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default FinalPriceCard;
