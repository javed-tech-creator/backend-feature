"use client";

import {
  fetchQuestionnaire,
  submitQuestionnaireAnswers,
} from "@/action/questionnaire.action";
import { submitSellOrder } from "@/action/order.action";
import {
  flattenQuestions,
  getSelectedAnswerItems,
  isRejectedBreakdown,
  toCalculatorAnswers,
  toOrderAnswers,
  validateStepAnswers,
} from "@/helper/questionnaire.helper";
import { getQuestionnaireSession } from "@/lib/questionnaire-session";
import type {
  LocationSelection,
  PriceBreakdown,
  QuestionnaireAnswers,
  QuestionnaireData,
  QuestionnaireSessionData,
} from "@/lib/types";
import { Loader2 } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import toast from "react-hot-toast";
import FinalPriceCard from "./FinalPriceCard";
import LocationSelectModal from "./LocationSelectModal";
import LoginOtpModal from "./LoginOtpModal";
import QuestionRenderer from "./QuestionRenderer";
import QuestionnaireSidebar from "./QuestionnaireSidebar";

type ViewState = "wizard" | "result" | "rejected";

const PAGE_SHELL = "w-full px-3 py-5 sm:px-4 sm:py-6 md:px-6 lg:px-8";
const PAGE_CONTAINER = "mx-auto w-full max-w-7xl";
const PAGE_CARD =
  "rounded-2xl border border-gray-200 bg-sky-50 p-4 sm:p-6 md:p-8";
const MAIN_GRID =
  "grid gap-6 lg:grid-cols-[minmax(0,1fr)_280px] lg:gap-8 xl:grid-cols-[minmax(0,1fr)_300px]";

type QuestionnaireProps = {
  isLoggedIn?: boolean;
};

const Questionnaire = ({ isLoggedIn: initialIsLoggedIn = false }: QuestionnaireProps) => {
  const router = useRouter();

  const [session, setSession] = useState<QuestionnaireSessionData | null>(null);
  const [sessionReady, setSessionReady] = useState(false);

  const [questionnaire, setQuestionnaire] = useState<QuestionnaireData | null>(
    null,
  );
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [fetchLoading, setFetchLoading] = useState(true);

  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<QuestionnaireAnswers>({});
  const [stepError, setStepError] = useState<string | null>(null);

  const [submitLoading, setSubmitLoading] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [priceResult, setPriceResult] = useState<PriceBreakdown | null>(null);
  const [viewState, setViewState] = useState<ViewState>("wizard");
  const [loggedIn, setLoggedIn] = useState(initialIsLoggedIn);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [location, setLocation] = useState<LocationSelection | null>(null);
  const [sellLoading, setSellLoading] = useState(false);

  const steps = questionnaire?.steps ?? [];
  const totalSteps = steps.length;
  const activeStep = steps[currentStep];
  const allQuestions = useMemo(() => flattenQuestions(steps), [steps]);
  const selectedItems = useMemo(
    () => getSelectedAnswerItems(allQuestions, answers),
    [allQuestions, answers],
  );

  const backHref = session
    ? `/sell/${session.deviceSlug}/${session.brandSlug}/${session.modelSlug}/${session.storageSlug}`
    : "/sell/mobile";

  useEffect(() => {
    const stored = getQuestionnaireSession();
    setSession(stored);
    setSessionReady(true);
  }, []);

  const loadQuestionnaire = useCallback(async (deviceId: string) => {
    setFetchLoading(true);
    setFetchError(null);

    try {
      const response = await fetchQuestionnaire(deviceId);

      if (!response.success || !response.data) {
        setFetchError(
          response.message || "Unable to load questionnaire. Please try again.",
        );
        setQuestionnaire(null);
        return;
      }

      if (!response.data.steps?.length) {
        setFetchError("No questions are available for this device right now.");
        setQuestionnaire(null);
        return;
      }

      setQuestionnaire(response.data);
      setCurrentStep(0);
    } catch {
      setFetchError("Unable to load questionnaire. Please try again.");
      setQuestionnaire(null);
    } finally {
      setFetchLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!sessionReady) return;

    if (!session?.modelData?.deviceId) {
      setFetchLoading(false);
      return;
    }

    loadQuestionnaire(session.modelData.deviceId);
  }, [session, sessionReady, loadQuestionnaire]);

  const handleAnswerChange = (questionId: string, value: string | string[]) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
    setStepError(null);
  };

  const submitAnswers = useCallback(async () => {
    if (!session) return;

    setSubmitLoading(true);
    setSubmitError(null);

    try {
      const payload = {
        modelId: session.modelData._id,
        storageId: session.selectedStorage.storageId._id,
        answers: toCalculatorAnswers(allQuestions, answers),
      };

      const response = await submitQuestionnaireAnswers(payload);

      if (!response.success || !response.data) {
        setSubmitError(
          response.message || "Unable to calculate price. Please try again.",
        );
        toast.error(response.message || "Unable to calculate price.");
        return;
      }

      setPriceResult(response.data);

      if (isRejectedBreakdown(response.data)) {
        setViewState("rejected");
      } else {
        setViewState("result");
      }

      setIsLocationModalOpen(false);
    } catch {
      setSubmitError("Unable to calculate price. Please try again.");
      toast.error("Unable to calculate price.");
    } finally {
      setSubmitLoading(false);
    }
  }, [session, allQuestions, answers]);

  const handleLoginSuccess = useCallback(() => {
    setLoggedIn(true);
    setIsLoginModalOpen(false);
    setIsLocationModalOpen(true);
  }, []);

  const handleLocationConfirm = useCallback(
    async (state: string, city: string) => {
      setLocation({ state, city });
      await submitAnswers();
    },
    [submitAnswers],
  );

  const handleSellNow = useCallback(async () => {
    if (!session) return;

    setSellLoading(true);

    try {
      const response = await submitSellOrder({
        modelId: session.modelData._id,
        storageId: session.selectedStorage.storageId._id,
        orderType: "sell",
        answers: toOrderAnswers(allQuestions, answers),
      });

      if (!response.success) {
        toast.error(response.message || "Unable to place order. Please try again.");
        return;
      }

      toast.success(response.message || "Order placed successfully!");
      router.push("/");
    } catch {
      toast.error("Unable to place order. Please try again.");
    } finally {
      setSellLoading(false);
    }
  }, [session, allQuestions, answers, router]);

  const handleNext = async () => {
    if (!activeStep || !session) return;

    const validationError = validateStepAnswers(activeStep.questions, answers);

    if (validationError) {
      setStepError(validationError);
      return;
    }

    if (currentStep < totalSteps - 1) {
      setCurrentStep((prev) => prev + 1);
      setStepError(null);
      return;
    }

    if (!loggedIn) {
      setIsLoginModalOpen(true);
      return;
    }

    setIsLocationModalOpen(true);
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1);
      setStepError(null);
    }
  };

  const renderNavButtons = () => (
    <div className="mt-5 flex flex-row items-center justify-end gap-2">
      {currentStep > 0 ? (
        <button
          type="button"
          onClick={handleBack}
          disabled={submitLoading}
          className="
            rounded-lg border border-gray-200 bg-white px-4 py-2
            text-sm font-medium text-gray-600 transition
            hover:border-gray-300 hover:bg-gray-50
            disabled:cursor-not-allowed disabled:opacity-50
          "
        >
          Back
        </button>
      ) : (
        <Link
          href={backHref}
          className="
            rounded-lg border border-gray-200 bg-white px-4 py-2
            text-sm font-medium text-gray-600 transition
            hover:border-gray-300 hover:bg-gray-50
          "
        >
          Back
        </Link>
      )}

      <button
        type="button"
        onClick={handleNext}
        disabled={submitLoading}
        className="
          flex min-w-28 items-center justify-center gap-1.5 rounded-lg bg-primary
          px-4 py-2 text-sm font-medium text-white transition
          hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50
        "
      >
        {submitLoading ? (
          <>
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            Calculating...
          </>
        ) : currentStep < totalSteps - 1 ? (
          "Next"
        ) : (
          "Get Price"
        )}
      </button>
    </div>
  );

  if (!sessionReady) {
    return (
      <div className="flex min-h-[50vh] w-full items-center justify-center px-4">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }

  if (!session) {
    return (
      <div className={PAGE_SHELL}>
        <div className={PAGE_CONTAINER}>
          <div className={`${PAGE_CARD} text-center`}>
            <p className="text-sm text-red-500 sm:text-base">
              Session expired. Please select your device variant again.
            </p>
            <button
              type="button"
              onClick={() => router.back()}
              className="mt-4 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-white hover:opacity-90"
            >
              Go Back
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (fetchLoading) {
    return (
      <div className="flex min-h-[40vh] w-full items-center justify-center px-4">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-xs text-gray-500 sm:text-sm">Loading questions...</p>
        </div>
      </div>
    );
  }

  if (fetchError) {
    return (
      <div className={PAGE_SHELL}>
        <div className={PAGE_CONTAINER}>
          <div className={`${PAGE_CARD} text-center`}>
            <p className="text-sm text-red-500 sm:text-base">{fetchError}</p>
            <div className="mt-4 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <button
                type="button"
                onClick={() => loadQuestionnaire(session.modelData.deviceId)}
                className="rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-white hover:opacity-90"
              >
                Try Again
              </button>
              <Link
                href={backHref}
                className="rounded-lg border border-gray-300 bg-white px-5 py-2.5 text-sm font-semibold text-gray-700 hover:border-primary"
              >
                Go Back
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (viewState === "rejected" && priceResult) {
    return (
      <div className={PAGE_SHELL}>
        <div className={PAGE_CONTAINER}>
          <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-center sm:p-8 md:p-10">
            <h2 className="text-xl font-semibold text-red-700 sm:text-2xl md:text-3xl">
              Device Not Eligible
            </h2>
            <p className="mx-auto mt-3 max-w-xl text-sm text-red-600 sm:text-base">
              Based on your answers, we are unable to offer a price for this
              device at the moment.
            </p>
            <Link
              href={backHref}
              className="mt-6 inline-block rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-white hover:opacity-90 sm:text-base"
            >
              Choose Another Variant
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (viewState === "result" && priceResult && location) {
    return (
      <div className={PAGE_SHELL}>
        <div className={PAGE_CONTAINER}>
          <div className={PAGE_CARD}>
            <div className="mb-6 text-center">
              <h2 className="text-xl font-semibold text-heading sm:text-2xl md:text-3xl">
                Your Assured Selling Price
              </h2>
              <p className="mt-1 text-sm text-gray-600">
                Review your device details and sell instantly
              </p>
            </div>

            <FinalPriceCard
              session={session}
              priceResult={priceResult}
              state={location.state}
              city={location.city}
              onSellNow={handleSellNow}
              sellLoading={sellLoading}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className={PAGE_SHELL}>
        <div className={PAGE_CONTAINER}>
          <div className={PAGE_CARD}>
            <div className={MAIN_GRID}>
            {/* Left — Questions */}
            <div className="min-w-0">
              {currentStep === 0 ? (
                <div className="mb-5 border-b border-gray-200/80 pb-4">
                  <p className="text-sm text-gray-500 sm:text-base">
                    Help us evaluate your device and get the best price
                  </p>
                </div>
              ) : null}

              <div className="space-y-3 lg:space-y-4">
                {activeStep?.questions.map((question) => (
                  <QuestionRenderer
                    key={question._id}
                    question={question}
                    value={answers[question._id]}
                    onChange={handleAnswerChange}
                  />
                ))}
              </div>

              {stepError ? (
                <p className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600 sm:text-sm">
                  {stepError}
                </p>
              ) : null}

              {submitError ? (
                <p className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600 sm:text-sm">
                  {submitError}
                </p>
              ) : null}

              {renderNavButtons()}
            </div>

            {/* Right — Progress, device & selections */}
            <div className="hidden lg:block">
              <QuestionnaireSidebar
                session={session}
                selectedItems={selectedItems}
                currentStep={currentStep}
                totalSteps={totalSteps}
              />
            </div>
          </div>

          <div className="mt-6 border-t border-gray-200/80 pt-5 lg:hidden">
            <QuestionnaireSidebar
              session={session}
              selectedItems={selectedItems}
              currentStep={currentStep}
              totalSteps={totalSteps}
              variant="compact"
            />
          </div>
        </div>
      </div>
    </div>

      <LoginOtpModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onSuccess={handleLoginSuccess}
      />

      <LocationSelectModal
        isOpen={isLocationModalOpen}
        onClose={() => {
          if (!submitLoading) setIsLocationModalOpen(false);
        }}
        onConfirm={handleLocationConfirm}
        loading={submitLoading}
      />
    </>
  );
};

export default Questionnaire;
