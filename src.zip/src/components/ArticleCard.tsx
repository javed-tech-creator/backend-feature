import { CalendarDays, Tag, ArrowRight } from "lucide-react";
import Link from "@/components/Link";

export default function ArticleCard({ article }: { article: any }) {
  return (
    <div
      className="
      blog-card group relative flex flex-col h-full
      bg-surface
      border border-border rounded-2xl
      overflow-hidden transition-all duration-300
      hover:border-primary/40 hover:-translate-y-2
      w-full
    "
    >
      {/* IMAGE */}
      <div className="relative h-48 sm:h-56 overflow-hidden">
        {/* DATE */}
        <div className="absolute top-3 left-3 bg-heading/70 backdrop-blur-md px-2 py-1 text-xs rounded-lg flex items-center gap-1.5 text-white z-20">
          <CalendarDays className="w-3 h-3" />
          {article?.updatedAt?.split("T")[0]}
        </div>

        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={article?.image}
          alt={article.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
      </div>

      {/* CONTENT */}
      <div className="flex flex-col p-3 sm:p-4 grow">
        {/* Device */}
        <span className="absolute top-3 right-3 z-20 inline-flex items-center gap-1.5 w-fit px-3 py-1 rounded-full bg-surface border border-border text-xs text-text">
          <Tag className="w-3 h-3" />
          {article?.device || "Technology"}
        </span>

        {/* Title */}
        <h3 className="text-lg sm:text-xl font-bold text-heading line-clamp-2 leading-snug group-hover:text-primary transition-colors">
          {article.title}
        </h3>

        {/* Description */}
        <div className="text-text-light text-sm line-clamp-3 grow">
          <div dangerouslySetInnerHTML={{ __html: article.description }} />
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-border mt-4">
          <Link
            href={`/blog-detail/${article.slug}`}
            className="inline-flex items-center text-sm font-bold text-primary group-hover:text-primary"
          >
            Read Full Article
            <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </div>
    </div>
  );
}
