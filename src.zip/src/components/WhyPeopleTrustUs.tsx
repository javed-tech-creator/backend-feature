import { Handshake, ShieldCheck, ThumbsUp } from "lucide-react";
import trustPerson from "../assets/images/trust-person.png";
export default function WhyTrustUs() {
  const features = [
    {
      title: "Best value to your Gadgets",
      desc: "MyPhoneCash gives the best value to your gadgets because we put no price on the satisfaction of customer and we want to expand the customer base in market.",
      icon: <ThumbsUp />,
    },
    {
      title: "No misuse of device or data",
      desc: "You can be sure that your device will be processed securely and never fall into the wrong hands. At pickup time we will ensure right before your eyes that all your data is wiped.",
      icon: <ShieldCheck />,
    },
    {
      title: "Quick & Hassle-free",
      desc: "Seal the deal in just 3 steps! Say goodbye to standing at a shop counter and negotiating or going crazy answering messages from prospective buyers. Best Price - Zero Hassle!",
      icon: <Handshake />,
    },
  ];

  return (
    <section className="bg-surface-alt py-10 ">
      <div className="px-4.5 md:px-0 max-w-360 mx-auto text-center ">
        <h2 className="text-2xl md:text-4xl font-bold text-heading leading-tight ">
          Why people <span className="text-primary">trust us</span>
        </h2>
        <p className="text-text-light mt-2 mb-4">MyPhoneCash</p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          {/* Left: feature list */}
          <div className="space-y-5">
            {features.map((f) => (
              <div
                key={f.title}
                className="flex flex-col md:flex-row items-center gap-6"
              >
                {/* Fixed Icon Section */}
                <div className="w-20 flex justify-center">
                  <div className="flex h-20 w-20 items-center justify-center rounded-full bg-linear-to-br from-accent to-secondary shadow-lg shadow-secondary/20">
                    <svg
                      className="w-8 h-8 text-white"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      {f.icon}
                    </svg>
                  </div>
                </div>

                {/* Text Section */}
                <div className="flex-1 md:text-left">
                  <h3 className="text-xl font-bold text-heading">{f.title}</h3>

                  <p className="mt-2 text-text-light leading-relaxed">
                    {f.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Right: image with decorative rings */}
          <div className="flex justify-center items-end h-full">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={trustPerson.src}
              alt="Why people trust us"
              className="h-64 md:h-90 lg:h-115 w-auto  self-end object-contain"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
