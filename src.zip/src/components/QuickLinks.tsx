import Link from "@/components/Link";
import { quickLinks } from "../lib/constant";

export default function QuickLinks() {
  // Merge all brands into one array and remove duplicates

  return (
    <section className=" py-10 bg-background">
      <div className="px-4.5 md:px-0  max-w-360 mx-auto">
        <div className=" border border-border rounded-md p-4 bg-surface-alt">
          <h2 className="text-2xl font-semibold mb-4 text-heading">
            Quick <span className="text-primary">Links</span>
          </h2>

          <div className="flex flex-wrap gap-1">
            {quickLinks.map((item, index) => (
              <Link
                key={index}
                href={`/sell/${item.device}/${item.name
                  .toLowerCase()
                  .replace(/\s+/g, "-")}`}
                className="px-2 py-2 bg-surface border border-border rounded-md text-xs text-text hover:bg-primary hover:border-primary hover:text-white transition"
              >
                Sell Old {item.name}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
