"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import ArticleCard from "./ArticleCard";
import AnimatedButton from "./AnimatedButton";
import { FaArrowLeft, FaArrowRight } from "react-icons/fa";

export default function LatestArticlesSection() {
  const router = useRouter();
  const articles = [
    {
      id: 1,
      title: "How to Sell Your Old Phone at the Best Price",
      slug: "how-to-sell-your-old-phone",
      image: "https://picsum.photos/id/180/800/500",
      device: "Mobile",
      author: "MobiZoo Team",
      updatedAt: "2026-07-12T10:30:00.000Z",
      createdAt: "2026-07-12T10:30:00.000Z",
      readTime: "5 min read",
      views: 2450,
      likes: 185,
      featured: true,
      description: `
      <p>Selling your old smartphone doesn't have to be difficult. Learn how to prepare your phone, compare offers, erase your personal data safely, and maximize its resale value with expert tips.</p>
    `,
    },

    {
      id: 2,
      title: "7 Things to Do Before Selling Your Laptop",
      slug: "things-to-do-before-selling-laptop",
      image: "https://picsum.photos/id/48/800/500",
      device: "Laptop",
      author: "MobiZoo Team",
      updatedAt: "2026-07-10T09:00:00.000Z",
      createdAt: "2026-07-10T09:00:00.000Z",
      readTime: "6 min read",
      views: 1820,
      likes: 124,
      featured: false,
      description: `
      <p>Before selling your laptop, back up important files, remove personal information, reset the operating system, and clean the device to increase its resale price.</p>
    `,
    },

    {
      id: 3,
      title: "Online vs Offline: Which is Better for Selling Devices?",
      slug: "online-vs-offline-device-selling",
      image: "https://picsum.photos/id/20/800/500",
      device: "Guide",
      author: "MobiZoo Team",
      updatedAt: "2026-07-08T12:00:00.000Z",
      createdAt: "2026-07-08T12:00:00.000Z",
      readTime: "4 min read",
      views: 1560,
      likes: 98,
      featured: false,
      description: `
      <p>Discover the advantages of selling your old gadgets online compared to local mobile shops. Compare pricing, convenience, pickup services, and payment options.</p>
    `,
    },

    {
      id: 4,
      title: "How Secure Data Wiping Protects Your Privacy",
      slug: "secure-data-wiping-guide",
      image: "https://picsum.photos/id/119/800/500",
      device: "Security",
      author: "MobiZoo Team",
      updatedAt: "2026-07-05T15:15:00.000Z",
      createdAt: "2026-07-05T15:15:00.000Z",
      readTime: "7 min read",
      views: 1980,
      likes: 145,
      featured: true,
      description: `
      <p>Protect your personal information by securely erasing your phone, laptop, or tablet before selling. Learn the safest methods for complete data removal.</p>
    `,
    },

    {
      id: 5,
      title: "Top Smartphones With the Best Resale Value",
      slug: "best-resale-smartphones-2026",
      image: "https://picsum.photos/id/160/800/500",
      device: "Resale Value",
      author: "MobiZoo Team",
      updatedAt: "2026-07-03T11:20:00.000Z",
      createdAt: "2026-07-03T11:20:00.000Z",
      readTime: "5 min read",
      views: 3150,
      likes: 276,
      featured: true,
      description: `
      <p>Explore the smartphones that offer the highest resale value in 2026, including iPhone, Samsung Galaxy, OnePlus, Google Pixel, and more.</p>
    `,
    },

    {
      id: 6,
      title: "Complete Checklist Before Selling Any Gadget",
      slug: "device-selling-checklist",
      image: "https://picsum.photos/id/250/800/500",
      device: "Tips",
      author: "MobiZoo Team",
      updatedAt: "2026-07-01T08:45:00.000Z",
      createdAt: "2026-07-01T08:45:00.000Z",
      readTime: "8 min read",
      views: 2740,
      likes: 192,
      featured: false,
      description: `
      <p>From removing accounts to cleaning accessories and checking warranty status, follow this complete checklist to sell your gadget quickly and at the best price.</p>
    `,
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [slidesPerView, setSlidesPerView] = useState(1);

  // RESPONSIVE SLIDES
  useEffect(() => {
    const updateSlides = () => {
      if (window.innerWidth >= 1024) setSlidesPerView(3);
      else if (window.innerWidth >= 768) setSlidesPerView(2);
      else setSlidesPerView(1);
    };

    updateSlides();
    window.addEventListener("resize", updateSlides);
    return () => window.removeEventListener("resize", updateSlides);
  }, []);

  const nextSlide = () => {
    setCurrentIndex((prev) =>
      prev >= articles.length - slidesPerView ? 0 : prev + 1,
    );
  };

  const prevSlide = () => {
    setCurrentIndex((prev) =>
      prev === 0 ? articles.length - slidesPerView : prev - 1,
    );
  };

  // Auto Slide
  useEffect(() => {
    const interval = setInterval(nextSlide, 3000);
    return () => clearInterval(interval);
  });

  return (
    <section className=" bg-surface-alt py-10 overflow-hidden">
      <div className="px-4.5 md:px-0 max-w-360 mx-auto">
        <div className="text-center mb-6">
          <h2 className="text-2xl md:text-4xl font-bold text-heading">
            Latest <span className="text-primary">Articles</span>
          </h2>

          <p className="mt-2 text-text-light max-w-2xl mx-auto">
            Explore expert tips, resale guides, and the latest insights to help
            you sell your old phones, laptops, tablets, and other gadgets for
            the best possible value.
          </p>
        </div>

        {/* SLIDER MAIN WRAPPER */}
        <div className="relative w-full overflow-hidden ">
          {/* TRACK */}
          <div
            className="flex transition-transform duration-500 ease-out"
            style={{
              transform: `translateX(-${
                (currentIndex * 100) / slidesPerView
              }%)`,
            }}
          >
            {articles.map((article) => (
              <div
                key={article.id}
                className="shrink-0 px-2 sm:px-3"
                style={{ width: `${100 / slidesPerView}%` }}
              >
                <ArticleCard article={article} />
              </div>
            ))}
          </div>

          {/* LEFT BTN */}
          <button
            onClick={prevSlide}
            className="absolute left-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-primary/80 p-2 text-white shadow-md backdrop-blur-sm transition hover:bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white sm:left-4 sm:p-3"
          >
            <FaArrowLeft className="h-3.5 w-3.5 sm:h-5 sm:w-5" />
          </button>

          {/* RIGHT BTN */}
          <button
            onClick={nextSlide}
            className=" absolute right-2 top-1/2 z-10 -translate-y-1/2 rounded-full bg-primary/80 p-2 text-white shadow-md backdrop-blur-sm transition hover:bg-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white sm:right-4 sm:p-3"
          >
            <FaArrowRight className="h-3.5 w-3.5 sm:h-5 sm:w-5" />
          </button>
        </div>

        {/* DOTS */}
        <div className="flex justify-center gap-2 mt-8 ">
          {articles
            .slice(0, articles.length - (slidesPerView - 1))
            .map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`transition-all duration-300 rounded-full ${
                  currentIndex === index
                    ? "bg-primary w-8 h-3"
                    : "bg-border w-3 h-3 hover:bg-text-light"
                }`}
              />
            ))}
        </div>

        {/* BUTTON */}
        <div className="flex justify-center mt-12">
          <AnimatedButton
            text="View Articles"
            width="170px"
            height="45px"
            bgColor="var(--color-primary)"
            onClick={() => router.push("/blog", { scroll: false })}
          />
        </div>
      </div>
    </section>
  );
}
