"use client";

import Image from "next/image";
import { useState } from "react";

type Storage = {
  _id: string;
  name: string;
  slug: string;
};

type StorageSelectorProps = {
  modelName: string;
  modelImage?: string;
  storages: Storage[];
  onSelect?: (storage: Storage) => void;
};

const StorageSelector = ({
  modelName,
  modelImage,
  storages,
  onSelect,
}: StorageSelectorProps) => {
  const [selectedStorage, setSelectedStorage] =
    useState<string | null>(null);

  const handleSelect = (storage: Storage) => {
    setSelectedStorage(storage._id);

    onSelect?.(storage);
  };

  return (
    <section className="w-full px-3 py-5 sm:px-4 sm:py-8 md:px-6 lg:px-8">
      <div className="mx-auto w-full max-w-6xl rounded-2xl border border-gray-200 bg-surface-alt p-4 sm:p-6 md:p-8">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-start md:gap-10">
          
          {/* Model Image */}
          <div className="flex w-full justify-center sm:w-60 md:w-70">
            <div className="relative h-52 w-44 sm:h-60 sm:w-52 md:h-65 md:w-56">
              {modelImage ? (
                <Image
                  src={modelImage}
                  alt={modelName}
                  fill
                  sizes="(max-width: 640px) 176px, 224px"
                  className="object-contain"
                  priority
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center rounded-xl bg-gray-100 text-sm text-gray-400">
                  No Image
                </div>
              )}
            </div>
          </div>

          {/* Model Details */}
          <div className="w-full flex-1">
            <h1 className="text-xl font-medium text-gray-800 sm:text-2xl md:text-3xl">
              {modelName}
            </h1>

            <p className="mt-5 text-sm font-medium text-gray-700 sm:text-base">
              Select Variant
            </p>

            {/* Storage List */}
            <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
              {storages.map((storage) => {
                const isSelected =
                  selectedStorage === storage._id;

                return (
                  <button
                    key={storage._id}
                    type="button"
                    onClick={() => handleSelect(storage)}
                    className={`
                      min-h-18
                      rounded-lg
                      border
                      px-3
                      py-3
                      text-sm
                      font-medium
                      transition-all
                      duration-200
                      cursor-pointer
                      sm:min-h-20
                      sm:text-base
                      ${
                        isSelected
                          ? "border-primary bg-primary text-white shadow-sm"
                          : "border-gray-200 bg-white text-gray-700 hover:border-primary hover:text-primary"
                      }
                    `}
                  >
                    {storage.name}
                  </button>
                );
              })}
            </div>

            {!storages.length && (
              <p className="mt-4 text-sm text-gray-500">
                No storage variants available.
              </p>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default StorageSelector;