"use client";

import { useRef, useState } from "react";
import { ArrowLeft, Loader2, ShieldCheck, Smartphone, X } from "lucide-react";
import toast from "react-hot-toast";
import { checkPhone, sendOtp, verifyOtp } from "@/api/auth.api";

interface LoginOtpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type Step = "phone" | "details" | "otp";

const LoginOtpModal = ({ isOpen, onClose }: LoginOtpModalProps) => {
  const [step, setStep] = useState<Step>("phone");

  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const [otp, setOtp] = useState<string[]>(["", "", "", "", "", ""]);

  const [isNewUser, setIsNewUser] = useState(false);
  const [loading, setLoading] = useState(false);

  const [phoneError, setPhoneError] = useState("");
  const [nameError, setNameError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [otpError, setOtpError] = useState("");

  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  // --------------------------------------------------
  // Validate phone
  // --------------------------------------------------

  const validatePhone = (): boolean => {
    if (!phone.trim()) {
      setPhoneError("Phone number is required.");
      return false;
    }

    if (!/^[6-9]\d{9}$/.test(phone.trim())) {
      setPhoneError("Please enter a valid 10-digit mobile number.");
      return false;
    }

    setPhoneError("");
    return true;
  };

  // --------------------------------------------------
  // Validate new user details
  // Name & email are OPTIONAL
  // --------------------------------------------------

  const validateDetails = (): boolean => {
    setNameError("");
    setEmailError("");

    // Name REQUIRED
    if (!name.trim()) {
      setNameError("Full name is required.");
      return false;
    }

    if (name.trim().length < 2) {
      setNameError("Name must be at least 2 characters.");
      return false;
    }

    // Email OPTIONAL
    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setEmailError("Please enter a valid email address.");
      return false;
    }

    return true;
  };

  // --------------------------------------------------
  // Check phone
  // --------------------------------------------------

  const handlePhoneContinue = async () => {
    if (!validatePhone()) return;

    try {
      setLoading(true);

      const response = await checkPhone(phone.trim());

      if (!response.success) {
        setPhoneError(response.message || "Unable to check phone number.");
        return;
      }

      const data = response.data;

      if (!data) {
        setPhoneError("Invalid response from server.");
        return;
      }

      const { exists, isNewUser } = data;

      setIsNewUser(isNewUser);

      // --------------------------------------------
      // Existing user
      // Directly send OTP
      // --------------------------------------------

      if (exists && !isNewUser) {
        await handleSendOtp(false);
        return;
      }

      // --------------------------------------------
      // New user
      // Show name/email screen
      // --------------------------------------------

      setStep("details");
    } catch (error) {
      console.error("Check phone error:", error);

      setPhoneError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // --------------------------------------------------
  // Send OTP
  // --------------------------------------------------

  const handleSendOtp = async (newUser: boolean) => {
    if (newUser && !validateDetails()) {
      return;
    }

    try {
      setLoading(true);

      const response = await sendOtp({
        phone: phone.trim(),

        ...(newUser
          ? {
              ...(name.trim()
                ? {
                    fullName: name.trim(),
                  }
                : {}),

              ...(email.trim()
                ? {
                    email: email.trim(),
                  }
                : {}),
            }
          : {}),
      });

      if (!response.success) {
        const message = response.message || "Failed to send OTP.";

        if (step === "details") {
          setEmailError(message);
        } else {
          setPhoneError(message);
        }

        toast.error(message);
        return;
      }

      setOtp(["", "", "", "", "", ""]);

      setOtpError("");
      setStep("otp");

      toast.success(response.message || "OTP sent successfully.");

      // Focus first OTP input
      setTimeout(() => {
        otpRefs.current[0]?.focus();
      }, 100);
    } catch (error) {
      console.error("Send OTP error:", error);

      toast.error("Something went wrong while sending OTP.");
    } finally {
      setLoading(false);
    }
  };

  // --------------------------------------------------
  // OTP input change
  // --------------------------------------------------

  const handleOtpChange = (index: number, value: string) => {
    const digit = value.replace(/\D/g, "").slice(-1);

    const newOtp = [...otp];
    newOtp[index] = digit;

    setOtp(newOtp);

    if (otpError) {
      setOtpError("");
    }

    if (digit && index < 5) {
      otpRefs.current[index + 1]?.focus();
    }
  };

  // --------------------------------------------------
  // OTP keyboard
  // --------------------------------------------------

  const handleOtpKeyDown = (
    index: number,
    e: React.KeyboardEvent<HTMLInputElement>,
  ) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }

    if (e.key === "ArrowLeft" && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }

    if (e.key === "ArrowRight" && index < 5) {
      otpRefs.current[index + 1]?.focus();
    }
  };

  // --------------------------------------------------
  // OTP paste
  // --------------------------------------------------

  const handleOtpPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();

    const pastedData = e.clipboardData
      .getData("text")
      .replace(/\D/g, "")
      .slice(0, 6);

    if (!pastedData) return;

    const newOtp = ["", "", "", "", "", ""];

    pastedData.split("").forEach((digit, index) => {
      newOtp[index] = digit;
    });

    setOtp(newOtp);
    setOtpError("");

    const focusIndex = Math.min(pastedData.length, 5);

    setTimeout(() => {
      otpRefs.current[focusIndex]?.focus();
    }, 0);
  };

  // --------------------------------------------------
  // Verify OTP
  // --------------------------------------------------

  const verifyOTP = async () => {
    const otpValue = otp.join("");

    if (!/^\d{6}$/.test(otpValue)) {
      setOtpError("Please enter a valid 6-digit OTP.");
      return;
    }

    setOtpError("");

    try {
      setLoading(true);

      const response = await verifyOtp({
        phone: phone.trim(),
        otp: otpValue,
      });

      if (!response.success) {
        setOtpError(response.message || "Invalid OTP.");
        toast.error(response.message || "Invalid OTP.");

        return;
      }

      toast.success(response.message || "Login successful.");
      resetForm();
      onClose();
    } catch (error) {
      setOtpError("Something went wrong while verifying OTP.");
    } finally {
      setLoading(false);
    }
  };

  // --------------------------------------------------
  // Back from details to phone
  // --------------------------------------------------

  const handleBackToPhone = () => {
    setStep("phone");

    setNameError("");
    setEmailError("");
    setOtpError("");
  };

  const resetForm = () => {
    setStep("phone");

    setPhone("");
    setName("");
    setEmail("");

    setOtp(["", "", "", "", "", ""]);

    setIsNewUser(false);
    setLoading(false);

    setPhoneError("");
    setNameError("");
    setEmailError("");
    setOtpError("");

    otpRefs.current = [];
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  // --------------------------------------------------
  // Change phone
  // --------------------------------------------------

  const changeNumber = () => {
   resetForm();
    setTimeout(() => {
      document.getElementById("phone-input")?.focus();
    }, 100);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 px-4 backdrop-blur-sm sm:px-6">
      <div className="relative w-full max-w-md overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-[0_30px_80px_rgba(15,23,42,0.18)]">
        <div className="absolute inset-x-0 top-0 h-1.5 bg-linear-to-r from-sky-500 via-blue-500 to-emerald-500" />

        <div className="p-5 sm:p-7">
          {/* Header */}
          <div className="mb-6 flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
                <Smartphone className="h-5 w-5" />
              </div>

              <div>
                <p className="text-xs font-medium uppercase tracking-[0.18em] text-blue-600">
                  Secure login
                </p>

                <h2 className="text-xl font-semibold text-slate-900">
                  {step === "otp"
                    ? "Verify your number"
                    : step === "details"
                      ? "Complete your details"
                      : "Continue with OTP"}
                </h2>
              </div>
            </div>

            <button
              type="button"
              onClick={handleClose}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 text-slate-500 transition hover:border-slate-300 hover:text-slate-700"
              aria-label="Close modal"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* ==========================================
              PHONE STEP
          =========================================== */}

          {step === "phone" && (
            <div className="space-y-5">
              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-3">
                <div className="flex items-center gap-2 text-sm font-medium text-slate-700">
                  <ShieldCheck className="h-4 w-4 text-emerald-500" />
                  No spam, just secure verification.
                </div>
              </div>

              <div>
                <label
                  htmlFor="phone-input"
                  className="mb-2 block text-sm font-medium text-slate-700"
                >
                  Mobile Number
                  <span className="ml-1 text-red-500">*</span>
                </label>

                <div
                  className={`flex overflow-hidden rounded-2xl border bg-white transition ${
                    phoneError
                      ? "border-red-400 bg-red-50"
                      : "border-slate-200 focus-within:border-blue-500 focus-within:ring-4 focus-within:ring-blue-100"
                  }`}
                >
                  <div className="flex shrink-0 items-center border-r border-slate-200 bg-slate-50 px-3 text-sm font-semibold text-slate-700 sm:px-4">
                    +91
                  </div>

                  <input
                    id="phone-input"
                    type="tel"
                    inputMode="numeric"
                    autoComplete="tel"
                    placeholder="Enter 10-digit mobile number"
                    value={phone}
                    maxLength={10}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, "");

                      setPhone(value);

                      if (phoneError) {
                        setPhoneError("");
                      }
                    }}
                    className="min-w-0 flex-1 bg-transparent px-3 py-3.5 text-base text-slate-800 outline-none placeholder:text-slate-400 sm:px-4"
                  />
                </div>

                {phoneError && (
                  <p className="mt-1.5 text-sm text-red-500">{phoneError}</p>
                )}
              </div>

              <button
                type="button"
                disabled={loading}
                onClick={handlePhoneContinue}
                className="w-full flex w-full items-center justify-center rounded-2xl bg-linear-to-r from-sky-600 to-blue-600 px-4 py-3.5 text-sm font-semibold text-white shadow-lg shadow-blue-500/20 transition hover:brightness-105 active:scale-[0.99] items-center disabled:cursor-not-allowed disabled:opacity-60 sm:text-base"
              >
                {loading ? <Loader2 className="animate-spin" /> : "Continue"}
              </button>
            </div>
          )}

          {/* ==========================================
              NEW USER DETAILS STEP
          =========================================== */}

          {step === "details" && (
            <div className="space-y-5">
              <div className="rounded-2xl border border-blue-100 bg-blue-50 px-4 py-3">
                <p className="text-sm text-slate-600">
                  Create your account. Name and email are optional.
                </p>
              </div>

              {/* Name */}
              <div>
                <label
                  htmlFor="name-input"
                  className="mb-2 block text-sm font-medium text-slate-700"
                >
                  Full Name
                  <span className="ml-1 text-red-500">*</span>
                </label>

                <input
                  id="name-input"
                  type="text"
                  required
                  placeholder="Enter your full name"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);

                    if (nameError) {
                      setNameError("");
                    }
                  }}
                  className={`w-full rounded-2xl border bg-white px-3 py-3.5 text-base text-slate-800 outline-none transition placeholder:text-slate-400 ${
                    nameError
                      ? "border-red-400 bg-red-50"
                      : "border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
                  }`}
                />

                {nameError && (
                  <p className="mt-1.5 text-sm text-red-500">{nameError}</p>
                )}
              </div>

              {/* Email */}
              <div>
                <label
                  htmlFor="email-input"
                  className="mb-2 block text-sm font-medium text-slate-700"
                >
                  Email Address
                  <span className="ml-1 text-xs font-normal text-slate-400">
                    (Optional)
                  </span>
                </label>

                <input
                  id="email-input"
                  type="email"
                  placeholder="Enter your email address"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);

                    if (emailError) {
                      setEmailError("");
                    }
                  }}
                  className={`w-full rounded-2xl border bg-white px-3 py-3.5 text-base text-slate-800 outline-none transition placeholder:text-slate-400 ${
                    emailError
                      ? "border-red-400 bg-red-50"
                      : "border-slate-200 focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
                  }`}
                />

                {emailError && (
                  <p className="mt-1.5 text-sm text-red-500">{emailError}</p>
                )}
              </div>

              <button
                type="button"
                disabled={loading}
                onClick={() => handleSendOtp(true)}
                className="w-full rounded-2xl bg-linear-to-r from-sky-600 to-blue-600 px-4 py-3.5 text-sm font-semibold text-white shadow-lg shadow-blue-500/20 transition hover:brightness-105 active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-60 sm:text-base"
              >
                {loading ? "Sending OTP..." : "Continue & Send OTP"}
              </button>

              <button
                type="button"
                disabled={loading}
                onClick={handleBackToPhone}
                className="mx-auto flex items-center gap-2 text-sm font-medium text-slate-600 transition hover:text-blue-600"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </button>
            </div>
          )}

          {/* ==========================================
              OTP STEP
          =========================================== */}

          {step === "otp" && (
            <div className="space-y-5">
              <div className="rounded-2xl border border-blue-100 bg-blue-50 px-4 py-3 text-center">
                <p className="text-sm text-slate-600">
                  We sent a 6-digit OTP to
                </p>

                <p className="mt-1 text-base font-semibold text-slate-900">
                  +91 {phone}
                </p>
              </div>

              <div>
                <div className="flex justify-center gap-2 sm:gap-3">
                  {otp.map((digit, index) => (
                    <input
                      key={index}
                      ref={(element) => {
                        otpRefs.current[index] = element;
                      }}
                      type="text"
                      inputMode="numeric"
                      autoComplete={index === 0 ? "one-time-code" : "off"}
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleOtpChange(index, e.target.value)}
                      onKeyDown={(e) => handleOtpKeyDown(index, e)}
                      onPaste={handleOtpPaste}
                      className={`h-12 w-11 rounded-xl border text-center text-lg font-bold outline-none transition sm:h-14 sm:w-12 sm:text-xl ${
                        otpError
                          ? "border-red-400 bg-red-50 text-red-600"
                          : digit
                            ? "border-blue-500 bg-blue-50 text-blue-700"
                            : "border-slate-200 bg-white text-slate-800 focus:border-blue-500 focus:ring-4 focus:ring-blue-100"
                      }`}
                    />
                  ))}
                </div>

                {otpError && (
                  <p className="mt-2 text-center text-sm text-red-500">
                    {otpError}
                  </p>
                )}
              </div>

              <button
                type="button"
                disabled={loading}
                onClick={verifyOTP}
                className="w-full rounded-2xl bg-linear-to-r from-emerald-500 to-green-600 px-4 py-3.5 text-sm font-semibold text-white shadow-lg shadow-emerald-500/20 transition hover:brightness-105 active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-60 sm:text-base"
              >
                {loading ? "Verifying..." : "Verify OTP"}
              </button>

              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <button
                  type="button"
                  onClick={() => {
                    setStep(isNewUser ? "details" : "phone");
                    setOtpError("");
                  }}
                  className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 transition hover:text-blue-600"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Back
                </button>

                <button
                  type="button"
                  onClick={changeNumber}
                  disabled={loading}
                  className="text-sm font-medium text-slate-600 transition hover:text-blue-600 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  Change number
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LoginOtpModal;
