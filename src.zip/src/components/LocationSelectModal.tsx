"use client";

import { getIndianCities, getIndianStates } from "@/action/location.action";
import { Loader2, MapPin, RefreshCw, X } from "lucide-react";
import { useCallback, useEffect, useState } from "react";

type LocationSelectModalProps = {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (state: string, city: string) => void;
  loading?: boolean;
};

const LocationSelectModal = ({
  isOpen,
  onClose,
  onConfirm,
  loading = false,
}: LocationSelectModalProps) => {
  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [error, setError] = useState("");

  const [states, setStates] = useState<string[]>([]);
  const [cities, setCities] = useState<string[]>([]);
  const [statesLoading, setStatesLoading] = useState(false);
  const [citiesLoading, setCitiesLoading] = useState(false);
  const [fetchError, setFetchError] = useState<string | null>(null);

  const loadStates = useCallback(async () => {
    setStatesLoading(true);
    setFetchError(null);

    try {
      const response = await getIndianStates();

      if (!response.success) {
        setFetchError(response.message);
        setStates([]);
        return;
      }

      setStates(response.data);
    } catch {
      setFetchError("Unable to load states. Please try again.");
      setStates([]);
    } finally {
      setStatesLoading(false);
    }
  }, []);

  const loadCities = useCallback(async (selectedState: string) => {
    setCitiesLoading(true);
    setFetchError(null);

    try {
      const response = await getIndianCities(selectedState);

      if (!response.success) {
        setFetchError(response.message);
        setCities([]);
        return;
      }

      setCities(response.data);
    } catch {
      setFetchError("Unable to load cities. Please try again.");
      setCities([]);
    } finally {
      setCitiesLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!isOpen) {
      setState("");
      setCity("");
      setError("");
      setCities([]);
      setFetchError(null);
      return;
    }

    void loadStates();
  }, [isOpen, loadStates]);

  useEffect(() => {
    if (!state) {
      setCities([]);
      return;
    }

    void loadCities(state);
  }, [state, loadCities]);

  if (!isOpen) return null;

  const handleStateChange = (value: string) => {
    setState(value);
    setCity("");
    setError("");
    setFetchError(null);
  };

  const handleSubmit = () => {
    if (!state) {
      setError("Please select your state.");
      return;
    }

    if (!city) {
      setError("Please select your city.");
      return;
    }

    setError("");
    onConfirm(state, city);
  };

  const isFormDisabled = loading || statesLoading;

  return (
    <div className="fixed inset-0 z-9999 flex items-center justify-center bg-black/50 p-4">
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-xl">
        <button
          type="button"
          onClick={onClose}
          disabled={loading}
          className="absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full text-gray-500 transition hover:bg-gray-100"
          aria-label="Close"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="p-5 sm:p-6">
          <div className="mb-5 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-sky-100 text-primary">
              <MapPin className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-heading">Pickup Location</h2>
              <p className="text-sm text-gray-500">Select your state and city</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label htmlFor="state" className="mb-1.5 block text-sm font-medium text-gray-700">
                State
              </label>
              <div className="relative">
                <select
                  id="state"
                  value={state}
                  onChange={(e) => handleStateChange(e.target.value)}
                  disabled={isFormDisabled}
                  className="
                    w-full rounded-lg border border-gray-300 bg-white px-3 py-2.5 text-sm
                    text-gray-800 outline-none transition
                    focus:border-primary focus:ring-2 focus:ring-primary/20
                    disabled:cursor-not-allowed disabled:opacity-60
                  "
                >
                  <option value="">
                    {statesLoading ? "Loading states..." : "Select state"}
                  </option>
                  {states.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
                {statesLoading ? (
                  <Loader2 className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-gray-400" />
                ) : null}
              </div>
            </div>

            <div>
              <label htmlFor="city" className="mb-1.5 block text-sm font-medium text-gray-700">
                City
              </label>
              <div className="relative">
                <select
                  id="city"
                  value={city}
                  onChange={(e) => {
                    setCity(e.target.value);
                    setError("");
                  }}
                  disabled={!state || citiesLoading || loading}
                  className="
                    w-full rounded-lg border border-gray-300 bg-white px-3 py-2.5 text-sm
                    text-gray-800 outline-none transition
                    focus:border-primary focus:ring-2 focus:ring-primary/20
                    disabled:cursor-not-allowed disabled:bg-gray-50 disabled:opacity-60
                  "
                >
                  <option value="">
                    {!state
                      ? "Select state first"
                      : citiesLoading
                        ? "Loading cities..."
                        : "Select city"}
                  </option>
                  {cities.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
                {citiesLoading ? (
                  <Loader2 className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-gray-400" />
                ) : null}
              </div>
            </div>
          </div>

          {fetchError ? (
            <div className="mt-3 flex items-center justify-between gap-2 rounded-lg bg-red-50 px-3 py-2">
              <p className="text-sm text-red-600">{fetchError}</p>
              <button
                type="button"
                onClick={() => (state ? void loadCities(state) : void loadStates())}
                disabled={statesLoading || citiesLoading}
                className="flex shrink-0 items-center gap-1 text-xs font-medium text-red-700 hover:underline"
              >
                <RefreshCw className="h-3 w-3" />
                Retry
              </button>
            </div>
          ) : null}

          {error ? <p className="mt-3 text-sm text-red-500">{error}</p> : null}

          <button
            type="button"
            onClick={handleSubmit}
            disabled={loading || statesLoading || citiesLoading || !states.length}
            className="
              mt-5 flex w-full items-center justify-center gap-2 rounded-lg bg-primary
              px-4 py-2.5 text-sm font-semibold text-white transition
              hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-60
            "
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Calculating Price...
              </>
            ) : (
              "Continue"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default LocationSelectModal;
