"use client";

import Image from "next/image";
import type { Brand } from "@/lib/types";
import Link from "@/components/Link";
import { useCallback, useEffect, useRef, useState } from "react";
import { loadMoreBrands } from "@/action/device.action";
import { deviceLabel } from "@/helper/common.helper";

type BrandListProps = {
  brands: Brand[];
  hasMore?: boolean;
  nextCursor: string | null;
  deviceSlug: string;
};

const BrandList = ({
  brands,
  hasMore = false,
  nextCursor,
  deviceSlug,
}: BrandListProps) => {
  const [brandList, setBrandList] = useState<Brand[]>(brands);
  const [cursor, setCursor] = useState<string | null>(nextCursor);
  const [hasMoreBrands, setHasMoreBrands] = useState<boolean>(hasMore);
  const [loading, setLoading] = useState<boolean>(false);

  const observerRef = useRef<HTMLDivElement | null>(null);

  const handleLoadMore = useCallback(async () => {
    if (!cursor || loading || !hasMoreBrands) return;

    try {
      setLoading(true);

      const response = await loadMoreBrands({
        slug: deviceSlug,
        limit: 24,
        cursor,
      });

      if (!response.success) {
        return;
      }

      setBrandList((prev) => [...prev, ...response.data.data]);

      setCursor(response.data.nextCursor);
      setHasMoreBrands(response.data.hasMore);
    } catch (error) {
      console.error("Load more brands error:", error);
    } finally {
      setLoading(false);
    }
  }, [cursor, loading, hasMoreBrands, deviceSlug]);

  useEffect(() => {
    const element = observerRef.current;

    if (!element || !hasMoreBrands) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          handleLoadMore();
        }
      },
      {
        rootMargin: "200px",
      },
    );

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, [handleLoadMore, hasMoreBrands]);

  const label = deviceLabel(deviceSlug);
  return (
    <section className="w-full  px-3 py-5 sm:px-4 sm:py-6 md:px-6 lg:px-8">
      {/* Page title */}
      <div className="mx-auto mb-3 w-full max-w-7xl text-center sm:mb-4">
        <h1 className="text-base font-bold text-heading sm:text-lg md:text-2xl">
          Sell Used {label}
        </h1>
        <p className="mt-0.5 text-[11px] text-gray-500 sm:text-xs md:text-sm">
          Choose a brand to get started
        </p>
      </div>

      {!brandList.length ? (
        <div className="flex min-h-50 items-center justify-center px-4">
          <p className="text-center text-sm text-gray-500 sm:text-base">
            No brands found.
          </p>
        </div>
      ) : (
        <>
          <div
            className="
              mx-auto
              grid
              w-full
              max-w-7xl
              grid-cols-2
              gap-3
              sm:grid-cols-3
              sm:gap-4
              md:grid-cols-4
              lg:grid-cols-8
              xl:grid-cols-8
            "
          >
            {brandList.map((brand) => (
              <Link
                key={brand._id}
                href={`/sell/${deviceSlug}/${brand.slug}`}
                className="
      group
      mx-auto
      flex
      h-28
      w-full
      max-w-35
      flex-col
      items-center
      justify-center
      rounded-xl
      border
      border-gray-200
      bg-surface-alt
      p-2.5
      transition-all
      duration-200
      hover:-translate-y-1
      hover:border-gray-300
      hover:shadow-md
      sm:h-32
      sm:max-w-40
      sm:p-3
    "
              >
                <div className="relative mb-2 flex h-10 w-full items-center justify-center sm:mb-3 sm:h-12">
                  {brand.logo ? (
                    <Image
                      src={brand.logo}
                      alt={`${brand.name} logo`}
                      fill
                      sizes="48px"
                      className="object-contain transition-transform duration-200 group-hover:scale-105"
                    />
                  ) : (
                    <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-100 text-xs font-semibold text-gray-500 sm:h-10 sm:w-10">
                      {brand.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                </div>

                <h2 className="w-full whitespace-normal wrap-break-word text-center text-xs font-medium text-gray-800 sm:text-sm">
                  {brand.name}
                </h2>
              </Link>
            ))}
          </div>

          {/* Infinite Scroll Trigger */}
          {hasMoreBrands && (
            <div
              ref={observerRef}
              className="flex min-h-20 items-center justify-center py-6"
            >
              {loading && (
                <div className="flex items-center gap-2 text-sm text-gray-500">
                  <span className="h-5 w-5 animate-spin rounded-full border-2 border-gray-300 border-t-primary" />
                  Loading more brands...
                </div>
              )}
            </div>
          )}
        </>
      )}
    </section>
  );
};

export default BrandList;
