"use server";

import { fetchIndianCities, fetchIndianStates } from "@/lib/location-api";

export async function getIndianStates() {
  try {
    const data = await fetchIndianStates();
    return { success: true as const, data };
  } catch {
    return {
      success: false as const,
      message: "Unable to load states. Please try again.",
    };
  }
}

export async function getIndianCities(state: string) {
  if (!state.trim()) {
    return { success: false as const, message: "Please select a state first." };
  }

  try {
    const data = await fetchIndianCities(state);
    return { success: true as const, data };
  } catch {
    return {
      success: false as const,
      message: "Unable to load cities. Please try again.",
    };
  }
}
