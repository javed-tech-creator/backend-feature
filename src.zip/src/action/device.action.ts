"use server";

import {
  getBrands,
  getBrandModels,
} from "@/api/device.api";

import type {
  GetBrandsParams,
  GetBrandModelsParams,
} from "@/lib/types";

export async function loadMoreBrands(
  params: GetBrandsParams,
) {
  return getBrands(params);
}

export async function loadMoreModels(
  params: GetBrandModelsParams,
) {
  return getBrandModels(params);
}