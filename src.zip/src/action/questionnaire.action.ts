"use server";

import {
  calculatePrice,
  getQuestionnaire,
} from "@/api/questionnaire.api";
import type {
  CalculatePricePayload,
} from "@/lib/types";

export async function fetchQuestionnaire(deviceId: string) {
  return getQuestionnaire(deviceId);
}

export async function submitQuestionnaireAnswers(
  payload: CalculatePricePayload,
) {
  return calculatePrice(payload);
}
