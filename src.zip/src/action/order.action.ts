"use server";

import { createSellOrder } from "@/api/order.api";
import type { CreateOrderPayload } from "@/lib/types";

export async function submitSellOrder(payload: CreateOrderPayload) {
  return createSellOrder(payload);
}
