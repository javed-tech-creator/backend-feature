"use client";

import { searchDevices } from "@/api/device.api";
import type { DeviceSearchResult } from "@/lib/types";
import { useEffect, useState } from "react";


export function useDeviceSearch(query: string) {
    const [results, setResults] = useState<DeviceSearchResult[]>([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        const trimmedQuery = query.trim();

        // Empty ya short query par API call mat karo
        if (trimmedQuery.length < 2) {
            setResults([]);
            setLoading(false);
            return;
        }

        let cancelled = false;

        const timer = setTimeout(async () => {
            try {
                setLoading(true);

                const response = await searchDevices({
                    query: trimmedQuery,
                });

                if (cancelled) return;

                if (!response.success) {
                    setResults([]);
                    return;
                }

                setResults(response.data?.data ?? []);
            } catch (error) {
                if (!cancelled) {
                    console.error("Device search error:", error);
                    setResults([]);
                }
            } finally {
                if (!cancelled) {
                    setLoading(false);
                }
            }
        }, 400);

        return () => {
            clearTimeout(timer);
            cancelled = true;
        };
    }, [query]);

    return {
        results,
        loading,
    };
}