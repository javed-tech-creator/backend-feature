"use client";

import { searchDevices } from "@/api/device.api";
import type { DeviceSearchResult } from "@/lib/types";
import { useEffect, useState } from "react";

type SearchMeta = {
  nextCursor?: string | null;
  hasMore?: boolean;
};

export function useDeviceSearch(query: string) {
  const [results, setResults] = useState<DeviceSearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);

  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(false);

  useEffect(() => {
    const trimmedQuery = query.trim();

    // Empty ya short query par API call mat karo
    if (trimmedQuery.length < 2) {
      setResults([]);
      setLoading(false);
      setLoadingMore(false);
      setNextCursor(null);
      setHasMore(false);
      return;
    }

    let cancelled = false;

    const timer = setTimeout(async () => {
      try {
        setLoading(true);

        const response = await searchDevices({
          query: trimmedQuery,
          limit: 20,
        });

        if (cancelled) return;

        if (!response.success) {
          setResults([]);
          setNextCursor(null);
          setHasMore(false);
          return;
        }
        setResults(response.data?.data ?? []);
        const meta = response.data as SearchMeta | undefined;

        setNextCursor(meta?.nextCursor ?? null);
        setHasMore(meta?.hasMore ?? false);
      } catch (error) {
        if (!cancelled) {
          console.error("Device search error:", error);
          setResults([]);
          setNextCursor(null);
          setHasMore(false);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }, 400);

    return () => {
      clearTimeout(timer);
      cancelled = true;
    };
  }, [query]);

  const loadMore = async () => {
    const trimmedQuery = query.trim();

    if (
      trimmedQuery.length < 2 ||
      loading ||
      loadingMore ||
      !hasMore ||
      !nextCursor
    ) {
      return;
    }

    try {
      setLoadingMore(true);

      const response = await searchDevices({
        query: trimmedQuery,
        limit: 20,
        cursor: nextCursor,
      });

      if (!response.success) {
        return;
      }

      const newResults = response.data?.data ?? [];

      setResults((prev) => [...prev, ...newResults]);

      const meta = response.data as SearchMeta | undefined;

      setNextCursor(meta?.nextCursor ?? null);
      setHasMore(meta?.hasMore ?? false);
    } catch (error) {
      console.error("Load more device search error:", error);
    } finally {
      setLoadingMore(false);
    }
  };

  return {
    results,
    loading,
    loadingMore,
    hasMore,
    loadMore,
  };
}
