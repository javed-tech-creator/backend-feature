import type { Question, QuestionnaireAnswers, OrderAnswerPayload, SelectedAnswerItem } from "@/lib/types";
import type { CalculatorAnswerPayload } from "@/lib/types";

export function flattenQuestions(steps: { questions: Question[] }[]): Question[] {
  return steps.flatMap((step) => step.questions);
}

export function validateStepAnswers(
  questions: Question[],
  answers: QuestionnaireAnswers,
): string | null {
  for (const question of questions) {
    const value = answers[question._id];

    if (question.type === "checkbox") {
      continue;
    }

    if (question.type === "input") {
      if (typeof value !== "string" || !value.trim()) {
        return `Please answer "${question.title}" before continuing.`;
      }
      continue;
    }

    if (typeof value !== "string" || !value) {
      return `Please select an option for "${question.title}" before continuing.`;
    }
  }

  return null;
}

export function toCalculatorAnswers(
  questions: Question[],
  answers: QuestionnaireAnswers,
): CalculatorAnswerPayload[] {
  const payload: CalculatorAnswerPayload[] = [];

  for (const question of questions) {
    const value = answers[question._id];

    if (value === undefined || value === "") {
      continue;
    }

    if (question.type === "checkbox" && Array.isArray(value)) {
      for (const optionId of value) {
        payload.push({ questionId: question._id, optionId });
      }
      continue;
    }

    if (question.type === "input") {
      continue;
    }

    if (typeof value === "string") {
      payload.push({ questionId: question._id, optionId: value });
    }
  }

  return payload;
}

export function isRejectedBreakdown(
  breakdown: { finalOffer: number; adjustments: { type: string }[] },
): boolean {
  return breakdown.adjustments.some(
    (adjustment) => adjustment.type === "reject",
  );
}

export function toOrderAnswers(
  questions: Question[],
  answers: QuestionnaireAnswers,
): OrderAnswerPayload[] {
  return toCalculatorAnswers(questions, answers).map((answer) => ({
    questionId: answer.questionId,
    selectedOptionId: answer.optionId,
  }));
}

export function getSelectedAnswerItems(
  questions: Question[],
  answers: QuestionnaireAnswers,
): SelectedAnswerItem[] {
  const items: SelectedAnswerItem[] = [];

  for (const question of questions) {
    const value = answers[question._id];

    if (value === undefined || value === "") {
      continue;
    }

    if (question.type === "checkbox" && Array.isArray(value)) {
      for (const optionId of value) {
        const option = question.options.find((item) => item._id === optionId);
        if (option) {
          items.push({
            questionId: question._id,
            questionTitle: question.title,
            optionTitle: option.title,
          });
        }
      }
      continue;
    }

    if (question.type === "input" && typeof value === "string") {
      items.push({
        questionId: question._id,
        questionTitle: question.title,
        optionTitle: value,
      });
      continue;
    }

    if (typeof value === "string") {
      const option = question.options.find((item) => item._id === value);
      if (option) {
        items.push({
          questionId: question._id,
          questionTitle: question.title,
          optionTitle: option.title,
        });
      }
    }
  }

  return items;
}
