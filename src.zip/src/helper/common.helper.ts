import { DEVICE_LABELS } from "@/lib/constant";

export const deviceLabel = (device: string) =>
  DEVICE_LABELS[device.toLowerCase()] ??
  device
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");

export function label(slug: string) {
  return slug
    .split("-")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}