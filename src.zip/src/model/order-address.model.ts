import { Schema, model } from "mongoose";
import { baseSchemaOptions } from "./base.model";
import { IOrderAddress } from "../types/types";


const orderAddressSchema = new Schema<IOrderAddress>(
  {
    orderId: {
      type: Schema.Types.ObjectId,
      required: true,
      ref: "Order",
      unique: true,
    },

    address1: {
      type: String,
      required: true,
      trim: true,
    },

    address2: {
      type: String,
      trim: true,
    },

    state: {
      type: String,
      required: true,
      trim: true,
    },

    city: {
      type: String,
      required: true,
      trim: true,
    },

    pincode: {
      type: String,
      required: true,
      trim: true,
    },

    isDeleted: {
      type: Boolean,
      default: false,
    },
  },
  baseSchemaOptions,
);

export const OrderAddress = model<IOrderAddress>(
  "OrderAddress",
  orderAddressSchema,
);