import { Schema, model } from 'mongoose';
import { baseSchemaOptions } from './base.model';
import { IOrder } from '../types/types';
import { OrderStatus, OrderType } from '../lib/enum';

const orderSchema = new Schema<IOrder>(
  {
    userId: { type: Schema.Types.ObjectId, required: true, ref: 'User' },
    modelId: { type: Schema.Types.ObjectId, required: true, ref: 'Model' },
    storageId: { type: Schema.Types.ObjectId, required: true, ref: 'Storage' },
    basePrice: { type: Number, required: true, default: 0 },
    finalPrice: { type: Number, required: true, default: 0 },
    status: { type: String, enum: Object.values(OrderStatus), default: OrderStatus.REQUESTED },
    orderType: { type: String, enum: Object.values(OrderType) },
    state: { type: String, required: true },
    city: { type: String, required: true },
    isDeleted: { type: Boolean, default: false },
  },
  baseSchemaOptions,
);

export const Order = model<IOrder>('Order', orderSchema);
