import { z } from 'zod';
import { OrderStatus, OrderType } from '../../../lib/enum';
import { objectIdSchema } from '../../../utils/object-id';
import { paginationQuerySchema } from '../../../utils/pagination';

export const orderAnswerSchema = z.object({
  questionId: objectIdSchema,
  selectedOptionId: objectIdSchema,
});

export const orderCreateSchema = z.object({
  state: z.string().trim().min(1),
  city: z.string().trim().min(1),
  modelId: objectIdSchema,
  basePrice: z.number().min(0),
  finalPrice: z.number().min(0),
  // The base price lives on the model/storage pair, so the storage decides the price.
  storageId: objectIdSchema,
  orderType: z.enum(OrderType).optional(),
  answers: z
    .array(orderAnswerSchema)
    .min(1, 'At least one answer is required')
    // A question answered twice would deduct twice from the final price.
    .refine(
      (answers) => new Set(answers.map((answer) => answer.questionId)).size === answers.length,
      'Each question can be answered only once',
    ),
});

export const orderStatusUpdateSchema = z.object({
  status: z.enum(OrderStatus),
});

export const orderListQuerySchema = paginationQuerySchema.extend({
  status: z.enum(OrderStatus).optional(),
  orderType: z.enum(OrderType).optional(),
  userId: objectIdSchema.optional(),
  modelId: objectIdSchema.optional(),
  sortBy: z.enum(['finalPrice', 'basePrice', 'status', 'createdAt']).default('createdAt'),
});

export type OrderAnswerDto = z.infer<typeof orderAnswerSchema>;
export type OrderCreateDto = z.infer<typeof orderCreateSchema>;
export type OrderStatusUpdateDto = z.infer<typeof orderStatusUpdateSchema>;
export type OrderListQuery = z.infer<typeof orderListQuerySchema>;
