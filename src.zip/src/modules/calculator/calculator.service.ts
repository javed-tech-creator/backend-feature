import { Model } from '../../model/model.model';
import { ModelStorage } from '../../model/model-storage.model';
import { Question } from '../../model/question.model';
import { QuestionOption } from '../../model/question-option.model';
import { ApiError } from '../../utils/api-error';
import { buildPriceBreakdown, PricedAnswer } from '../../utils/pricing';
import { findLiveById } from '../../utils/query';
import { QuestionService } from '../question/question.service';
import { OrderService } from '../order/order.service';
import { CalculatorCalculateDto } from './dto/index.dto';

/** The base price of a model in a given storage — the figure every adjustment works off. */
const resolveBasePrice = async (modelId: string, storageId: string): Promise<number> => {
  await findLiveById(Model, modelId, 'Model');

  const modelStorage = await ModelStorage.findOne({ modelId, storageId });

  if (!modelStorage) {
    throw ApiError.badRequest('This storage is not available for the selected model');
  }

  return modelStorage.basePrice;
};

export class CalculatorService {
  /** The live questionnaire for a device, reused from the question module. */
  static async questions(deviceId: string) {
    return QuestionService.activeForDevice(deviceId);
  }

  static async calculate(
    userId: string,
    { state, city, modelId, storageId, answers }: CalculatorCalculateDto,
  ) {
    const basePrice = await resolveBasePrice(modelId, storageId);

    const priced: PricedAnswer[] = await Promise.all(
      answers.map(async ({ questionId, optionId }) => {
        const question = await findLiveById(Question, questionId, 'Question');
        const option = await findLiveById(QuestionOption, optionId, 'Question option');

        if (!option.questionId.equals(question.id)) {
          throw ApiError.badRequest('Selected option does not belong to the question');
        }

        // A disabled question must not move the price, even if it is sent.
        if (!question.isActive) {
          throw ApiError.badRequest(`"${question.title}" is disabled and cannot be answered`);
        }

        return {
          question: question.title,
          option: option.title,
          type: option.adjustmentType,
          operation: option.operation,
          value: option.value ?? 0,
        };
      }),
    );

    const breakdown = buildPriceBreakdown(basePrice, priced);
     await OrderService.create(userId, {
      basePrice,
      finalPrice: breakdown.finalOffer,
      state,
      city,
      modelId,
      storageId,
      answers: answers.map(({ questionId, optionId }) => ({
        questionId,
        selectedOptionId: optionId,
      })),
    });

    return { ...breakdown };
  }
}
