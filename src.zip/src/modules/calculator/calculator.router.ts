import { Router } from 'express';
import { validate } from '../../middlewares/validate';
import { CalculatorController } from './calculator.controller';
import { calculatorCalculateSchema } from './dto/index.dto';
import { authenticate } from '../../middlewares/authenticate';

const router = Router();

// Read-only and priced from admin-managed data, so the storefront can call both
// without a session — the same endpoints back the admin preview screen.
router.get('/questions', CalculatorController.questions);

router.use(authenticate);
router.post(
  '/calculate',
  validate({ body: calculatorCalculateSchema }),
  CalculatorController.calculate,
);

export default router;
