import { NextFunction, Request, Response } from 'express';
import { ResponseHandler } from '../../helper/response.handler';
import { CalculatorService } from './calculator.service';
import { calculatorQuestionsQuerySchema } from './dto/index.dto';

export class CalculatorController {
  static async questions(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { deviceId } = calculatorQuestionsQuerySchema.parse(req.query);
      const questions = await CalculatorService.questions(deviceId);
      ResponseHandler.success(res, 'Calculator questions fetched successfully', questions);
    } catch (error) {
      next(error);
    }
  }

  static async calculate(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const result = await CalculatorService.calculate(req.user!.id, req.body);
      ResponseHandler.success(res, 'Price calculated and order created successfully', result, 201);
    } catch (error) {
      next(error);
    }
  }
}
