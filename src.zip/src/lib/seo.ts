/**
 * Single source of truth for site-wide SEO values.
 *
 * NEXT_PUBLIC_SITE_URL must be the real production origin (no trailing slash).
 * It is what canonical URLs, Open Graph tags and the sitemap are built from, so
 * a wrong value here silently points every canonical at the wrong domain.
 */
export const siteConfig = {
  name: "MobiZoo",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
  title: "Sell Your Old Phone, Tablet & Laptop for Instant Cash",
  description:
    "India's most trusted platform to sell your old mobile phones, tablets, laptops and gadgets. Get the best price and instant cash at your doorstep with MobiZoo.",
  locale: "en_IN",
  phone: "+917526074042",
  social: [
    "https://facebook.com",
    "https://instagram.com",
    "https://youtube.com",
  ],
} as const;

/** Absolute URL for a site-relative path — required by canonical/OG tags. */
export function absoluteUrl(path = "/") {
  return new URL(path, siteConfig.url).toString();
}
