import type { IconType } from "react-icons";

export interface MenuItem {
  title: string;
  type?: string;
  items?: string[];
  path?: string;
}
export interface SocialLink {
  icon: IconType;
  href: string;
  label: string;
}

export interface SessionUser {
  phone: string;
  fullName: string;
}

export interface AuthSession {
  token: string;
  user: SessionUser;
}

export interface ApiCallOptions extends RequestInit {
  basePath?: string;
  skipAuth?: boolean;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  status?: number;
}

export interface CheckPhoneResponse {
  exists: boolean;
  isNewUser: boolean;
}

export interface SendOtpResponse {
  isNewUser: boolean;
}

export interface VerifyOtpResponse {
  token: string;
  user: SessionUser;
}

export interface BrandModel {
  _id: string;
  name: string;
  logo?: string;
  slug: string;
  price?: number;
}

export interface GetBrandModelsParams {
  device: string;
  brand: string;
  limit?: number;
  cursor?: string;
}

export interface GetBrandModelsData {
  data: BrandModel[];
  nextCursor: string | null;
  hasMore: boolean;
}

export interface GetBrandModelsResponse {
  success: boolean;
  message: string;
  status: number;
  data: GetBrandModelsData;
}

export interface GetBrandModelsParams {
  device: string;
  brand: string;
  limit?: number;
  cursor?: string;
}

export type ModelParams = {
  deviceSlug: string;
  brandSlug: string;
  modelSlug: string;
};

export interface Storage {
  _id: string;
  ram: string;
  rom: string;
  slug: string;
}

export interface ModelStorage {
  _id: string;
  storageId: Storage;
  basePrice: number;
}

export interface ModelDetails {
  _id: string;
  name: string;
  logo?: string;
}

export interface GetModelDetailsParams {
  model: string;
}

export interface GetModelDetailsData {
   model: ModelDetails;
   data: ModelStorage[];
}
export interface GetModelDetailsParams {
  model: string;
  limit?: number;
  cursor?: string;
}

export type StorageParams = {
  deviceSlug: string;
  brandSlug: string;
  modelSlug: string;
  storageSlug: string;
};

export interface Brand {
  _id: string;
  name: string;
  slug: string;
  logo?: string;
}

export interface GetBrandsParams {
  slug: string;
  limit?: number;
  cursor?: string;
}

export interface GetBrandsData {
  data: Brand[];
  nextCursor: string | null;
  hasMore: boolean;
}

export interface GetBrandsResponse {
  success: boolean;
  message: string;
  status: number;
  data: GetBrandsData;
}

export interface DeviceSearchResult {
  id: string;
  modelName: string;
  logo: string;
  route: string;
}

export interface DeviceSearchData {
  data: DeviceSearchResult[];
}

export interface DeviceSearchParams {
  query: string;
}