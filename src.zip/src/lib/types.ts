import type { IconType } from "react-icons";

export interface MenuItem {
  title: string;
  type?: string;
  items?: string[];
  path?: string;
}
export interface SocialLink {
  icon: IconType;
  href: string;
  label: string;
}

export interface SessionUser {
  phone: string;
  fullName: string;
}

export interface AuthSession {
  token: string;
  user: SessionUser;
}

export interface ApiCallOptions extends RequestInit {
  basePath?: string;
  skipAuth?: boolean;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  status?: number;
}

export interface CheckPhoneResponse {
  exists: boolean;
  isNewUser: boolean;
}

export interface SendOtpResponse {
  isNewUser: boolean;
}

export interface VerifyOtpResponse {
  token: string;
  user: SessionUser;
}

export interface BrandModel {
  _id: string;
  name: string;
  logo?: string;
  slug: string;
  price?: number;
}

export interface GetBrandModelsParams {
  device: string;
  brand: string;
  limit?: number;
  cursor?: string;
}

export interface GetBrandModelsData {
  data: BrandModel[];
  nextCursor: string | null;
  hasMore: boolean;
}

export interface GetBrandModelsResponse {
  success: boolean;
  message: string;
  status: number;
  data: GetBrandModelsData;
}

export interface GetBrandModelsParams {
  device: string;
  brand: string;
  limit?: number;
  cursor?: string;
}

export type ModelParams = {
  deviceSlug: string;
  brandSlug: string;
  modelSlug: string;
};

export interface Storage {
  _id: string;
  ram: string;
  rom: string;
  slug: string;
}

export interface ModelStorage {
  _id: string;
  storageId: Storage;
  basePrice: number;
}

export interface ModelDetails {
  _id: string;
  name: string;
  logo?: string;
  deviceId?: string;
}

export interface GetModelDetailsParams {
  model: string;
}

export interface GetModelDetailsData {
  model: ModelDetails;
  data: ModelStorage[];
}
export interface GetModelDetailsParams {
  model: string;
  limit?: number;
  cursor?: string;
}

export type StorageParams = {
  deviceSlug: string;
  brandSlug: string;
  modelSlug: string;
  storageSlug: string;
};

export interface Brand {
  _id: string;
  name: string;
  slug: string;
  logo?: string;
}

export interface GetBrandsParams {
  slug: string;
  limit?: number;
  cursor?: string;
}

export interface GetBrandsData {
  data: Brand[];
  nextCursor: string | null;
  hasMore: boolean;
}

export interface GetBrandsResponse {
  success: boolean;
  message: string;
  status: number;
  data: GetBrandsData;
}

export interface DeviceSearchResult {
  id: string;
  modelName: string;
  logo: string;
  route: string;
}

export interface DeviceSearchData {
  data: DeviceSearchResult[];
  nextCursor: string | null;
  hasMore: boolean;
  limit: number;
}

export interface DeviceSearchParams {
  query: string;
  limit?: number;
  cursor?: string;
}

export interface DeviceCategory {
  _id: string;
  name: string;
  slug: string;
  logo?: string;
}

export interface GetDevicesData {
  data: DeviceCategory[];
}

export type QuestionType = "radio" | "checkbox" | "boolean" | "input";

export type OptionOperation = "increase" | "decrease";

export interface QuestionOption {
  _id: string;
  title: string;
  icon: string | null;
  operation?: OptionOperation | string | null;
}

export interface Question {
  _id: string;
  title: string;
  type: QuestionType;
  options: QuestionOption[];
}

export interface QuestionnaireStep {
  step: number;
  questions: Question[];
}

export interface QuestionnaireData {
  deviceId: string;
  steps: QuestionnaireStep[];
}

/** Answers keyed by questionId — option id(s) or free-text for input. */
export type QuestionnaireAnswers = Record<string, string | string[]>;

export interface CalculatorAnswerPayload {
  questionId: string;
  optionId: string;
}

export interface CalculatePricePayload {
  modelId: string;
  storageId: string;
  answers: CalculatorAnswerPayload[];
}

export interface PriceAdjustment {
  question?: string;
  option?: string;
  type: string;
  operation: string | null;
  value: number;
  amount: number;
}

export interface PriceBreakdown {
  basePrice: number;
  adjustments: PriceAdjustment[];
  totalIncrease: number;
  totalDecrease: number;
  finalOffer: number;
}

export interface QuestionnaireContext {
  deviceSlug: string;
  brandSlug: string;
  modelSlug: string;
  storageSlug: string;
  deviceId: string;
  modelId: string;
  storageId: string;
  modelName: string;
  modelLogo?: string;
  storageLabel: string;
  basePrice?: number;
}

/** Persisted when navigating from storage page to questionnaire. */
export interface QuestionnaireSessionData {
  modelData: ModelDetails & { deviceId: string };
  selectedStorage: ModelStorage;
  deviceSlug: string;
  brandSlug: string;
  modelSlug: string;
  storageSlug: string;
  brandLabel: string;
  storageLabel: string;
}

export interface SelectedAnswerItem {
  questionId: string;
  questionTitle: string;
  optionTitle: string;
}

export interface LocationSelection {
  state: string;
  city: string;
}

export interface OrderAnswerPayload {
  questionId: string;
  selectedOptionId: string;
}

export interface CreateOrderPayload {
  modelId: string;
  storageId: string;
  orderType: "sell";
  answers: OrderAnswerPayload[];
}

export interface Order {
  _id: string;
  finalPrice: number;
  basePrice: number;
  status: string;
}
