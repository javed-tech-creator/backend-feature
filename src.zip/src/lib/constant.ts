import { FaFacebookF, FaInstagram, FaYoutube } from "react-icons/fa";
import type { SocialLink } from "./types";
import mobile from "../assets/images/phone.png";
import tablet from "../assets/images/tablet.png";
import laptop from "../assets/images/laptop.png";
import watch from "../assets/images/watch.png";
import earbud from "../assets/images/earbud.png";
import dslr from "../assets/images/dslr.png";

export const SESSION_COOKIE = "phone_auth_session";
export const SESSION_USER = "phone_auth_user";

export const socialLinks: SocialLink[] = [
  {
    icon: FaFacebookF,
    href: "https://facebook.com",
    label: "Facebook",
  },
  {
    icon: FaInstagram,
    href: "https://instagram.com",
    label: "Instagram",
  },
  {
    icon: FaYoutube,
    href: "https://youtube.com",
    label: "YouTube",
  },
];
export const services = [
  { title: "Sell Phone", path: "/sell/mobile" },
  { title: "Sell Tablet", path: "/sell/tablet" },
  { title: "Sell Laptop", path: "/sell/laptop" },
  { title: "Sell Gadget", path: "/sell/gadget" },
];

export const siteLinks = [
  { title: "About Us", path: "/about-us" },
  { title: "Contact Us", path: "/contact-us" },
  { title: "Blog", path: "/blog" },
  { title: "FAQ", path: "/faq" },
];

export const terms = [
  { title: "Terms & Conditions", path: "/terms-and-conditions" },
  { title: "Privacy Policy", path: "/privacy-policy" },
];

export const sellCategories = [
  {
    id: 1,
    title: "Mobile",
    image: mobile,
    link: "/sell/mobile",
  },
  {
    id: 2,
    title: "Tablet",
    image: tablet,
    link: "/sell/tablet",
  },
  {
    id: 3,
    title: "Laptop",
    image: laptop,
    link: "/sell/laptop",
  },
  {
    id: 4,
    title: "Smart Watch",
    image: watch,
    link: "/sell/smart-watch",
  },
  {
    id: 5,
    title: "Earbud",
    image: earbud,
    link: "/sell/earbud",
  },
  {
    id: 6,
    title: "DSLR",
    image: dslr,
    link: "/sell/dslr",
  },
];

export const quickLinks = [
  // Phones
  { name: "Apple", device: "phone" },
  { name: "Samsung", device: "phone" },
  { name: "OnePlus", device: "phone" },
  { name: "Xiaomi", device: "phone" },
  { name: "Redmi", device: "phone" },
  { name: "Realme", device: "phone" },
  { name: "Vivo", device: "phone" },
  { name: "Oppo", device: "phone" },
  { name: "Nothing", device: "phone" },
  { name: "Google", device: "phone" },
  { name: "Motorola", device: "phone" },
  { name: "Nokia", device: "phone" },
  { name: "iQOO", device: "phone" },
  { name: "Tecno", device: "phone" },
  { name: "Infinix", device: "phone" },
  { name: "Lava", device: "phone" },
  { name: "Honor", device: "phone" },
  { name: "Asus", device: "phone" },
  { name: "Sony", device: "phone" },
  { name: "Lenovo", device: "phone" },
  { name: "HTC", device: "phone" },
  { name: "Huawei", device: "phone" },
  { name: "BlackBerry", device: "phone" },
  { name: "Micromax", device: "phone" },
  { name: "Coolpad", device: "phone" },
  { name: "LeEco", device: "phone" },
  { name: "Karbonn", device: "phone" },
  { name: "Gionee", device: "phone" },
  { name: "Panasonic", device: "phone" },
  { name: "InFocus", device: "phone" },
  { name: "Lyf", device: "phone" },
  { name: "Yu", device: "phone" },
  { name: "10.or", device: "phone" },
  { name: "Nubia", device: "phone" },
  { name: "Xolo", device: "phone" },
  { name: "Itel", device: "phone" },
  { name: "Poco", device: "phone" },

  // Laptops
  { name: "Dell", device: "laptop" },
  { name: "HP", device: "laptop" },
  { name: "MSI", device: "laptop" },
  { name: "Microsoft", device: "laptop" },
  { name: "LG", device: "laptop" },
  { name: "Alienware", device: "laptop" },
  { name: "Avita", device: "laptop" },
  { name: "Fujitsu", device: "laptop" },
  { name: "HCL", device: "laptop" },
  { name: "IBM", device: "laptop" },
  { name: "RDP", device: "laptop" },
  { name: "Toshiba", device: "laptop" },
  { name: "Acer", device: "laptop" },

  // Tablets
  { name: "Apple", device: "tablet" },
  { name: "Samsung", device: "tablet" },
  { name: "Lenovo", device: "tablet" },
  { name: "Xiaomi", device: "tablet" },
  { name: "Realme", device: "tablet" },
  { name: "Honor", device: "tablet" },
  { name: "Huawei", device: "tablet" },
  { name: "Nokia", device: "tablet" },

  // Smart Watches
  { name: "Apple", device: "smartwatch" },
  { name: "Samsung", device: "smartwatch" },
  { name: "Noise", device: "smartwatch" },
  { name: "boAt", device: "smartwatch" },
  { name: "Fire-Boltt", device: "smartwatch" },
  { name: "Fossil", device: "smartwatch" },
  { name: "Fitbit", device: "smartwatch" },
  { name: "Amazfit", device: "smartwatch" },
  { name: "Garmin", device: "smartwatch" },

  // Earbuds
  { name: "Apple", device: "earbuds" },
  { name: "Samsung", device: "earbuds" },
  { name: "boAt", device: "earbuds" },
  { name: "Noise", device: "earbuds" },
  { name: "OnePlus", device: "earbuds" },
  { name: "Realme", device: "earbuds" },
  { name: "Oppo", device: "earbuds" },
  { name: "JBL", device: "earbuds" },
  { name: "Sony", device: "earbuds" },
  { name: "Nothing", device: "earbuds" },
];

export const DEVICE_LABELS: Record<string, string> = {
  phone: "Phone",
  tablet: "Tablet",
  laptop: "Laptop",
  gadget: "Gadget",
  smartwatch: "Smart Watch",
  earbuds: "Earbuds",
};
