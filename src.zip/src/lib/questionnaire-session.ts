import type { QuestionnaireSessionData } from "@/lib/types";

export const QUESTIONNAIRE_SESSION_KEY = "sell_questionnaire_session";

export function saveQuestionnaireSession(data: QuestionnaireSessionData): void {
  if (typeof window === "undefined") return;
  sessionStorage.setItem(QUESTIONNAIRE_SESSION_KEY, JSON.stringify(data));
}

export function getQuestionnaireSession(): QuestionnaireSessionData | null {
  if (typeof window === "undefined") return null;

  const raw = sessionStorage.getItem(QUESTIONNAIRE_SESSION_KEY);
  if (!raw) return null;

  try {
    return JSON.parse(raw) as QuestionnaireSessionData;
  } catch {
    return null;
  }
}

export function clearQuestionnaireSession(): void {
  if (typeof window === "undefined") return;
  sessionStorage.removeItem(QUESTIONNAIRE_SESSION_KEY);
}
