const COUNTRIES_NOW_BASE = "https://countriesnow.space/api/v0.1";
const COUNTRY = "India";

type StatesResponse = {
  error: boolean;
  msg: string;
  data?: {
    states: { name: string; state_code: string }[];
  };
};

type CitiesResponse = {
  error: boolean;
  msg: string;
  data?: string[];
};

export async function fetchIndianStates(): Promise<string[]> {
  const response = await fetch(`${COUNTRIES_NOW_BASE}/countries/states`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ country: COUNTRY }),
    next: { revalidate: 86_400 },
  });

  if (!response.ok) {
    throw new Error("Failed to fetch states.");
  }

  const json = (await response.json()) as StatesResponse;

  if (json.error || !json.data?.states?.length) {
    throw new Error(json.msg || "Failed to fetch states.");
  }

  return json.data.states.map((item) => item.name).sort((a, b) => a.localeCompare(b));
}

export async function fetchIndianCities(state: string): Promise<string[]> {
  const response = await fetch(`${COUNTRIES_NOW_BASE}/countries/state/cities`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ country: COUNTRY, state }),
    next: { revalidate: 86_400 },
  });

  if (!response.ok) {
    throw new Error("Failed to fetch cities.");
  }

  const json = (await response.json()) as CitiesResponse;

  if (json.error || !json.data?.length) {
    throw new Error(json.msg || "Failed to fetch cities.");
  }

  return [...json.data].sort((a, b) => a.localeCompare(b));
}
