import React from "react";
import "./App.css";
import { Route, Routes } from "react-router-dom";
import Layout from "./layouts/Layout";
import Dashboard from "./pages/Dashboard";
import LoginPage from "./pages/LoginPage";
import BlogDashboard from "./pages/blog/BlogDashboard";
import TeamDashboard from "./pages/team/TeamDashboard";
import InquiryDashboard from "./pages/inquiry/InquiryDashboard";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import BlogForm from "./pages/blog/BlogForm";
import TeamForm from "./pages/team/TeamForm";
import VisitorDashboard from "./pages/visitor/VisitorDashboard";
import ProtectedRoute from "./pages/ProtectedRoute";
import DeviceManagement from "./pages/device-management/DeviceManagement";
import DeviceForm from "./components/device-management/DeviceForm";
import StorageForm from "./components/device-management/StorageForm";
import BrandForm from "./components/device-management/BrandForm";
import ModelForm from "./components/device-management/ModelForm";
import ModelUploadPage from "./pages/device-management/ModelUploadPage";
import UserDashboard from "./pages/user/UserDashboard";
import OrderDashboard from "./pages/order/OrderDashboard";
function App() {
  return (
    <>
      <ToastContainer />
      <Routes>
        <Route path="/" element={<LoginPage />} />
        {/* Protected Routes */}
        <Route element={<ProtectedRoute />}>
          <Route element={<Layout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/blog" element={<BlogDashboard />} />
            <Route path="/blog/add" element={<BlogForm />} />
            <Route path="/blog/update/:id" element={<BlogForm />} />
            <Route path="/team" element={<TeamDashboard />} />
            <Route path="/team/add" element={<TeamForm />} />
            <Route path="/team/update/:id" element={<TeamForm />} />
            <Route path="/inquiry" element={<InquiryDashboard />} />
            <Route path="/visitor" element={<VisitorDashboard />} />
            <Route path="/users" element={<UserDashboard />} />
            <Route path="/orders" element={<OrderDashboard />} />
            <Route path="/subscriber/announcement" />
            <Route
              path="/device-management/:section"
              element={<DeviceManagement />}
            />
            <Route
              path="/device-management/devices/add"
              element={<DeviceForm />}
            />
            <Route
              path="/device-management/devices/update/:id"
              element={<DeviceForm />}
            />
            <Route
              path="/device-management/storages/add"
              element={<StorageForm />}
            />
            <Route
              path="/device-management/storages/update/:id"
              element={<StorageForm />}
            />
            <Route
              path="/device-management/brands/add"
              element={<BrandForm />}
            />
            <Route
              path="/device-management/brands/update/:id"
              element={<BrandForm />}
            />
            <Route
              path="/device-management/models/add"
              element={<ModelForm />}
            />
            <Route
              path="/device-management/models/upload"
              element={<ModelUploadPage />}
            />
            <Route
              path="/device-management/models/update/:id"
              element={<ModelForm />}
            />
          </Route>
        </Route>
      </Routes>
    </>
  );
}

export default App;
