import React, { useEffect, useMemo, useState } from "react";
import { Icon } from "@iconify/react";
import * as LucideIcons from "lucide-react";
import { Search, X, Check, Loader2 } from "lucide-react";
import { searchIcons, STARTER_ICONS } from "../services/Iconify";

/**
 * Renders a stored icon name.
 *
 * New icons are Iconify names ("mdi:cellphone"). Older rows hold a lucide
 * component name ("Smartphone") from before the switch, so those still render
 * rather than silently disappearing.
 */
export const AppIcon = ({ name, size = 20, className }) => {
  if (!name) return null;

  if (name.includes(":")) {
    return (
      <Icon icon={name} width={size} height={size} className={className} />
    );
  }

  const Legacy = LucideIcons[name];

  return Legacy ? <Legacy size={size} className={className} /> : null;
};

/**
 * IconPicker
 * ----------
 * Modal for searching & selecting an Iconify icon. Stores the icon's full name
 * (e.g. "mdi:cellphone"), which is what gets persisted to the DB.
 *
 *   <IconPicker
 *     value={iconName}
 *     onSelect={(name) => setIcon(name)}
 *     onClose={() => setOpen(false)}
 *   />
 */
const IconPicker = ({ value = "", onSelect, onClose }) => {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState(STARTER_ICONS);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Debounced search — a request per keystroke would rate-limit the API, and
  // the abort drops answers to searches the user has already moved past.
  useEffect(() => {
    const controller = new AbortController();
    const q = query.trim();

    if (!q) {
      setResults(STARTER_ICONS);
      setLoading(false);
      setError("");
      return () => controller.abort();
    }

    setLoading(true);
    setError("");

    const timer = setTimeout(() => {
      searchIcons(q, { signal: controller.signal })
        .then((icons) => {
          setResults(icons);
          setLoading(false);
        })
        .catch((err) => {
          if (err.name === "AbortError") return;
          setError("Could not reach the icon service. Check your connection.");
          setResults([]);
          setLoading(false);
        });
    }, 300);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [query]);

  const isBrowsing = useMemo(() => !query.trim(), [query]);

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-2xl max-h-[85vh] flex flex-col rounded-2xl bg-white shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-sky-50">
          <div>
            <h3 className="text-lg font-simeibold text-gray-800">
              Choose an Icon
            </h3>
            <p className="text-xs text-gray-500 mt-0.5">
              Search over 200,000 Iconify icons
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-lg border bg-white text-gray-500 hover:bg-gray-100 flex items-center justify-center"
          >
            <X size={18} />
          </button>
        </div>

        {/* Search */}
        <div className="px-6 py-3 border-b">
          <div className="relative">
            <Search
              size={16}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
            />
            <input
              autoFocus
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search icons (e.g. phone, battery, camera)..."
              className="w-full h-11 rounded-lg border border-gray-300 pl-10 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {loading && (
              <Loader2
                size={16}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 animate-spin"
              />
            )}
          </div>
        </div>

        {/* Grid */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {isBrowsing && (
            <p className="mb-3 text-xs text-gray-400">
              Suggested icons — type above to search everything.
            </p>
          )}

          {error ? (
            <div className="text-center text-sm text-red-500 py-12">
              {error}
            </div>
          ) : loading ? (
            <div className="flex items-center justify-center gap-2 text-sm text-gray-400 py-12">
              <Loader2 size={18} className="animate-spin" /> Searching...
            </div>
          ) : results.length === 0 ? (
            <div className="text-center text-sm text-gray-400 py-12">
              No icons match “{query}”.
            </div>
          ) : (
            <div className="grid grid-cols-5 sm:grid-cols-7 md:grid-cols-8 gap-2">
              {results.map((name) => {
                const active = name === value;
                return (
                  <button
                    key={name}
                    type="button"
                    title={name}
                    onClick={() => onSelect(name)}
                    className={`relative aspect-square flex flex-col items-center justify-center gap-1 rounded-lg border text-gray-600 transition
                      ${
                        active
                          ? "border-primary bg-blue-50 text-primary ring-2 ring-primary/30"
                          : "border-gray-200 hover:border-primary hover:bg-blue-50"
                      }`}
                  >
                    {active && (
                      <span className="absolute top-1 right-1 text-primary">
                        <Check size={12} />
                      </span>
                    )}
                    <Icon icon={name} width={22} height={22} />
                    <span className="w-full truncate px-1 text-[9px] leading-tight text-gray-400">
                      {name.split(":")[1] || name}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t bg-gray-50">
          <div className="flex items-center gap-2 text-sm text-gray-600 min-w-0">
            {value ? (
              <>
                <span className="text-gray-400 shrink-0">Selected:</span>
                <AppIcon name={value} size={18} className="text-primary" />
                <span className="font-medium truncate">{value}</span>
              </>
            ) : (
              <span className="text-gray-400">No icon selected</span>
            )}
          </div>
          <div className="flex gap-2 shrink-0">
            {value && (
              <button
                type="button"
                onClick={() => onSelect("")}
                className="px-3 py-1.5 text-sm rounded-lg border text-red-600 hover:bg-red-50"
              >
                Clear
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 text-sm rounded-lg bg-primary text-white"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IconPicker;
