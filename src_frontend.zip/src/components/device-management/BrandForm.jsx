import React, { useEffect, useState } from "react";
import PageHeader from "../../components/PageHeader";
import { toast } from "react-toastify";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, ImagePlus, Save } from "lucide-react";

import {
  useBrandCreateMutation,
  useBrandUpdateMutation,
  useGetBrandByIdQuery,
} from "../../api/brand.api";

import { useGetAllDeviceQuery } from "../../api/device.api";
import { capitalize } from "../../lib/helper";

const BrandForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const isEdit = !!id;

  const { data: brandData } = useGetBrandByIdQuery(id, {
    skip: !id,
  });

  const { data: deviceData } = useGetAllDeviceQuery();

  const devices = deviceData?.data?.data || [];

  const [createBrand, { isLoading: creating }] =
    useBrandCreateMutation();

  const [updateBrand, { isLoading: updating }] =
    useBrandUpdateMutation();

  const isLoading = creating || updating;

  const [deviceId, setDeviceId] = useState("");
  const [name, setName] = useState("");
  const [logo, setLogo] = useState(null);
  const [preview, setPreview] = useState("");

  useEffect(() => {
    if (!brandData?.data) return;

    const brand = brandData.data;

    setName(brand.name || "");
    setPreview(brand.logo || "");

    // backend may return deviceId or populated device
    setDeviceId(
      brand.deviceId?._id ||
      brand.deviceId ||
      ""
    );
  }, [brandData]);

  const handleImage = (e) => {
    const file = e.target.files?.[0];

    if (!file) return;

    setLogo(file);
    setPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!deviceId) {
      toast.error("Please select device");
      return;
    }

    if (!name.trim()) {
      toast.error("Brand name is required");
      return;
    }

    const formData = new FormData();

    formData.append("deviceId", deviceId);
    formData.append("name", name.trim().toLowerCase());

    if (logo) {
      formData.append("logo", logo);
    }

    try {
      if (isEdit) {
        await updateBrand({
          id,
          formData,
        }).unwrap();

        toast.success("Brand Updated Successfully");
      } else {
        if (!logo) {
          toast.error("Brand logo is required");
          return;
        }

        await createBrand({
          formData,
        }).unwrap();

        toast.success("Brand Created Successfully");
      }

      navigate("/device-management/brands");
    } catch (err) {
      toast.error(err?.data?.message || "Something went wrong");
    }
  };

  return (
    <div>
      <PageHeader
        title={isEdit ? "Edit Brand" : "Add Brand"}
        subtitle={
          isEdit
            ? "Update brand information"
            : "Create a new brand"
        }
      />

      <div className="max-w-7xl mx-auto mt-8">
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden"
        >
          <div className="px-8 py-5 border-b bg-gray-50">
            <h2 className="text-xl font-simeibold text-gray-800">
              {isEdit ? "Edit Brand" : "Brand Information"}
            </h2>

            <p className="text-sm text-gray-500 mt-1">
              {isEdit
                ? "Update brand details."
                : "Fill the details below."}
            </p>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">

              {/* Device */}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Device <span className="text-red-500">*</span>
                </label>

                <select
                  value={deviceId}
                  onChange={(e) => setDeviceId(e.target.value)}
                  className="w-full h-11 rounded-lg border border-gray-300 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Device</option>

                  {devices.map((device) => (
                    <option
                      key={device._id}
                      value={device._id}
                    >
                      {capitalize(device.name)}
                    </option>
                  ))}
                </select>
              </div>

              {/* Brand Name */}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Brand Name <span className="text-red-500">*</span>
                </label>

                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Enter Brand Name"
                  className="w-full h-11 rounded-lg border border-gray-300 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Logo */}

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Brand Logo <span className="text-red-500">*</span>
                </label>

                <label className="h-44 flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-primary hover:bg-blue-50 transition">

                  {preview ? (
                    <img
                      src={preview}
                      alt="Preview"
                      className="w-24 h-24 object-contain"
                    />
                  ) : (
                    <>
                      <ImagePlus
                        size={36}
                        className="text-gray-400 mb-2"
                      />

                      <p className="text-sm font-medium text-gray-600">
                        Upload Logo
                      </p>

                      <span className="text-xs text-gray-400">
                        PNG, JPG, JPEG
                      </span>
                    </>
                  )}

                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImage}
                    required={!isEdit}
                  />
                </label>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 px-6 py-4 border-t bg-gray-50">

            <button
              type="button"
              onClick={() => navigate(-1)}
              className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-100"
            >
              <ArrowLeft size={16} />
              Cancel
            </button>

            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 px-5 py-2 bg-primary text-white rounded-lg"
            >
              <Save size={16} />

              {isLoading
                ? isEdit
                  ? "Updating..."
                  : "Saving..."
                : isEdit
                ? "Update Brand"
                : "Save Brand"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BrandForm;