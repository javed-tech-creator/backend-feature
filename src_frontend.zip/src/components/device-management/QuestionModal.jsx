import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { X, Save, Check } from "lucide-react";
import {
  useQuestionCreateMutation,
  useQuestionUpdateMutation,
} from "../../api/question.api";
import { capitalize } from "../../lib/helper";

// Mirrors the backend QuestionType enum.
export const QUESTION_TYPES = [
  {
    value: "radio",
    label: "Single choice (radio)",
    short: "Single choice",
    hint: "Customer picks one option",
  },
  {
    value: "checkbox",
    label: "Multiple choice (checkbox)",
    short: "Multiple choice",
    hint: "Customer can pick many",
  },
  {
    value: "boolean",
    label: "Yes / No (boolean)",
    short: "Yes / No",
    hint: "A simple two-way answer",
  },
  {
    value: "input",
    label: "Free text (input)",
    short: "Free text",
    hint: "Customer types an answer",
  },
];

/**
 * QuestionModal — create or edit a single question within a step of a device.
 *
 *   mode: "add" | "edit"
 *   deviceId: the device this question belongs to
 *   devices: device list, so an existing question can be moved to another device
 *   step: number (required for add — the step this question belongs to)
 *   question: existing question object (for edit)
 */
const QuestionModal = ({
  mode = "add",
  deviceId,
  devices = [],
  step,
  question,
  onClose,
}) => {
  const isEdit = mode === "edit";

  const [title, setTitle] = useState("");
  const [type, setType] = useState("radio");
  const [device, setDevice] = useState(deviceId || "");

  const [createQuestion, { isLoading: creating }] = useQuestionCreateMutation();
  const [updateQuestion, { isLoading: updating }] = useQuestionUpdateMutation();
  const isLoading = creating || updating;

  useEffect(() => {
    if (isEdit && question) {
      setTitle(question.title || "");
      setType(question.type || "radio");
      setDevice(question.deviceId?._id || question.deviceId || deviceId || "");
    }
  }, [isEdit, question, deviceId]);

  const stepValue = isEdit ? question?.step : step;
  const deviceName = capitalize(
    devices.find((item) => item._id === device)?.name,
  );

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!title.trim()) {
      toast.error("Question title is required");
      return;
    }
    if (!type) {
      toast.error("Please select a question type");
      return;
    }
    if (!device) {
      toast.error("Please select a device");
      return;
    }

    const payload = {
      deviceId: device,
      title: title.trim(),
      type,
      step: stepValue,
    };

    try {
      if (isEdit) {
        await updateQuestion({ id: question._id, data: payload }).unwrap();
        toast.success("Question updated");
      } else {
        await createQuestion(payload).unwrap();
        toast.success("Question added");
      }
      onClose();
    } catch (err) {
      toast.error(err?.data?.message || "Something went wrong");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-xl rounded-2xl bg-white shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-sky-50">
          <div className="min-w-0">
            <h3 className="text-lg font-simeibold text-gray-800">
              {isEdit ? "Edit Question" : "Add Question"}
            </h3>
            {/* Device and step are already decided by the page — show, don't ask. */}
            <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
              <span className="text-xs px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                {deviceName}
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600 border border-gray-200">
                Step {stepValue}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 shrink-0 rounded-lg border bg-white text-gray-500 hover:bg-gray-100 flex items-center justify-center"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-6 space-y-6 overflow-y-auto">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Question Title <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={2}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Does the screen have any cracks?"
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Answer Type <span className="text-red-500">*</span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {QUESTION_TYPES.map((item) => {
                const active = type === item.value;
                return (
                  <button
                    type="button"
                    key={item.value}
                    onClick={() => setType(item.value)}
                    className={`flex items-start gap-2.5 rounded-xl border px-3 py-2.5 text-left transition ${
                      active
                        ? "border-primary bg-blue-50"
                        : "border-gray-200 hover:border-primary hover:bg-blue-50/50"
                    }`}
                  >
                    <span
                      className={`mt-0.5 w-4 h-4 shrink-0 rounded-full border flex items-center justify-center ${
                        active
                          ? "border-primary bg-primary text-white"
                          : "border-gray-300"
                      }`}
                    >
                      {active && <Check size={11} strokeWidth={3} />}
                    </span>
                    <span className="min-w-0">
                      <span className="block text-sm font-medium text-gray-800">
                        {item.short}
                      </span>
                      <span className="block text-xs text-gray-500">
                        {item.hint}
                      </span>
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Only surfaced on edit — adding always uses the page's device. */}
          {isEdit && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Move to Device
              </label>
              <select
                value={device}
                onChange={(e) => setDevice(e.target.value)}
                className="w-full h-11 rounded-lg border border-gray-300 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {devices.map((item) => (
                  <option key={item._id} value={item._id}>
                    {capitalize(item.name)}
                  </option>
                ))}
              </select>
              <p className="mt-1.5 text-xs text-gray-400">
                Moves this question and its answer options to that device.
              </p>
            </div>
          )}
        </div>

        <div className="flex justify-end gap-3 px-6 py-4 border-t bg-gray-50">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border rounded-lg text-sm hover:bg-gray-100"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isLoading}
            className="flex items-center gap-2 px-5 py-2 bg-primary text-white rounded-lg text-sm disabled:opacity-60"
          >
            <Save size={16} />
            {isLoading
              ? isEdit
                ? "Updating..."
                : "Saving..."
              : isEdit
                ? "Update Question"
                : "Add Question"}
          </button>
        </div>
      </form>
    </div>
  );
};

export default QuestionModal;
