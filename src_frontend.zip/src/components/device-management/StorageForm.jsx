import React, { useState, useEffect } from "react";
import PageHeader from "../../components/PageHeader";
import { ArrowLeft, Save } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import {
  useGetStorageByIdQuery,
  useStorageCreateMutation,
  useStorageUpdateMutation,
} from "../../api/storage.api";
import { storageMediaTypes, storageTypes } from "../../lib/constant";

const StorageForm = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const { data: storageData, isLoading: isFetching } = useGetStorageByIdQuery(
    id,
    {
      skip: !id,
    },
  );
  const [createStorage, { isLoading: isCreating }] = useStorageCreateMutation();
  const [updateStorage, { isLoading: isUpdating }] = useStorageUpdateMutation();

  const isLoading = isCreating || isUpdating;

  const [ram, setRam] = useState("");
  const [rom, setRom] = useState("");
  const [romUnit, setRomUnit] = useState("");
  const [romMedia, setRomMedia] = useState("");

  useEffect(() => {
    if (!storageData?.data) return;

    const storage = storageData.data;
    // RAM — absent for devices sold by storage only, such as the iPhone
    const ramMatch = storage.ram?.match(/^(\d+)/);
    setRam(ramMatch ? ramMatch[1] : "");
    // ROM
    const romParts = (storage.rom || "").split(" ");
    setRom(romParts[0] || "");
    setRomUnit(romParts[1] || "");
    setRomMedia(romParts.slice(2).join(" "));
  }, [storageData]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!rom) {
      toast.error("ROM is required");
      return;
    }

    if (!romUnit) {
      toast.error("Please select ROM unit");
      return;
    }

    // An empty RAM is sent through so an edit can also clear it.
    const payload = {
      ram: ram ? `${ram} GB` : "",
      rom: `${rom} ${romUnit}${romMedia ? ` ${romMedia}` : ""}`,
    };
    try {
      if (id) {
        await updateStorage({
          id,
          ...payload,
        }).unwrap();

        toast.success("Storage Updated Successfully");
      } else {
        await createStorage(payload).unwrap();

        toast.success("Storage Added Successfully");
      }

      navigate("/device-management/storages");
    } catch (err) {
      toast.error(err?.data?.message || "Something went wrong");
    }
  };

  return (
    <div>
      <PageHeader
        title={id ? "Update Storage" : "Add Storage"}
        subtitle={
          id
            ? "Update storage configuration"
            : "Create a new storage configuration"
        }
      />

      <div className="max-w-7xl mx-auto mt-8">
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden"
        >
          {/* Header */}
          <div className="px-8 py-5 border-b bg-gray-50">
            <h2 className="text-xl font-simeibold text-gray-800">
              {id ? "Update Storage Information" : "Storage Information"}
            </h2>

            <p className="text-sm text-gray-500 mt-1">
              Fill in the storage details below. RAM is optional — some devices
              are sold by storage alone.
            </p>
          </div>

          {/* Body */}
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* RAM */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  RAM{" "}
                  <span className="text-gray-400 text-xs">
                    (optional — leave empty for devices like the iPhone)
                  </span>
                </label>

                <div className="flex gap-2">
                  <input
                    type="number"
                    min="1"
                    value={ram}
                    onChange={(e) => setRam(e.target.value)}
                    placeholder="Enter RAM (optional)"
                    className="flex-1 h-11 rounded-lg border border-gray-300 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />

                  <select
                    disabled
                    value="GB"
                    className="w-24 h-11 rounded-lg border border-gray-300 bg-gray-100 text-sm cursor-not-allowed"
                  >
                    <option>GB</option>
                  </select>
                </div>
              </div>

              {/* ROM */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Storage <span className="text-red-500">*</span>
                </label>

                <div className="grid grid-cols-3 gap-2">
                  {/* Number */}
                  <input
                    type="number"
                    min="1"
                    value={rom}
                    onChange={(e) => setRom(e.target.value)}
                    placeholder="Storage"
                    className="h-11 rounded-lg border border-gray-300 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />

                  {/* GB / TB / MB */}
                  <select
                    value={romUnit}
                    onChange={(e) => setRomUnit(e.target.value)}
                    className="h-11 rounded-lg border border-gray-300 px-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Select</option>

                    {storageTypes.map((item) => (
                      <option key={item._id} value={item.name}>
                        {item.name}
                      </option>
                    ))}
                  </select>

                  {/* Optional Storage Media */}
                  <select
                    value={romMedia}
                    onChange={(e) => setRomMedia(e.target.value)}
                    className="h-11 rounded-lg border border-gray-300 px-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Media (Optional)</option>

                    {storageMediaTypes.map((item) => (
                      <option key={item._id} value={item.name}>
                        {item.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="flex justify-end gap-3 px-6 py-4 border-t bg-gray-50">
            <button
              type="button"
              onClick={() => navigate(-1)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100 transition"
            >
              <ArrowLeft size={16} />
              Cancel
            </button>

            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 px-5 py-2 rounded-lg bg-primary text-white"
            >
              <Save size={16} />

              {isLoading
                ? id
                  ? "Updating..."
                  : "Saving..."
                : id
                  ? "Update Storage"
                  : "Save Storage"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default StorageForm;
