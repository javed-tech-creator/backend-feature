import React, { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import * as Icons from "lucide-react";
import { useAuth } from "../store/AuthContext";
import { toast } from "react-toastify";
import mylogo from "../assets/my-logo.png";

const sidebarItems = [
  {
    key: "dashboard",
    title: "Dashboard",
    icon: "LayoutDashboard",
    path: "/dashboard",
  },
  {
    key: "users",
    title: "Registered Users",
    icon: "UserRoundCheck",
    path: "/users",
  },
  {
    key: "orders",
    title: "Orders",
    icon: "ShoppingCart",
    path: "/orders",
  },

  {
    key: "devices",
    title: "Device Management",
    icon: "Smartphone",
    children: [
      {
        key: "device",
        title: "Devices",
        path: "/device-management/devices",
      },
      {
        key: "storage",
        title: "Storage",
        path: "/device-management/storages",
      },
      {
        key: "brand",
        title: "Brands",
        path: "/device-management/brands",
      },
      {
        key: "model",
        title: "Models",
        path: "/device-management/models",
      },
      {
        key: "questions",
        title: "Questions & Answers",
        path: "/device-management/questions",
      },
      {
        key: "pricing-calculator",
        title: "Pricing Calculator",
        path: "/device-management/pricing-calculator",
      },
    ],
  },
  {
    key: "team",
    title: "Our Team",
    icon: "UsersRound",
    path: "/team",
  },
  {
    key: "blog",
    title: "Blogs",
    icon: "Newspaper",
    path: "/blog",
  },
  {
    key: "inquiry",
    title: "Inquiry",
    icon: "CircleUser",
    path: "/inquiry",
  },

];

const Sidebar = () => {
  const [openDropdown, setOpenDropdown] = useState(null);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const navigate = useNavigate()

  const toggleDropdown = (key) => {
    if (isCollapsed) return;
    setOpenDropdown(openDropdown === key ? null : key);
  };

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
    if (!isCollapsed) {
      setOpenDropdown(null);
    }
  };

  return (
    <div className={`${isCollapsed ? 'w-16  tracking-wider flex flex-col justify-center items-center' : 'w-64'} bg-primary/50  h-screen ease-in-out shadow-2xl`}>
      {/* Header */}
      <div className="p-2">
        <div className="flex items-center justify-between h-14">
          {!isCollapsed && (
            <div className="flex items-center">
                 <img src={mylogo} alt="logo" className="h-12 w-12" />
            </div>
          )}
          <button
            onClick={toggleSidebar}
            className="p-2 rounded-lg bg-sky-50 hover:bg-sky-100 transition-colors duration-200 text-heading hover:text-heading cursor-pointer"
          >
            <Icons.Menu size={20} />
          </button>
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-2 space-y-2 overflow-y-auto flex-1">
        {sidebarItems.map((item, index) => {
          const Icon = Icons[item.icon] || Icons.Circle;
          const isActive = openDropdown === item.key;

          return (
            <div key={index} className="relative border-b border-white/50">
              {item.children ? (
                <>
                  <button
                    onClick={() => toggleDropdown(item.key)}
                    className={`w-full flex items-center text-gray-300  hover:text-white justify-between p-1.5 rounded-lg transition-all duration-200 group `}
                    //    ${
                    //   isActive 
                    //     ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white' 
                    //     : 'text-gray-300 hover:bg-gray-800 hover:text-white'
                    // }`}
                    title={isCollapsed ? item.title : ''}
                  >
                    <div className="flex items-center gap-3">
                      <Icon size={20} className="flex-shrink-0" />
                      {!isCollapsed && (
                        <span className="text-sm font-medium">{item.title}</span>
                      )}
                    </div>
                    {!isCollapsed && (
                      <Icons.ChevronDown
                        size={16}
                        className={`transition-transform duration-200 ${
                          isActive ? "rotate-180" : ""
                        }`}
                      />
                    )}
                  </button>

                  {isActive && !isCollapsed && (
                    <div className=" ml-4  border-l border-white/50 pl-4 mb-1">
                      {item.children.map((child, idx) => (
                        <NavLink
                          key={idx}
                          to={child.path}
                          className={({ isActive }) => `
                            block text-sm px-2 py-1 rounded-sm transition-colors duration-200
                            ${isActive 
                              ? 'text-heading bg-sky-50' 
                              : 'text-gray-300 hover:text-white '
                            }
                          `}
                        >
                          {child.title}
                        </NavLink>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <NavLink
                  to={item.path}
                  className={({ isActive }) => `
                    flex items-center gap-2 p-1.5 rounded-lg transition-all duration-200 group
                    ${isActive 
                      ? 'text-gray-300' 
                      : 'text-gray-300 hover: hover:text-white'
                    }
                  `}
                  title={isCollapsed ? item.title : ''}
                >
                  <Icon size={20} className="flex-shrink-0" />
                  {!isCollapsed && (
                    <span className="text-sm font-medium">{item.title}</span>
                  )}
                </NavLink>
              )}
            </div>
          );
        })}
      </nav>
    </div>
  );
};

export default Sidebar;