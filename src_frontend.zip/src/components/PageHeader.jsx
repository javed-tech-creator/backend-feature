import { Plus, PlusCircle } from 'lucide-react'
import React from 'react'
import { Link } from 'react-router-dom'

function PageHeader({title = 'Title' , path = "" , btnTitle="title" }) {
  return (
    <div>
         <div className="w-full border-l-4 border-l-primary mb-6 rounded-lg shadow-md bg-white p-3  transition duration-300">
        <div className="flex items-center justify-between bg-sky-50 p-1.5 border border-gray-200 rounded-md">
          <h2 className="text-xl text-heading animate-bounce px-4 font-simeibold">!! {title} !!</h2>
         {path && 
         <Link to={path} className='mx-3 bg-primary text-white px-4 py-1.5 cursor-pointer flex justify-center items-center gap-1 border border-gray-300 rounded-sm'>
          <Plus size={20}/> {btnTitle} 
          </Link>
         } 
        </div>
      </div>
    </div>
  )
}

export default PageHeader