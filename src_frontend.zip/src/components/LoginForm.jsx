import React, { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
// import ForgotPassword from "./ForgotPassword";
import logo from "../assets/logo-money.png";
import { useLocation, useNavigate } from "react-router-dom";
import { useLoginMutation } from "../api/auth.api";
import { useAuth } from "../store/AuthContext";
import { toast } from "react-toastify";
export default function Login() {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [identifierError, setIdentifierError] = useState(false);
  const [passwordError, setPasswordError] = useState(false);
  const [openForgot, setOpenForgot] = useState(false);
  const [resetEmail, setResetEmail] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const navigate = useNavigate();
  const validateInputs = () => {
    let isValid = true;

    if (!identifier.trim()) {
      setIdentifierError(true);
      isValid = false;
    } else {
      setIdentifierError(false);
    }

    if (!password.trim()) {
      setPasswordError(true);
      isValid = false;
    } else {
      setPasswordError(false);
    }

    return isValid;
  };

  const [login, { isLoading, error }] = useLoginMutation();
  const { setUserData } = useAuth();

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!validateInputs()) return;

    const formData = { identifier: identifier.trim(), password };

    try {
      const res = await login(formData).unwrap();
      const responseData = res?.data ?? res;

      setUserData(responseData);
      localStorage.setItem("userData", JSON.stringify(responseData));
      toast.success("Login successful!");
      navigate(`/dashboard`);
      setIdentifier("");
      setPassword("");
    } catch (err) {
      console.error("Login failed:", err);
      toast.error(
        err?.data?.message || "Login failed. Please check your credentials.",
      );
    }
  };
  const handleForgotPassword = () => {
    console.log("Reset email:", resetEmail);
    setOpenForgot(false);
    setResetEmail("");
  };

  return (
    // {/* <div className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8 "> */}

    <div className="w-full max-w-md bg-sky-100 rounded-2xl shadow-lg border border-border p-8 sm:p-10">
      <div className="flex flex-col items-center mb-6">
        <img src={logo} alt="Logo" className="h-24 w-30 mb-2" />
        <h2 className="text-2xl font-bold text-heading">Sign In</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Identifier */}
        <div>
          <label
            htmlFor="identifier"
            className="block text-sm font-simeibold text-heading mb-1"
          >
            Email / Phone
          </label>
          <input
            id="identifier"
            name="identifier"
            type="text"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            placeholder="Enter your email or phone number"
            className={`w-full px-4 py-3 border rounded-xl shadow-sm placeholder-text-light text-text bg-surface focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-all ${
              identifierError
                ? "border-danger focus:ring-danger focus:border-danger"
                : "border-border"
            }`}
          />
          {identifierError && (
            <p className="mt-1 text-sm text-red-600">
              Please enter your email or phone number
            </p>
          )}
        </div>

        {/* Password */}
        <div>
          <label
            htmlFor="password"
            className="block text-sm font-simeibold text-heading mb-1"
          >
            Password
          </label>
          <div className="relative">
            <input
              id="password"
              name="password"
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              className={`w-full px-4 py-3 pr-12 border rounded-xl shadow-sm placeholder-text-light text-text bg-surface focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-all ${
                passwordError
                  ? "border-danger focus:ring-danger focus:border-danger"
                  : "border-border"
              }`}
            />
            <button
              type="button"
              className="absolute inset-y-0 right-0 pr-3 flex items-center"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? (
                <EyeOff className="h-5 w-5 text-text-light hover:text-primary" />
              ) : (
                <Eye className="h-5 w-5 text-text-light hover:text-primary" />
              )}
            </button>
          </div>
          {passwordError && (
            <p className="mt-1 text-sm text-red-600">Password is required</p>
          )}
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isLoading}
          className={`w-full py-3 rounded-xl text-white font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all ${
            isLoading
              ? "bg-primary-hover cursor-not-allowed"
              : "bg-primary hover:bg-primary/90 cursor-pointer"
          }`}
        >
          {isLoading ? (
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mx-auto"></div>
          ) : (
            "Sign In"
          )}
        </button>
      </form>
    </div>
    // </div>
  );
}
