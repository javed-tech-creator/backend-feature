import React, { useEffect, useMemo, useState } from "react";
import { toast } from "react-toastify";
import {
  ChevronLeftIcon,
  ChevronRightIcon,
  ChevronUpIcon,
  ChevronDownIcon,
  ChevronsUpDownIcon,
  Loader2,
  Download,
  Search as SearchIcon,
} from "lucide-react";

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const PAGE_SIZE_OPTIONS = [10, 25, 50, 75, 100];

// Varying widths for skeleton cells so loading rows look natural
const SKW = [
  "72%",
  "85%",
  "60%",
  "50%",
  "55%",
  "68%",
  "45%",
  "78%",
  "62%",
  "40%",
  "30%",
];

// ---------------------------------------------------------------------------
// Cell renderers (badges / links / two-line customer cell)
// ---------------------------------------------------------------------------

const STATUS_STYLES = {
  approved: {
    bg: "rgba(34,197,94,0.14)",
    border: "rgba(34,197,94,0.4)",
    text: "#4ade80",
  },
  active: {
    bg: "rgba(34,197,94,0.14)",
    border: "rgba(34,197,94,0.4)",
    text: "#4ade80",
  },
  rejected: {
    bg: "rgba(239,68,68,0.14)",
    border: "rgba(239,68,68,0.4)",
    text: "#f87171",
  },
  cancelled: {
    bg: "rgba(239,68,68,0.14)",
    border: "rgba(239,68,68,0.4)",
    text: "#f87171",
  },
  requested: {
    bg: "rgba(245,158,11,0.14)",
    border: "rgba(245,158,11,0.4)",
    text: "#fbbf24",
  },
  pending: {
    bg: "rgba(245,158,11,0.14)",
    border: "rgba(245,158,11,0.4)",
    text: "#fbbf24",
  },
  default: {
    bg: "rgba(148,163,184,0.14)",
    border: "rgba(148,163,184,0.4)",
    text: "#94a3b8",
  },
};

const StatusBadge = ({ value }) => {
  if (value === null || value === undefined || value === "")
    return <span>--</span>;
  const key = String(value).toLowerCase();
  const s = STATUS_STYLES[key] || STATUS_STYLES.default;
  return (
    <span
      className="inline-block px-3 py-1 rounded-full text-xs font-simeibold tracking-wide"
      style={{
        backgroundColor: s.bg,
        border: `1px solid ${s.border}`,
        color: s.text,
      }}
    >
      {value}
    </span>
  );
};

const PillBadge = ({ value }) => {
  if (value === null || value === undefined || value === "")
    return <span>--</span>;
  return (
    <span className="inline-block px-3 py-1 rounded-md text-xs font-medium dt-pill">
      {value}
    </span>
  );
};

const ContractLink = ({ value, href }) => {
  if (value === null || value === undefined || value === "")
    return <span>--</span>;
  return (
    <a
      href={href || "#"}
      className="font-simeibold underline underline-offset-2 dt-contract-link"
      onClick={(e) => !href && e.preventDefault()}
    >
      {value}
    </a>
  );
};

const CustomerCell = ({ value, email }) => {
  if (value === null || value === undefined || value === "")
    return <span>--</span>;
  return (
    <div className="flex flex-col items-start text-left leading-tight">
      <span className="font-simeibold text-white text-[13px]">{value}</span>
      {email && <span className="dt-subtext text-[12px]">{email}</span>}
    </div>
  );
};

// Guesses a sensible default renderer based on the column key name,
// used only when columnConfig does not already provide a `render` fn.
const smartRender = (col, value, row) => {
  const key = String(col).toLowerCase();

  if (key.includes("status")) return <StatusBadge value={value} />;
  if (key.includes("payment")) return <PillBadge value={value} />;
  if (key === "contractid" || key === "id") {
    return <ContractLink value={value} href={row.href || row.url} />;
  }
  if (key.includes("customer") || key.includes("name")) {
    const email = row.email || row.contactEmail;
    return <CustomerCell value={value} email={email} />;
  }
  return value ?? "--";
};

// ---------------------------------------------------------------------------
// Sort icon
// ---------------------------------------------------------------------------

const SortIcon = ({ active, dir }) => {
  if (!active)
    return (
      <ChevronsUpDownIcon
        className="ml-1 inline-block opacity-25"
        width={11}
        height={11}
      />
    );
  return dir === "asc" ? (
    <ChevronUpIcon
      className="ml-1 inline-block dt-sort-active"
      width={11}
      height={11}
    />
  ) : (
    <ChevronDownIcon
      className="ml-1 inline-block dt-sort-active"
      width={11}
      height={11}
    />
  );
};

// ---------------------------------------------------------------------------
// CSV helpers
// ---------------------------------------------------------------------------

function escapeCsv(value) {
  if (value === null || value === undefined) return "";
  const str = String(value);
  if (/[",\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function generateCSV(rows, headers) {
  const headerRow = headers.map(escapeCsv).join(",");
  const dataRows = rows.map((row) =>
    headers.map((h) => escapeCsv(row[h])).join(","),
  );
  return [headerRow, ...dataRows].join("\n");
}

function downloadCSV(csv, filename) {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${filename}-${new Date().toISOString().split("T")[0]}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// ---------------------------------------------------------------------------
// Main Table
// ---------------------------------------------------------------------------

/**
 * Reusable data table with built-in client/server pagination, sorting, search,
 * loading skeleton and CSV export.
 *
 * Backward compatible with the old API:
 *   <Table data={rows} columnConfig={config} />
 *
 * Server-side pagination (limit + page) when `paginationMode="server"`:
 *   <Table
 *     data={rows}                       // current page rows
 *     columnConfig={config}
 *     paginationMode="server"
 *     totalRecords={total}              // total count from API
 *     page={page}                       // current page (1-based)
 *     pageSize={limit}                  // limit per page
 *     onPageChange={(p) => ...}         // call API with { page, limit }
 *     onPageSizeChange={(s) => ...}     // call API with new limit
 *     loading={isLoading}
 *     sortConfig={{ key, dir }}         // controlled server sort
 *     onSortChange={(key, dir) => ...}
 *     searchable
 *     onSearch={(q) => ...}             // server-side search
 *     exportConfig={{ fetchFn, mapRow, filename }}
 *   />
 */
const Table = ({
  data = [],
  columnConfig = {},
  pageSize: initialPageSize = 10,
  searchable = true,

  // Server-side pagination / sort / search
  paginationMode = "client", // "client" | "server"
  totalRecords,
  page: serverPage,
  pageSize: serverPageSize,
  onPageChange,
  onPageSizeChange,

  sortConfig, // { key, dir } — when provided sorting is controlled (server)
  onSortChange,

  searchValue, // controlled server-side search string
  onSearch,
  searchDebounceMs = 400,

  loading = false,
  emptyText = "No matching records found",
  exportConfig, // { fetchFn, currentParams, mapRow, filename, label }
}) => {
  const columns = Object.keys(columnConfig);
  const isServer = paginationMode === "server";
  const isSortControlled = !!onSortChange || !!sortConfig;

  // ---- client-side state ----
  const [search, setSearch] = useState("");
  const [sortCol, setSortCol] = useState(null);
  const [sortDir, setSortDir] = useState("asc");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(initialPageSize);
  const [exporting, setExporting] = useState(false);

  // ---- search (debounced) ----
  const [debouncedSearch, setDebouncedSearch] = useState("");
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(search), searchDebounceMs);
    return () => clearTimeout(t);
  }, [search, searchDebounceMs]);

  // ---- active sort (controlled vs client) ----
  const activeSortKey = isSortControlled ? (sortConfig?.key ?? null) : sortCol;
  const activeSortDir = isSortControlled ? (sortConfig?.dir ?? "asc") : sortDir;

  // ---- filter (client only) ----
  const filtered = useMemo(() => {
    if (isServer) return data;
    if (!debouncedSearch.trim()) return data;
    const q = debouncedSearch.toLowerCase();
    return data.filter((row) =>
      columns.some((col) =>
        String(row[col] ?? "")
          .toLowerCase()
          .includes(q),
      ),
    );
  }, [data, debouncedSearch, columns, isServer]);

  // ---- sort (client only; when controlled, server already sorted) ----
  const sorted = useMemo(() => {
    if (isServer || isSortControlled) return filtered;
    if (!sortCol) return filtered;
    const copy = [...filtered];
    copy.sort((a, b) => {
      const av = a[sortCol];
      const bv = b[sortCol];
      if (av == null) return 1;
      if (bv == null) return -1;
      if (typeof av === "number" && typeof bv === "number") {
        return sortDir === "asc" ? av - bv : bv - av;
      }
      return sortDir === "asc"
        ? String(av).localeCompare(String(bv))
        : String(bv).localeCompare(String(av));
    });
    return copy;
  }, [filtered, sortCol, sortDir, isServer, isSortControlled]);

  // ---- totals ----
  const effectiveTotal = isServer
    ? (totalRecords ?? data.length)
    : sorted.length;
  const effectivePageSize = isServer ? (serverPageSize ?? pageSize) : pageSize;
  const effectivePage = isServer ? (serverPage ?? page) : page;
  const totalPages = Math.max(1, Math.ceil(effectiveTotal / effectivePageSize));
  const currentPage = Math.min(effectivePage, totalPages);

  // ---- rows for current page (client only slices; server sends already-paged rows) ----
  const displayData = useMemo(() => {
    if (isServer) return data;
    const start = (currentPage - 1) * effectivePageSize;
    return sorted.slice(start, start + effectivePageSize);
  }, [sorted, currentPage, effectivePageSize, isServer, data]);

  // ---- handlers ----
  const handleSort = (col) => {
    if (isSortControlled) {
      const nextDir =
        sortConfig?.key === col && sortConfig?.dir === "asc" ? "desc" : "asc";
      onSortChange?.(col, nextDir);
      return;
    }
    if (sortCol === col) {
      setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    } else {
      setSortCol(col);
      setSortDir("asc");
    }
    if (!isServer) setPage(1);
  };

  const goToPage = (p) => {
    if (p < 1 || p > totalPages) return;
    if (isServer) onPageChange?.(p);
    else setPage(p);
  };

  const handlePageSizeChange = (s) => {
    if (isServer) onPageSizeChange?.(s);
    else {
      setPageSize(s);
      setPage(1);
    }
  };

  const handleSearchChange = (val) => {
    setSearch(val);
    if (isServer && onSearch) onSearch(val);
    if (!isServer) setPage(1);
  };

  // ---- CSV export ----
  const handleExport = async () => {
    if (!exportConfig) return;
    if (!effectiveTotal) {
      toast.error("No data to export");
      return;
    }
    setExporting(true);
    try {
      let rows;
      if (exportConfig.fetchFn) {
        const result = await exportConfig.fetchFn({
          ...(exportConfig.currentParams || {}),
          page: 1,
          limit: effectiveTotal,
        });
        if (!result?.success || !result?.data) {
          toast.error(result?.error || "Failed to fetch data for export");
          return;
        }
        rows = Array.isArray(result.data)
          ? result.data
          : (result.data?.data ?? []);
      } else {
        rows = sorted;
      }

      if (!rows.length) {
        toast.error("No data to export");
        return;
      }

      const mapped = rows.map(exportConfig.mapRow);
      const headers = mapped.length ? Object.keys(mapped[0]) : [];
      const csv = generateCSV(mapped, headers);
      downloadCSV(csv, exportConfig.filename || "export");
      toast.success(`Exported ${rows.length} records`);
    } catch {
      toast.error("Something went wrong during export");
    } finally {
      setExporting(false);
    }
  };

  // ---- page number window (compact: 1 … p-1 p p+1 … last) ----
  const pageNumbers = useMemo(() => {
    const out = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) out.push(i);
    } else {
      out.push(1);
      if (currentPage > 3) out.push("…");
      for (
        let i = Math.max(2, currentPage - 1);
        i <= Math.min(totalPages - 1, currentPage + 1);
        i++
      )
        out.push(i);
      if (currentPage < totalPages - 2) out.push("…");
      out.push(totalPages);
    }
    return out;
  }, [totalPages, currentPage]);

  const rangeStart =
    effectiveTotal === 0 ? 0 : (currentPage - 1) * effectivePageSize + 1;
  const rangeEnd = Math.min(currentPage * effectivePageSize, effectiveTotal);
  const totalCols = columns.length + 1;

  // ---- render ----
  return (
    <div className="dt-dark-theme rounded-xl overflow-hidden">
      {/* toolbar: search + export */}
      {(searchable || exportConfig) && (
        <div className="flex items-center justify-between px-4 py-3 gap-3 flex-wrap dt-toolbar">
          <div className="relative">
            {searchable && (
              <>
                <SearchIcon
                  size={14}
                  className="dt-search-icon"
                  style={{
                    position: "absolute",
                    left: 10,
                    top: "50%",
                    transform: "translateY(-50%)",
                  }}
                />
                <input
                  type="text"
                  value={isServer ? (searchValue ?? search) : search}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  placeholder="Search..."
                  className="dt-search-input"
                  style={{ paddingLeft: 30 }}
                />
              </>
            )}
          </div>

          {exportConfig && (
            <button
              type="button"
              onClick={handleExport}
              disabled={exporting || !effectiveTotal}
              className="dt-export-btn"
            >
              {exporting ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                <Download size={14} />
              )}
              <span>{exportConfig.label || "Export CSV"}</span>
            </button>
          )}
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr>
              <th className="px-4 py-3 text-xs uppercase font-simeibold text-center">
                #
              </th>
              {columns.map((col) => (
                <th
                  key={col}
                  onClick={() => handleSort(col)}
                  className="px-4 py-3 text-xs uppercase font-simeibold text-center dt-th-sortable"
                  style={{ whiteSpace: "nowrap" }}
                >
                  <span className="inline-flex items-center">
                    {columnConfig[col]?.label || col}
                    <SortIcon
                      active={activeSortKey === col}
                      dir={activeSortDir}
                    />
                  </span>
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {loading ? (
              Array.from({ length: 8 }).map((_, i) => (
                <tr
                  key={`sk-${i}`}
                  className={`dt-skel-row ${i % 2 !== 0 ? "" : "dt-stripe"}`}
                >
                  <td className="px-4 py-3.5 w-12">
                    <div
                      className="dt-skel"
                      style={{ width: "40%", height: 10 }}
                    />
                  </td>
                  {columns.map((col, j) => (
                    <td key={col} className="px-4 py-3.5">
                      <div
                        className="dt-skel"
                        style={{ width: SKW[j % SKW.length], height: 10 }}
                      />
                    </td>
                  ))}
                </tr>
              ))
            ) : displayData.length === 0 ? (
              <tr>
                <td
                  colSpan={totalCols}
                  className="px-4 py-14 text-center dt-empty"
                >
                  {emptyText}
                </td>
              </tr>
            ) : (
              displayData.map((row, idx) => {
                const rowNum = (currentPage - 1) * effectivePageSize + idx + 1;
                return (
                  <tr
                    key={row._id || row.id || idx}
                    className={idx % 2 !== 0 ? "" : "dt-stripe"}
                  >
                    <td className="px-4 py-3 text-center dt-index">{rowNum}</td>
                    {columns.map((col) => (
                      <td
                        key={col}
                        className="px-4 py-3 text-center"
                        style={{ whiteSpace: "nowrap" }}
                      >
                        {columnConfig[col]?.render
                          ? columnConfig[col].render(row[col], row)
                          : smartRender(col, row[col], row)}
                      </td>
                    ))}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Footer: info + page size + pagination */}
      {!loading && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 px-4 py-3 dt-footer">
          <div className="dt-info text-xs flex items-center gap-3">
            <span>
              Showing {rangeStart}–{rangeEnd} of {effectiveTotal}
            </span>
            <select
              value={effectivePageSize}
              onChange={(e) => handlePageSizeChange(Number(e.target.value))}
              className="dt-page-select"
            >
              {PAGE_SIZE_OPTIONS.map((n) => (
                <option key={n} value={n}>
                  {n} / page
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1">
            <button
              className="dt-page-btn"
              onClick={() => goToPage(1)}
              disabled={currentPage === 1}
            >
              «
            </button>
            <button
              className="dt-page-btn"
              onClick={() => goToPage(currentPage - 1)}
              disabled={currentPage === 1}
            >
              <ChevronLeftIcon width={14} height={14} />
            </button>

            {pageNumbers.map((p, i) =>
              p === "…" ? (
                <span key={`ellipsis-${i}`} className="dt-page-ellipsis">
                  …
                </span>
              ) : (
                <button
                  key={p}
                  onClick={() => goToPage(p)}
                  className={`dt-page-btn ${p === currentPage ? "dt-page-btn-active" : ""}`}
                >
                  {p}
                </button>
              ),
            )}

            <button
              className="dt-page-btn"
              onClick={() => goToPage(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              <ChevronRightIcon width={14} height={14} />
            </button>
            <button
              className="dt-page-btn"
              onClick={() => goToPage(totalPages)}
              disabled={currentPage === totalPages}
            >
              »
            </button>
          </div>
        </div>
      )}

      {/* ---- Dark theme styling ---- */}
      <style>{`
        .dt-dark-theme {
          background-color: #0b1220;
          border: 1px solid #1c2740;
          box-shadow: 0 8px 24px rgba(0,0,0,0.25);
        }

        table { border-collapse: separate; border-spacing: 0; }

        .dt-dark-theme thead th {
          background-color: #0b1220;
          color: #7c93c9;
          border-bottom: 1px solid #1c2740;
          font-size: 11px;
          letter-spacing: 0.05em;
        }
        .dt-th-sortable { cursor: pointer; user-select: none; }
        .dt-th-sortable:hover { color: #a9bde3; }

        .dt-sort-active { color: #e0ac52; }

        .dt-dark-theme tbody tr { background-color: #0b1220; }
        .dt-dark-theme tbody tr.dt-stripe { background-color: #0d1626; }
        .dt-dark-theme tbody tr:hover { background-color: #101a30; }
        .dt-dark-theme tbody td {
          border-bottom: 1px solid #16203a;
          color: #e2e8f0;
          font-size: 13px;
        }

        .dt-index { color: #56698f; font-size: 12px; }

        .dt-contract-link { color: #e0ac52; text-decoration-color: rgba(224,172,82,0.5); }
        .dt-contract-link:hover { color: #f0bc66; }

        .dt-subtext { color: #6f88bf; }

        .dt-pill {
          background-color: #131f38;
          border: 1px solid #24344f;
          color: #d7e2f5;
        }

        /* toolbar */
        .dt-toolbar { border-bottom: 1px solid #16203a; }
        .dt-search-icon { color: #56698f; }
        .dt-search-input {
          background-color: #0f1a2e;
          border: 1px solid #24344f;
          color: #e2e8f0;
          border-radius: 6px;
          padding: 6px 12px;
          font-size: 13px;
          outline: none;
          min-width: 220px;
        }
        .dt-search-input::placeholder { color: #56698f; }
        .dt-search-input:focus { border-color: #3b78e7; box-shadow: 0 0 0 2px rgba(59,120,231,0.15); }

        .dt-export-btn {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          border-radius: 6px;
          border: 1px solid #24344f;
          background-color: #0f1a2e;
          color: #d7e2f5;
          font-size: 12px;
          cursor: pointer;
          transition: all .15s ease;
        }
        .dt-export-btn:hover:not(:disabled) { border-color: #e0ac52; color: #e0ac52; }
        .dt-export-btn:disabled { opacity: .4; cursor: not-allowed; }

        /* footer */
        .dt-footer { border-top: 1px solid #16203a; }
        .dt-info { color: #7c93c9; }
        .dt-page-select {
          background-color: #0f1a2e;
          border: 1px solid #24344f;
          color: #e2e8f0;
          border-radius: 6px;
          padding: 3px 6px;
          font-size: 12px;
          outline: none;
        }

        .dt-page-btn {
          color: #7c93c9;
          background: transparent;
          border: none;
          border-radius: 8px;
          min-width: 30px;
          height: 30px;
          font-size: 13px;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }
        .dt-page-btn:hover:not(:disabled) { background: #101a30; color: #fff; }
        .dt-page-btn:disabled { color: #3c4a68; cursor: not-allowed; }
        .dt-page-btn-active {
          background: #16233d;
          color: #ffffff;
          border: 1px solid #2c3e5e;
        }
        .dt-page-ellipsis { color: #435374; padding: 0 4px; font-size: 13px; }

        .dt-empty { color: #94a3b8; }

        /* skeleton */
        .dt-skel {
          background: linear-gradient(90deg, #16203a 25%, #1c2740 37%, #16203a 63%);
          background-size: 400% 100%;
          animation: dt-shimmer 1.4s ease infinite;
          border-radius: 6px;
          display: block;
        }
        @keyframes dt-shimmer {
          0% { background-position: 100% 50%; }
          100% { background-position: 0 50%; }
        }

        /* Scrollbar */
        .dt-dark-theme ::-webkit-scrollbar { height: 8px; }
        .dt-dark-theme ::-webkit-scrollbar-thumb { background: #24344f; border-radius: 8px; }
      `}</style>
    </div>
  );
};

export default Table;
