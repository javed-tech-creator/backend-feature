// store/index.js or store.js

import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { persistStore, persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage"; // localStorage
import { authApi } from "../api/auth.api.js";
import { blogApi } from "../api/blog.api.js";
import { teamApi } from "../api/team.api.js";
import { inquiryApi } from "../api/inquiry.api.js";
import { visitorApi } from "../api/visitor.api.js";
import { deviceApi } from "../api/device.api.js";
import { storageApi } from "../api/storage.api.js";
import { brandApi } from "../api/brand.api.js";
import { modelApi } from "../api/model.api.js";
import { questionApi } from "../api/question.api.js";
import { calculatorApi } from "../api/calculator.api.js";
import { userApi } from "../api/user.api.js";
import { orderApi } from "../api/order.api.js";
const persistConfig = {
  key: "root",
  storage,
  whitelist: ["auth"],
};

const rootReducer = combineReducers({
  [authApi.reducerPath]: authApi.reducer,
  [blogApi.reducerPath]: blogApi.reducer,
  [teamApi.reducerPath]: teamApi.reducer,
  [inquiryApi.reducerPath]: inquiryApi.reducer,
  [visitorApi.reducerPath]: visitorApi.reducer,
  [deviceApi.reducerPath]: deviceApi.reducer,
  [storageApi.reducerPath]: storageApi.reducer,
  [brandApi.reducerPath]: brandApi.reducer,
  [modelApi.reducerPath]: modelApi.reducer,
  [questionApi.reducerPath]: questionApi.reducer,
  [calculatorApi.reducerPath]: calculatorApi.reducer,
  [userApi.reducerPath]: userApi.reducer,
  [orderApi.reducerPath]: orderApi.reducer,
});

const persistedReducer = persistReducer(persistConfig, rootReducer);
export const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }).concat(
      authApi.middleware,
      blogApi.middleware,
      teamApi.middleware,
      inquiryApi.middleware,
      visitorApi.middleware,
      deviceApi.middleware,
      storageApi.middleware,
      brandApi.middleware,
      modelApi.middleware,
      questionApi.middleware,
      calculatorApi.middleware,
      userApi.middleware,
      orderApi.middleware,
    ),
  devTools: import.meta.env.VITE_MODE !== "Pro",
});

export const persistor = persistStore(store);
