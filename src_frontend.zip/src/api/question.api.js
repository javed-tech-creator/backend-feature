import { createApi } from "@reduxjs/toolkit/query/react";
import { axiosBaseQuery } from "./axiosBaseQuery";

// Single API slice covering both Question and QuestionOption resources.
// Questions carry a `step` number — "steps" are just groupings of questions
// that share the same step value (there is no separate Step entity).
export const questionApi = createApi({
  baseQuery: axiosBaseQuery(),
  reducerPath: "questionApi",
  tagTypes: ["Question", "QuestionOption"],
  endpoints: (builder) => ({
    // ---- Questions ----
    getAllQuestion: builder.query({
      query: (params = {}) => ({
        url: `/question`,
        method: "GET",
        params,
      }),
      providesTags: ["Question"],
    }),

    getQuestionById: builder.query({
      query: (id) => ({
        url: `/question/${id}`,
        method: "GET",
      }),
      providesTags: ["Question"],
    }),

    questionCreate: builder.mutation({
      query: (data) => ({
        url: `/admin/question`,
        method: "POST",
        data,
      }),
      invalidatesTags: ["Question"],
    }),

    questionUpdate: builder.mutation({
      query: ({ id, data }) => ({
        url: `/admin/question/${id}`,
        method: "PATCH",
        data,
      }),
      invalidatesTags: ["Question"],
    }),

    // Drag-to-reorder posts the whole reordered set in one go.
    reorderQuestions: builder.mutation({
      query: (items) => ({
        url: `/admin/question/reorder`,
        method: "PATCH",
        data: { items },
      }),
      invalidatesTags: ["Question"],
    }),

    deleteQuestion: builder.mutation({
      query: ({ id }) => ({
        url: `/admin/question/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Question", "QuestionOption"],
    }),

    // ---- Question Options ----
    getAllQuestionOption: builder.query({
      query: (params = {}) => ({
        url: `/question-option`,
        method: "GET",
        params,
      }),
      providesTags: ["QuestionOption"],
    }),

    // The question list embeds each question's options, so an option change has
    // to invalidate "Question" too or the list would keep serving stale options.
    optionCreate: builder.mutation({
      query: (data) => ({
        url: `/admin/question-option`,
        method: "POST",
        data,
      }),
      invalidatesTags: ["QuestionOption", "Question"],
    }),

    optionUpdate: builder.mutation({
      query: ({ id, data }) => ({
        url: `/admin/question-option/${id}`,
        method: "PATCH",
        data,
      }),
      invalidatesTags: ["QuestionOption", "Question"],
    }),

    deleteOption: builder.mutation({
      query: ({ id }) => ({
        url: `/admin/question-option/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["QuestionOption", "Question"],
    }),
  }),
});

export const {
  useGetAllQuestionQuery,
  useGetQuestionByIdQuery,
  useQuestionCreateMutation,
  useQuestionUpdateMutation,
  useReorderQuestionsMutation,
  useDeleteQuestionMutation,
  useGetAllQuestionOptionQuery,
  useOptionCreateMutation,
  useOptionUpdateMutation,
  useDeleteOptionMutation,
} = questionApi;
