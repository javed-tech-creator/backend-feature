import { createApi } from "@reduxjs/toolkit/query/react";
import { axiosBaseQuery } from "./axiosBaseQuery";

export const deviceApi = createApi({
  baseQuery: axiosBaseQuery(),
  reducerPath: "deviceApi",
  tagTypes: ["Device"],
  endpoints: (builder) => ({
    deviceCreate: builder.mutation({
      query: ({ formData }) => ({
        url: `/admin/device`,
        method: "POST",
        data: formData,
      }),
      invalidatesTags: ["Device"],
    }),
    deviceUpdate: builder.mutation({
      query: ({ formData, id }) => ({
        url: `/admin/device/${id}`,
        method: "PATCH",
        data: formData,
      }),
      invalidatesTags: ["Device"],
    }),

    getDeviceById: builder.query({
      query: (id) => ({
        url: `/device/${id}`,
        method: "GET",
      }),
      providesTags: ["Device"],
    }),

    getAllDevice: builder.query({
      query: ({ page, limit, search, ...rest } = {}) => ({
        url: `/device`,
        method: "GET",
        params: { page, limit, search, ...rest },
      }),
      providesTags: ["Device"],
    }),

    deleteDevice: builder.mutation({
      query: ({ id }) => ({
        url: `/admin/device/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Device"],
    }),
  }),
});

export const {
  useDeviceCreateMutation,
  useGetAllDeviceQuery,
  useGetDeviceByIdQuery,
  useDeleteDeviceMutation,
  useDeviceUpdateMutation,
} = deviceApi;
