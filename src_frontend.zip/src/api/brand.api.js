import { createApi } from "@reduxjs/toolkit/query/react";
import { axiosBaseQuery } from "./axiosBaseQuery";

export const brandApi = createApi({
  baseQuery: axiosBaseQuery(),
  reducerPath: "brandApi",
  tagTypes: ["Brand"],
  endpoints: (builder) => ({
    brandCreate: builder.mutation({
      query: ({ formData }) => ({
        url: `/admin/brand`,
        method: "POST",
        data: formData,
      }),
      invalidatesTags: ["Brand"],
    }),
    brandUpdate: builder.mutation({
      query: ({ formData, id }) => ({
        url: `/admin/brand/${id}`,
        method: "PATCH",
        data: formData,
      }),
      invalidatesTags: ["Brand"],
    }),

    getBrandById: builder.query({
      query: (id) => ({
        url: `/brand/${id}`,
        method: "GET",
      }),
      providesTags: ["Brand"],
    }),

    getAllBrand: builder.query({
      query: ({ page, limit, search, ...rest } = {}) => ({
        url: `/brand`,
        method: "GET",
        params: { page, limit, search, ...rest },
      }),
      providesTags: ["Brand"],
    }),

    getBrandsByDevice: builder.query({
      query: (deviceId) => ({
        url: `/brand?deviceId=${deviceId}`,
        method: "GET",
      }),
      providesTags: ["Brand"],
    }),

    deleteBrand: builder.mutation({
      query: ({ id }) => ({
        url: `/admin/brand/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Brand"],
    }),
  }),
});

export const {
  useBrandCreateMutation,
  useGetAllBrandQuery,
  useGetBrandByIdQuery,
  useDeleteBrandMutation,
  useBrandUpdateMutation,
  useGetBrandsByDeviceQuery,
} = brandApi;
