import { createApi } from "@reduxjs/toolkit/query/react";
import { axiosBaseQuery } from "./axiosBaseQuery";

export const modelApi = createApi({
  baseQuery: axiosBaseQuery(),
  reducerPath: "modelApi",
  tagTypes: ["Model"],
  endpoints: (builder) => ({
    modelCreate: builder.mutation({
      query: (formData) => ({
        url: `/admin/model`,
        method: "POST",
        data: formData,
      }),
      invalidatesTags: ["Model"],
    }),
    modelUpdate: builder.mutation({
      query: ({ id, formData }) => ({
        url: `/admin/model/${id}`,
        method: "PATCH",
        data: formData,
      }),
      invalidatesTags: ["Model"],
    }),

    getModelById: builder.query({
      query: (id) => ({
        url: `/model/${id}`,
        method: "GET",
      }),
      providesTags: ["Model"],
    }),

    getAllModel: builder.query({
      query: ({ page, limit, search, ...rest } = {}) => ({
        url: `/model`,
        method: "GET",
        params: { page, limit, search, ...rest },
      }),
      providesTags: ["Model"],
    }),

    // Always returns full list (no pagination) — used by dropdowns/forms
    getAllModelList: builder.query({
      query: () => ({
        url: `/model`,
        method: "GET",
      }),
      providesTags: ["Model"],
    }),

    deleteModel: builder.mutation({
      query: ({ id }) => ({
        url: `/admin/model/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Model"],
    }),
    uploadModels: builder.mutation({
      query: ({ file, deviceId, brandId }) => {
        const fd = new FormData();
        fd.append("file", file);
        fd.append("deviceId", deviceId);
        fd.append("brandId", brandId);

        return {
          url: `/admin/model/upload`,
          method: "POST",
          data: fd,
        };
      },
      invalidatesTags: ["Model"],
    }),
    
  }),
});

export const {
  useModelCreateMutation,
  useGetAllModelQuery,
  useGetAllModelListQuery,
  useGetModelByIdQuery,
  useDeleteModelMutation,
  useModelUpdateMutation,
  useUploadModelsMutation,
} = modelApi;
