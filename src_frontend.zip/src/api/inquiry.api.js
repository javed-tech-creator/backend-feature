import { createApi } from "@reduxjs/toolkit/query/react";
import { axiosBaseQuery } from "./axiosBaseQuery";

export const inquiryApi = createApi({
  baseQuery: axiosBaseQuery(),
  reducerPath: "inquiryApi",
  tagTypes: ["Inquiry"],
  endpoints: (builder) => ({
    inquiryCreate: builder.mutation({
      query: ({ formData }) => ({
        url: `/inquiry`,
        method: "POST",
        data: formData,
      }),
      invalidatesTags: ["Inquiry"],
    }),

    getAllInquiry: builder.query({
      query: ({ page, limit, search, ...rest } = {}) => ({
        url: `/inquiry`,
        method: "GET",
        params: { page, limit, search, ...rest },
      }),
      providesTags: ["Inquiry"],
    }),

    deleteInquiry: builder.mutation({
      query: ({id}) => ({
        url: `/inquiry/${id}`,
        method: "DELETE",
      }),
       invalidatesTags: ["Inquiry"],
    }),
  }),
});

export const { useInquiryCreateMutation, useGetAllInquiryQuery , useDeleteInquiryMutation } = inquiryApi;
