import { createApi } from "@reduxjs/toolkit/query/react";
import { axiosBaseQuery } from "./axiosBaseQuery";

export const orderApi = createApi({
  reducerPath: "orderApi",
  baseQuery: axiosBaseQuery(),
  tagTypes: ["Order"],
  endpoints: (builder) => ({
    getAllOrders: builder.query({
      query: ({ page, limit, search, ...rest } = {}) => ({
        url: "/admin/orders",
        method: "GET",
        params: {
          page,
          limit,
          search,
          ...rest,
        },
      }),
      providesTags: ["Order"],
    }),
    getOrderById: builder.query({
      query: ({ id }) => ({
        url: `/admin/order/${id}`,
        method: "GET",
      }),
      providesTags: (_result, _error, { id }) => [{ type: "Order", id }],
    }),
    uploadOrderDocuments: builder.mutation({
      query: ({ orderId, formData }) => ({
        url: `/admin/order/${orderId}`,
        method: "POST",
        data: formData,
      }),
      invalidatesTags: (_result, _error, { orderId }) => [
        "Order",
        { type: "Order", id: orderId },
      ],
    }),
    updateOrderStatus: builder.mutation({
      query: ({ id, status }) => ({
        url: `/admin/order/${id}/status`,
        method: "PATCH",
        data: { status },
      }),
      async onQueryStarted(
        { id, status, queryParams },
        { dispatch, queryFulfilled },
      ) {
        const patchResult = dispatch(
          orderApi.util.updateQueryData(
            "getAllOrders",
            queryParams,
            (draft) => {
              const rows = Array.isArray(draft?.data?.data)
                ? draft.data.data
                : Array.isArray(draft?.data)
                  ? draft.data
                  : Array.isArray(draft)
                    ? draft
                    : [];
              const order = rows.find(
                (item) => (item?._id || item?.id || item?.orderId) === id,
              );

              if (order) order.status = status;
            },
          ),
        );

        try {
          await queryFulfilled;
        } catch {
          patchResult.undo();
        }
      },
      invalidatesTags: (_result, _error, { id }) => [
        "Order",
        { type: "Order", id },
      ],
    }),
  }),
});

export const {
  useGetAllOrdersQuery,
  useGetOrderByIdQuery,
  useUploadOrderDocumentsMutation,
  useUpdateOrderStatusMutation,
} = orderApi;
