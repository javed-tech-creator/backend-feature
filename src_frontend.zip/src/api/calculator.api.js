import { createApi } from "@reduxjs/toolkit/query/react";
import { axiosBaseQuery } from "./axiosBaseQuery";

// The calculator reads the same questions/options the Questions & Answers screen
// manages — only the pricing endpoints are its own.
export const calculatorApi = createApi({
  baseQuery: axiosBaseQuery(),
  reducerPath: "calculatorApi",
  tagTypes: ["Question"],
  endpoints: (builder) => ({
    // Active questions for a device, in the order the admin arranged them.
    getCalculatorQuestions: builder.query({
      query: (deviceId) => ({
        url: `/calculator/questions`,
        method: "GET",
        params: { deviceId },
      }),
      providesTags: ["Question"],
    }),

    calculatePrice: builder.mutation({
      query: (data) => ({
        url: `/calculator/calculate`,
        method: "POST",
        data,
      }),
    }),
  }),
});

export const { useGetCalculatorQuestionsQuery, useCalculatePriceMutation } =
  calculatorApi;
