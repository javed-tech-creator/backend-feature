import { createApi } from "@reduxjs/toolkit/query/react";
import { axiosBaseQuery } from "./axiosBaseQuery";

export const storageApi = createApi({
  baseQuery: axiosBaseQuery(),
  reducerPath: "storageApi",
  tagTypes: ["Storage"],
  endpoints: (builder) => ({
    storageCreate: builder.mutation({
      query: (formData) => ({
        url: `/admin/storage`,
        method: "POST",
        data: formData,
      }),
      invalidatesTags: ["Storage"],
    }),
    storageUpdate: builder.mutation({
      query: ({ id, ...body }) => ({
        url: `/admin/storage/${id}`,
        method: "PATCH",
        data: body,
      }),
      invalidatesTags: ["Storage"],
    }),

    getStorageById: builder.query({
      query: (id) => ({
        url: `/storage/${id}`,
        method: "GET",
      }),
      providesTags: ["Storage"],
    }),

    getAllStorage: builder.query({
      query: ({ page, limit, search, ...rest } = {}) => ({
        url: `/storage`,
        method: "GET",
        params: { page, limit, search, ...rest },
      }),
      providesTags: ["Storage"],
    }),

    deleteStorage: builder.mutation({
      query: ({ id }) => ({
        url: `/admin/storage/${id}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Storage"],
    }),
  }),
});

export const {
  useStorageCreateMutation,
  useGetAllStorageQuery,
  useGetStorageByIdQuery,
  useDeleteStorageMutation,
  useStorageUpdateMutation,
} = storageApi;
