import { createApi } from "@reduxjs/toolkit/query/react";
import { axiosBaseQuery } from "./axiosBaseQuery";

export const userApi = createApi({
  reducerPath: "userApi",
  baseQuery: axiosBaseQuery(),
  tagTypes: ["User"],
  endpoints: (builder) => ({
    getAllUsers: builder.query({
      query: ({ page, limit, search, ...rest } = {}) => ({
        url: "/admin/users",
        method: "GET",
        params: {
          page,
          limit,
          search,
          isDeleted: false,
          ...rest,
        },
      }),
      providesTags: ["User"],
    }),
  }),
});

export const { useGetAllUsersQuery } = userApi;
