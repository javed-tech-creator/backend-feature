// Iconify search. Icon artwork is fetched on demand from the public Iconify API
// by @iconify/react, so no icon data is bundled — this module only searches.
const SEARCH_URL = "https://api.iconify.design/search";

// Shown before the user types: icons that suit device-condition questions, so
// the picker is useful straight away and without a request.
export const STARTER_ICONS = [
  "mdi:cellphone",
  "mdi:tablet",
  "mdi:laptop",
  "mdi:watch",
  "mdi:camera",
  "mdi:monitor",
  "mdi:cellphone-screenshot",
  "mdi:image-broken-variant",
  "mdi:battery",
  "mdi:battery-charging",
  "mdi:power-plug",
  "mdi:usb-port",
  "mdi:volume-high",
  "mdi:microphone",
  "mdi:headphones",
  "mdi:speaker",
  "mdi:wifi",
  "mdi:bluetooth",
  "mdi:sim",
  "mdi:fingerprint",
  "mdi:face-recognition",
  "mdi:water",
  "mdi:water-off",
  "mdi:hammer-wrench",
  "mdi:wrench",
  "mdi:cog",
  "mdi:shield-check",
  "mdi:lock",
  "mdi:lock-open",
  "mdi:check-circle",
  "mdi:close-circle",
  "mdi:alert-circle",
  "mdi:help-circle",
  "mdi:thumb-up",
  "mdi:thumb-down",
  "mdi:star",
  "mdi:package-variant",
  "mdi:receipt",
  "mdi:cash",
  "mdi:tag",
];

/**
 * Search the whole Iconify catalogue (200k+ icons across every collection).
 * Returns names like "mdi:cellphone" — exactly what gets stored in the DB.
 * `signal` lets the caller drop a superseded keystroke.
 */
export async function searchIcons(query, { limit = 96, signal } = {}) {
  const q = query.trim();

  if (!q) return STARTER_ICONS;

  const url = `${SEARCH_URL}?query=${encodeURIComponent(q)}&limit=${limit}`;
  const response = await fetch(url, { signal });

  if (!response.ok) {
    throw new Error("Icon search failed");
  }

  const body = await response.json();

  return Array.isArray(body?.icons) ? body.icons : [];
}
