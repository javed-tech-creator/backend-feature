import React from "react";
import { useParams } from "react-router-dom";

import DevicePage from "./DevicePage";
import BrandPage from "./BrandPage";
import ModelPage from "./ModelPage";
import StoragePage from "./StoragePage";
import QuestionPage from "./QuestionPage";
import PricingCalculatorPage from "./PricingCalculatorPage";

const DeviceForm = () => {
  const { section } = useParams();

  const components = {
    devices: DevicePage,
    brands: BrandPage,
    models: ModelPage,
    storages: StoragePage,
    questions: QuestionPage,
    "pricing-calculator": PricingCalculatorPage,
  };

  const Component = components[section];

  if (!Component) {
    return <div className="text-center py-10">Invalid Section</div>;
  }

  return <Component />;
};

export default DeviceForm;
