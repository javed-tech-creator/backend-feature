import React, { useEffect, useMemo, useState } from "react";
import Swal from "sweetalert2";
import { toast } from "react-toastify";
import {
  Plus,
  Pencil,
  Trash2,
  Layers,
  ListChecks,
  HelpCircle,
  Loader2,
  Smartphone,
  ChevronRight,
  ToggleLeft,
  ToggleRight,
  GripVertical,
} from "lucide-react";

import PageHeader from "../../components/PageHeader";
import { AppIcon } from "../../components/IconPicker";
import QuestionModal, {
  QUESTION_TYPES,
} from "../../components/device-management/QuestionModal";
import OptionModal from "../../components/device-management/OptionModal";
import {
  useGetAllQuestionQuery,
  useQuestionUpdateMutation,
  useReorderQuestionsMutation,
  useDeleteQuestionMutation,
  useDeleteOptionMutation,
} from "../../api/question.api";
import { useGetAllDeviceQuery } from "../../api/device.api";
import { capitalize, formatAdjustment } from "../../lib/helper";

// RTK data may come back as a plain array or a paginated { data: [...] }.
const toArray = (res) => {
  const inner = res?.data;
  if (Array.isArray(inner)) return inner;
  if (Array.isArray(inner?.data)) return inner.data;
  return [];
};

const TYPE_LABEL = QUESTION_TYPES.reduce((acc, t) => {
  acc[t.value] = t.short;
  return acc;
}, {});

const TYPE_BADGE = {
  radio: "bg-blue-50 text-blue-700 border-blue-200",
  checkbox: "bg-violet-50 text-violet-700 border-violet-200",
  boolean: "bg-emerald-50 text-emerald-700 border-emerald-200",
  input: "bg-amber-50 text-amber-700 border-amber-200",
};

const QuestionPage = () => {
  const { data: deviceRes, isLoading: dLoading } = useGetAllDeviceQuery({
    limit: 100,
  });
  const devices = useMemo(() => toArray(deviceRes), [deviceRes]);

  // Steps and questions are scoped to one device at a time.
  const [deviceId, setDeviceId] = useState("");

  // Land on the first device once they arrive, and recover if it disappears.
  useEffect(() => {
    if (!devices.length) return;
    if (devices.some((device) => device._id === deviceId)) return;
    setDeviceId(devices[0]._id);
  }, [devices, deviceId]);

  const { data: questionRes, isLoading: qLoading } = useGetAllQuestionQuery(
    { deviceId, limit: 100 },
    { skip: !deviceId },
  );
  const [deleteQuestion] = useDeleteQuestionMutation();
  const [deleteOption] = useDeleteOptionMutation();
  const [updateQuestion] = useQuestionUpdateMutation();
  const [reorderQuestions] = useReorderQuestionsMutation();

  const questions = useMemo(() => toArray(questionRes), [questionRes]);

  const activeDevice = useMemo(
    () => devices.find((device) => device._id === deviceId) || null,
    [devices, deviceId],
  );

  // Group questions into steps and sort ascending.
  const steps = useMemo(() => {
    const map = {};
    for (const q of questions) {
      const step = Number(q.step) || 0;
      (map[step] ||= []).push(q);
    }

    // Inside a step the admin's drag order wins; creation order breaks ties.
    Object.values(map).forEach((list) =>
      list.sort(
        (a, b) =>
          (a.sortOrder ?? 0) - (b.sortOrder ?? 0) ||
          new Date(a.createdAt) - new Date(b.createdAt),
      ),
    );

    return Object.keys(map)
      .map(Number)
      .sort((a, b) => a - b)
      .map((step) => ({ step, questions: map[step] }));
  }, [questions]);

  // Draft steps: created locally, not yet persisted (no questions in DB yet).
  const [draftSteps, setDraftSteps] = useState([]);

  // Merge real + draft steps for rendering.
  const allSteps = useMemo(() => {
    const existing = new Set(steps.map((s) => s.step));
    const drafts = draftSteps
      .filter((n) => !existing.has(n))
      .map((n) => ({ step: n, questions: [], isDraft: true }));
    return [...steps, ...drafts].sort((a, b) => a.step - b.step);
  }, [steps, draftSteps]);

  // Which step is open in the right-hand panel.
  const [selectedStep, setSelectedStep] = useState(null);

  // Drafts and the open step belong to the device that was selected — drop both
  // when switching, otherwise step 3 of "phone" would linger over "laptop".
  useEffect(() => {
    setDraftSteps([]);
    setSelectedStep(null);
  }, [deviceId]);

  // Open the first step automatically so the panel is never pointlessly empty.
  useEffect(() => {
    if (!allSteps.length) return;
    if (allSteps.some((s) => s.step === selectedStep)) return;
    setSelectedStep(allSteps[0].step);
  }, [allSteps, selectedStep]);

  const activeStepData = useMemo(
    () => allSteps.find((s) => s.step === selectedStep) || null,
    [allSteps, selectedStep],
  );

  // Drag-to-reorder. `localOrder` holds the ids in their dragged order so the
  // list does not snap back while the save round-trips.
  const [dragIndex, setDragIndex] = useState(null);
  const [overIndex, setOverIndex] = useState(null);
  const [localOrder, setLocalOrder] = useState(null);

  useEffect(() => {
    setLocalOrder(null);
  }, [selectedStep, deviceId]);

  const stepQuestions = useMemo(() => {
    const list = activeStepData?.questions || [];
    if (!localOrder) return list;

    const byId = new Map(list.map((q) => [q._id, q]));
    const ordered = localOrder.map((id) => byId.get(id)).filter(Boolean);

    // A question added or removed since the drag makes the saved order stale.
    return ordered.length === list.length ? ordered : list;
  }, [activeStepData, localOrder]);

  const handleDrop = async (targetIndex) => {
    const from = dragIndex;
    setDragIndex(null);
    setOverIndex(null);

    if (from === null || from === targetIndex) return;

    const next = [...stepQuestions];
    const [moved] = next.splice(from, 1);
    next.splice(targetIndex, 0, moved);
    setLocalOrder(next.map((q) => q._id));

    try {
      await reorderQuestions(
        next.map((q, index) => ({ id: q._id, sortOrder: index })),
      ).unwrap();
      toast.success("Question order updated");
    } catch (err) {
      setLocalOrder(null);
      toast.error(err?.data?.message || "Failed to reorder questions");
    }
  };

  // Modal state
  const [questionModal, setQuestionModal] = useState(null); // { mode, step, question }
  const [optionModal, setOptionModal] = useState(null); // { mode, questionId, option }

  const nextStep = useMemo(() => {
    const nums = [...steps.map((s) => s.step), ...draftSteps];
    return (nums.length ? Math.max(...nums) : 0) + 1;
  }, [steps, draftSteps]);

  const handleAddStep = () => {
    setDraftSteps((prev) => [...prev, nextStep]);
    setSelectedStep(nextStep);
  };

  const handleDeleteStep = async (step, stepQuestions) => {
    const result = await Swal.fire({
      title: `Delete Step ${step}?`,
      text: stepQuestions.length
        ? `This will delete ${stepQuestions.length} question(s) and all their answer options.`
        : "This step is empty and will be removed.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#dc2626",
      confirmButtonText: "Delete",
    });
    if (!result.isConfirmed) return;

    try {
      await Promise.all(
        stepQuestions.map((q) => deleteQuestion({ id: q._id }).unwrap()),
      );
      setDraftSteps((prev) => prev.filter((n) => n !== step));
      toast.success(`Step ${step} deleted`);
    } catch (err) {
      toast.error(err?.data?.message || "Failed to delete step");
    }
  };

  const handleDeleteQuestion = async (question) => {
    const result = await Swal.fire({
      title: "Delete Question?",
      text: "This question and all its answer options will be removed.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#dc2626",
      confirmButtonText: "Delete",
    });
    if (!result.isConfirmed) return;

    try {
      await deleteQuestion({ id: question._id }).unwrap();
      toast.success("Question deleted");
    } catch (err) {
      toast.error(err?.data?.message || "Failed to delete question");
    }
  };

  // A disabled question stays put but is skipped by the calculator.
  const handleToggleActive = async (question) => {
    const nextActive = question.isActive === false;

    try {
      await updateQuestion({
        id: question._id,
        data: { isActive: nextActive },
      }).unwrap();
      toast.success(nextActive ? "Question enabled" : "Question disabled");
    } catch (err) {
      toast.error(err?.data?.message || "Failed to update question");
    }
  };

  const handleDeleteOption = async (option) => {
    const result = await Swal.fire({
      title: "Delete Option?",
      text: "This answer option will be removed.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#dc2626",
      confirmButtonText: "Delete",
    });
    if (!result.isConfirmed) return;

    try {
      await deleteOption({ id: option._id }).unwrap();
      toast.success("Option deleted");
    } catch (err) {
      toast.error(err?.data?.message || "Failed to delete option");
    }
  };

  const deviceName = activeDevice ? capitalize(activeDevice.name) : "";

  return (
    <div>
      <PageHeader title="Questions & Answers" />

      {/* Step 1 — pick the device the questionnaire belongs to */}
      <section className="bg-white rounded-2xl shadow-md border border-gray-200 border-l-4 border-l-primary overflow-hidden">
        <div className="px-5 py-3 border-b border-gray-200 bg-sky-50 flex items-center gap-2">
          <span className="w-6 h-6 rounded-full bg-primary text-white text-xs font-bold flex items-center justify-center">
            1
          </span>
          <h2 className="text-sm font-simeibold text-gray-800">Choose Device</h2>
          <span className="text-xs text-gray-500">
            each device has its own steps &amp; questions
          </span>
        </div>

        <div className="p-4">
          {dLoading ? (
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Loader2 size={16} className="animate-spin" /> Loading devices...
            </div>
          ) : devices.length === 0 ? (
            <p className="text-sm text-gray-500">
              No devices yet — add a device first, questions are grouped under
              one.
            </p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {devices.map((device) => {
                const active = device._id === deviceId;
                return (
                  <button
                    key={device._id}
                    onClick={() => setDeviceId(device._id)}
                    className={`inline-flex items-center gap-2 rounded-lg border px-3.5 py-2 text-sm transition ${
                      active
                        ? "border-primary bg-primary text-white shadow-sm"
                        : "border-gray-300 bg-white text-gray-700 hover:border-primary hover:bg-blue-50"
                    }`}
                  >
                    {device.logo ? (
                      <img
                        src={device.logo}
                        alt=""
                        className="w-5 h-5 object-contain"
                      />
                    ) : (
                      <Smartphone size={16} />
                    )}
                    {capitalize(device.name)}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Step 2 — steps on the left, the open step's questions on the right */}
      {deviceId && (
        <div className="mt-5 grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-5 items-start">
          {/* Steps sidebar */}
          <section className="bg-white rounded-2xl shadow-md border border-gray-200 border-l-4 border-l-primary overflow-hidden">
            <div className="px-5 py-3 border-b border-gray-200 bg-sky-50 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-primary text-white text-xs font-bold flex items-center justify-center">
                2
              </span>
              <h2 className="text-sm font-simeibold text-gray-800">Steps</h2>
              <span className="ml-auto text-xs text-gray-500">
                {allSteps.length}
              </span>
            </div>

            <div className="p-3 space-y-2">
              {qLoading ? (
                <p className="flex items-center justify-center gap-2 px-2 py-6 text-sm text-gray-400">
                  <Loader2 size={15} className="animate-spin" /> Loading...
                </p>
              ) : allSteps.length === 0 ? (
                <p className="px-2 py-6 text-center text-sm text-gray-400">
                  No steps yet
                </p>
              ) : (
                allSteps.map(({ step, questions: stepQuestions, isDraft }) => {
                  const active = step === selectedStep;
                  return (
                    <button
                      key={step}
                      onClick={() => setSelectedStep(step)}
                      className={`w-full flex items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition ${
                        active
                          ? "border-primary bg-blue-50"
                          : "border-gray-200 bg-white hover:bg-gray-50"
                      }`}
                    >
                      <span
                        className={`w-9 h-9 shrink-0 rounded-lg flex items-center justify-center text-sm font-bold ${
                          active
                            ? "bg-primary text-white"
                            : "bg-sky-100 text-sky-700"
                        }`}
                      >
                        {step}
                      </span>

                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-1.5">
                          <span className="text-sm font-medium text-gray-800">
                            Step {step}
                          </span>
                          {isDraft && (
                            <span className="text-[10px] uppercase px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700">
                              Draft
                            </span>
                          )}
                        </span>
                        <span className="block text-xs text-gray-500">
                          {stepQuestions.length} question
                          {stepQuestions.length !== 1 ? "s" : ""}
                        </span>
                      </span>

                      <ChevronRight
                        size={16}
                        className={active ? "text-primary" : "text-gray-300"}
                      />
                    </button>
                  );
                })
              )}
            </div>

            <div className="px-3 pb-3">
              <button
                onClick={handleAddStep}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border-2 border-dashed border-gray-300 text-sm text-gray-600 hover:border-primary hover:text-primary hover:bg-blue-50 transition"
              >
                <Plus size={16} /> Add Step
              </button>
            </div>
          </section>

          {/* Open step */}
          <section className="bg-white rounded-2xl shadow-md border border-gray-200 border-l-4 border-l-primary overflow-hidden">
            {!activeStepData ? (
              <div className="text-center py-20 px-6">
                <Layers size={38} className="mx-auto text-gray-300 mb-3" />
                <p className="font-medium text-gray-700">
                  {deviceName
                    ? `No steps for ${deviceName} yet`
                    : "No step selected"}
                </p>
                <p className="text-sm text-gray-500 mt-1">
                  Add a step on the left to start building this questionnaire.
                </p>
              </div>
            ) : (
              <>
                <div className="px-5 py-4 border-b border-gray-200 bg-sky-50 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <h2 className="font-simeibold text-gray-800 flex items-center gap-2">
                      Step {activeStepData.step}
                      {activeStepData.isDraft && (
                        <span className="text-[10px] uppercase px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">
                          Draft
                        </span>
                      )}
                    </h2>
                    <p className="text-xs text-gray-500 mt-0.5 flex items-center gap-1.5">
                      <HelpCircle size={13} />
                      {activeStepData.questions.length} question
                      {activeStepData.questions.length !== 1 ? "s" : ""}
                      {deviceName ? ` · ${deviceName}` : ""}
                      {activeStepData.questions.length > 1
                        ? " · drag the handle to reorder"
                        : ""}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() =>
                        setQuestionModal({
                          mode: "add",
                          step: activeStepData.step,
                        })
                      }
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 text-sm rounded-lg bg-primary text-white hover:opacity-90"
                    >
                      <Plus size={15} /> Add Question
                    </button>
                    <button
                      onClick={() =>
                        handleDeleteStep(
                          activeStepData.step,
                          activeStepData.questions,
                        )
                      }
                      title="Delete step"
                      className="w-9 h-9 rounded-lg border border-red-200 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white flex items-center justify-center"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>

                <div className="p-5 space-y-4">
                  {activeStepData.questions.length === 0 ? (
                    <div className="text-center py-12 border-2 border-dashed border-gray-200 rounded-xl">
                      <HelpCircle
                        size={30}
                        className="mx-auto text-gray-300 mb-2"
                      />
                      <p className="text-sm text-gray-500">
                        No questions in this step yet.
                      </p>
                      <button
                        onClick={() =>
                          setQuestionModal({
                            mode: "add",
                            step: activeStepData.step,
                          })
                        }
                        className="mt-3 inline-flex items-center gap-1.5 text-sm text-primary hover:underline"
                      >
                        <Plus size={15} /> Add the first question
                      </button>
                    </div>
                  ) : (
                    stepQuestions.map((q, qIndex) => {
                      const qOptions = q.options || [];
                      const dragging = dragIndex === qIndex;
                      const dropTarget = overIndex === qIndex && !dragging;
                      return (
                        <div
                          key={q._id}
                          onDragOver={(e) => {
                            // Without this the browser refuses the drop.
                            e.preventDefault();
                            setOverIndex(qIndex);
                          }}
                          onDragLeave={() =>
                            setOverIndex((prev) =>
                              prev === qIndex ? null : prev,
                            )
                          }
                          onDrop={() => handleDrop(qIndex)}
                          className={`rounded-xl border border-gray-200 border-l-4 overflow-hidden transition ${
                            dragging ? "opacity-40" : ""
                          } ${
                            dropTarget
                              ? "border-l-primary ring-2 ring-primary/30"
                              : "border-l-sky-300"
                          }`}
                        >
                          {/* Question header */}
                          <div className="flex items-start justify-between gap-3 px-4 py-3 bg-sky-50 border-b border-gray-200">
                            <div className="flex items-start gap-3 min-w-0">
                              {/* Only the handle is draggable, so text stays selectable. */}
                              <span
                                draggable
                                onDragStart={() => setDragIndex(qIndex)}
                                onDragEnd={() => {
                                  setDragIndex(null);
                                  setOverIndex(null);
                                }}
                                title="Drag to reorder"
                                className="mt-1 shrink-0 cursor-grab active:cursor-grabbing text-gray-400 hover:text-primary"
                              >
                                <GripVertical size={16} />
                              </span>

                              <span className="mt-0.5 w-7 h-7 shrink-0 rounded-lg bg-primary text-white text-xs font-simeibold flex items-center justify-center">
                                Q{qIndex + 1}
                              </span>
                              <div className="min-w-0">
                                <p className="font-medium text-gray-800 break-words">
                                  {q.title}
                                </p>
                                <div className="mt-1 flex flex-wrap items-center gap-1.5">
                                  <span
                                    className={`inline-flex items-center text-[11px] px-2 py-0.5 rounded-full border ${
                                      TYPE_BADGE[q.type] ||
                                      "bg-gray-50 text-gray-600 border-gray-200"
                                    }`}
                                  >
                                    {TYPE_LABEL[q.type] || q.type}
                                  </span>

                                  {q.isActive === false && (
                                    <span className="inline-flex items-center text-[11px] px-2 py-0.5 rounded-full border bg-gray-100 text-gray-500 border-gray-300">
                                      Disabled
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                onClick={() => handleToggleActive(q)}
                                title={
                                  q.isActive === false
                                    ? "Enable question"
                                    : "Disable question"
                                }
                                className={`w-8 h-8 rounded-lg border flex items-center justify-center ${
                                  q.isActive === false
                                    ? "border-gray-300 bg-gray-50 text-gray-400 hover:bg-gray-600 hover:text-white"
                                    : "border-emerald-200 bg-emerald-50 text-emerald-600 hover:bg-emerald-600 hover:text-white"
                                }`}
                              >
                                {q.isActive === false ? (
                                  <ToggleLeft size={16} />
                                ) : (
                                  <ToggleRight size={16} />
                                )}
                              </button>
                              <button
                                onClick={() =>
                                  setQuestionModal({ mode: "edit", question: q })
                                }
                                title="Edit question"
                                className="w-8 h-8 rounded-lg border border-blue-200 bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white flex items-center justify-center"
                              >
                                <Pencil size={14} />
                              </button>
                              <button
                                onClick={() => handleDeleteQuestion(q)}
                                title="Delete question"
                                className="w-8 h-8 rounded-lg border border-red-200 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white flex items-center justify-center"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>

                          {/* Options */}
                          <div className="p-4">
                            <div className="flex items-center justify-between mb-3">
                              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-gray-500 uppercase tracking-wide">
                                <ListChecks size={14} /> Answer Options (
                                {qOptions.length})
                              </span>
                              <button
                                onClick={() =>
                                  setOptionModal({
                                    mode: "add",
                                    questionId: q._id,
                                  })
                                }
                                className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                              >
                                <Plus size={14} /> Add Option
                              </button>
                            </div>

                            {qOptions.length === 0 ? (
                              <p className="text-xs text-gray-400 italic">
                                No options added yet.
                              </p>
                            ) : (
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                {qOptions.map((opt) => (
                                  <div
                                    key={opt._id}
                                    className="group flex items-center gap-3 rounded-lg border border-gray-200 px-3 py-2 hover:border-primary"
                                  >
                                    <span className="w-9 h-9 rounded-lg bg-sky-50 border border-sky-100 flex items-center justify-center text-primary shrink-0">
                                      {opt.icon ? (
                                        <AppIcon name={opt.icon} size={18} />
                                      ) : (
                                        <ListChecks
                                          size={16}
                                          className="text-gray-400"
                                        />
                                      )}
                                    </span>
                                    <div className="min-w-0 flex-1">
                                      <p className="text-sm text-gray-800 truncate">
                                        {opt.title}
                                      </p>
                                      {opt.value !== null &&
                                        opt.value !== undefined && (
                                          <p className={`text-xs ${opt.operation === "increase" ? "text-green-500":"text-red-500"}`}>
                                            {formatAdjustment(opt)}
                                          </p>
                                        )}
                                    </div>
                                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                                      <button
                                        onClick={() =>
                                          setOptionModal({
                                            mode: "edit",
                                            option: opt,
                                          })
                                        }
                                        title="Edit option"
                                        className="w-7 h-7 rounded-md border border-blue-200 bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white flex items-center justify-center"
                                      >
                                        <Pencil size={12} />
                                      </button>
                                      <button
                                        onClick={() => handleDeleteOption(opt)}
                                        title="Delete option"
                                        className="w-7 h-7 rounded-md border border-red-200 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white flex items-center justify-center"
                                      >
                                        <Trash2 size={12} />
                                      </button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </>
            )}
          </section>
        </div>
      )}

      {/* Modals */}
      {questionModal && (
        <QuestionModal
          mode={questionModal.mode}
          deviceId={deviceId}
          devices={devices}
          step={questionModal.step}
          question={questionModal.question}
          onClose={() => setQuestionModal(null)}
        />
      )}

      {optionModal && (
        <OptionModal
          mode={optionModal.mode}
          questionId={optionModal.questionId}
          option={optionModal.option}
          onClose={() => setOptionModal(null)}
        />
      )}
    </div>
  );
};

export default QuestionPage;
