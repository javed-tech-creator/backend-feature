import React from "react";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";
import {
  useDeleteStorageMutation,
  useGetAllStorageQuery,
} from "../../api/storage.api";
import { Pencil, Trash2, Eye } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { toast } from "react-toastify";
import { usePagination, extractPaginatedData } from "../../lib/usePagination";

const StoragePage = () => {
  const navigate = useNavigate();

  const {
    page,
    limit,
    search,
    params,
    onPageChange,
    onPageSizeChange,
    onSearchChange,
  } = usePagination({ initialLimit: 10 });

  const { data, isLoading } = useGetAllStorageQuery(params);
  const [deleteStorage, { isLoading: isDeleting }] = useDeleteStorageMutation(); // Backend response ke hisaab se adjust kar lena

  const { rows: storageList, totalRecords } = extractPaginatedData(data, {
    clientPage: page,
    clientLimit: limit,
    clientSearch: search,
  });

  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: "Delete Storage?",
      text: "This action cannot be undone.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Delete",
      cancelButtonText: "Cancel",
      confirmButtonColor: "#dc2626",
    });

    if (!result.isConfirmed) return;

    try {
      await deleteStorage({ id }).unwrap();
      toast.success("Storage deleted successfully");
    } catch (err) {
      toast.error(err?.data?.message || "Failed to delete Storage");
    }
  };

  const columnConfig = {
    ram: {
      label: "RAM",
      render: (value) => value || "--",
    },

    rom: {
      label: "ROM",
    },
    slug: {
      label: "Slug",
    },

    createdAt: {
      label: "Created At",
      render: (value) => (value ? new Date(value).toLocaleDateString() : "--"),
    },

    action: {
      label: "Action",
      render: (_, row) => (
        <div className="flex items-center justify-center gap-2">
          <button
            title="Edit"
            onClick={() =>
              navigate(`/device-management/storages/update/${row._id}`)
            }
            className="w-9 h-9 rounded-lg border border-blue-200 bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white flex items-center justify-center"
          >
            <Pencil size={17} />
          </button>

          <button
            title="Delete"
            className="w-9 h-9 rounded-lg border border-red-200 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white flex items-center justify-center"
            onClick={() => handleDelete(row._id)}
          >
            <Trash2 size={17} />
          </button>
        </div>
      ),
    },
  };

  return (
    <div>
      <PageHeader
        title="Storage Management"
        path="add"
        btnTitle="Add Storage"
      />

      <div className="mt-5">
        <Table
          data={storageList}
          columnConfig={columnConfig}
          paginationMode="server"
          totalRecords={totalRecords}
          page={page}
          pageSize={limit}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
          loading={isLoading}
          searchValue={search}
          onSearch={onSearchChange}
        />
      </div>
    </div>
  );
};

export default StoragePage;
