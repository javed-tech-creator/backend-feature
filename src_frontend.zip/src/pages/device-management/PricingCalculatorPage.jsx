import React from "react";

import PageHeader from "../../components/PageHeader";
import CalculatorPreview from "../../components/device-management/CalculatorPreview";

/**
 * Pricing Calculator — tests the live pricing rules end to end. The questions
 * and their deductions are managed on the Questions & Answers screen.
 */
const PricingCalculatorPage = () => (
  <div>
    <PageHeader title="Pricing Calculator" />
    <CalculatorPreview />
  </div>
);

export default PricingCalculatorPage;
