import React from "react";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";
import { Eye, Pencil, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { toast } from "react-toastify";

import {
  useDeleteBrandMutation,
  useGetAllBrandQuery,
} from "../../api/brand.api";
import { capitalize } from "../../lib/helper";
import { usePagination, extractPaginatedData } from "../../lib/usePagination";

const BrandPage = () => {
  const navigate = useNavigate();

  const {
    page,
    limit,
    search,
    params,
    onPageChange,
    onPageSizeChange,
    onSearchChange,
  } = usePagination({ initialLimit: 10 });

  const { data, isLoading } = useGetAllBrandQuery(params);

  const [deleteBrand] = useDeleteBrandMutation();

  const { rows: brandList, totalRecords } = extractPaginatedData(data, {
    clientPage: page,
    clientLimit: limit,
    clientSearch: search,
  });

  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: "Delete Brand?",
      text: "This action cannot be undone.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#dc2626",
      confirmButtonText: "Delete",
    });

    if (!result.isConfirmed) return;

    try {
      await deleteBrand({ id }).unwrap();
      toast.success("Brand deleted successfully");
    } catch (err) {
      toast.error(err?.data?.message || "Failed to delete brand");
    }
  };

  const columnConfig = {
    deviceId: {
      label: "Device",
      render: (_, row) => capitalize(row.deviceId?.name),
    },

    name: {
      label: "Brand Name",
      render: (value) => capitalize(value),
    },

    logo: {
      label: "Logo",
      render: (value) =>
        value ? (
          <a href={value} target="_blank" rel="noreferrer">
            <img
              src={value}
              alt="logo"
              className="w-12 h-12 rounded-md border object-contain mx-auto"
            />
          </a>
        ) : (
          "--"
        ),
    },
    slug: {
      label: "Slug",
    },
    createdAt: {
      label: "Created At",
      render: (value) => (value ? new Date(value).toLocaleDateString() : "--"),
    },

    action: {
      label: "Action",
      render: (_, row) => (
        <div className="flex justify-center gap-2">
          <button
            className="w-9 h-9 rounded-lg border bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white flex items-center justify-center"
            onClick={() =>
              navigate(`/device-management/brands/update/${row._id}`)
            }
          >
            <Pencil size={17} />
          </button>

          <button
            className="w-9 h-9 rounded-lg border bg-red-50 text-red-600 hover:bg-red-600 hover:text-white flex items-center justify-center"
            onClick={() => handleDelete(row._id)}
          >
            <Trash2 size={17} />
          </button>
        </div>
      ),
    },
  };

  return (
    <div>
      <PageHeader title="Brands Management" path="add" btnTitle="Add Brand" />

      <div className="mt-5">
        <Table
          data={brandList}
          columnConfig={columnConfig}
          paginationMode="server"
          totalRecords={totalRecords}
          page={page}
          pageSize={limit}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
          loading={isLoading}
          searchValue={search}
          onSearch={onSearchChange}
        />
      </div>
    </div>
  );
};

export default BrandPage;
