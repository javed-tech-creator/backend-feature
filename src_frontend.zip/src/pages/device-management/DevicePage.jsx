import React from "react";
import PageHeader from "../../components/PageHeader";
import {
  useDeleteDeviceMutation,
  useGetAllDeviceQuery,
} from "../../api/device.api";
import Table from "../../components/Table";
import { Pencil, Trash2, Eye } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { toast } from "react-toastify";
import { capitalize } from "../../lib/helper";
import { usePagination, extractPaginatedData } from "../../lib/usePagination";

const DevicePage = () => {
  const {
    page,
    limit,
    search,
    params,
    onPageChange,
    onPageSizeChange,
    onSearchChange,
  } = usePagination({ initialLimit: 10 });

  const { data, isLoading } = useGetAllDeviceQuery(params);
  const navigate = useNavigate();
  const [deleteDevice, { isLoading: isDeleting }] = useDeleteDeviceMutation(); // Backend response ke hisaab se adjust kar lena
  const { rows: deviceList, totalRecords } = extractPaginatedData(data, {
    clientPage: page,
    clientLimit: limit,
    clientSearch: search,
  });
  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: "Delete Device?",
      text: "This action cannot be undone.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Delete",
      cancelButtonText: "Cancel",
      confirmButtonColor: "#dc2626",
    });

    if (!result.isConfirmed) return;

    try {
      await deleteDevice({ id }).unwrap();
      toast.success("Device deleted successfully");
    } catch (err) {
      toast.error(err?.data?.message || "Failed to delete device");
    }
  };

  const columnConfig = {
    logo: {
      label: "Logo",
      render: (value) =>
        value ? (
          <a
            href={value}
            target="_blank"
            rel="noopener noreferrer"
            title="View Logo"
          >
            <img
              src={value}
              alt="logo"
              className="w-12 h-12 rounded-md object-contain mx-auto border border-gray-200 p-1 hover:scale-110 transition-transform duration-200 cursor-pointer"
            />
          </a>
        ) : (
          "--"
        ),
    },

    name: {
      label: "Device Name",
      render: (value) => capitalize(value),
    },
    slug: {
      label: "Slug",
    },

    createdAt: {
      label: "Created At",
      render: (value) => (value ? new Date(value).toLocaleDateString() : "--"),
    },

    action: {
      label: "Action",
      render: (_, row) => (
        <div className="flex items-center justify-center gap-2">
          {/* Edit */}
          <button
            title="Edit"
            className="w-9 h-9 flex items-center justify-center rounded-lg border border-blue-200 bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white transition-all duration-200 cursor-pointer"
            onClick={() =>
              navigate(`/device-management/devices/update/${row._id}`)
            }
          >
            <Pencil size={17} />
          </button>

          {/* Delete */}
          <button
            title="Delete"
            className="w-9 h-9 flex items-center justify-center rounded-lg border border-red-200 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white transition-all duration-200 cursor-pointer"
            onClick={() => handleDelete(row._id)}
          >
            <Trash2 size={17} />
          </button>
        </div>
      ),
    },
  };

  return (
    <div>
      <PageHeader title="Device Management" path="add" btnTitle="Add Device" />

      <div className="mt-5">
        <Table
          data={deviceList}
          columnConfig={columnConfig}
          paginationMode="server"
          totalRecords={totalRecords}
          page={page}
          pageSize={limit}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
          loading={isLoading}
          searchValue={search}
          onSearch={onSearchChange}
        />
      </div>
    </div>
  );
};

export default DevicePage;
