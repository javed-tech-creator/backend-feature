import React from "react";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";
import { Pencil, Trash2 } from "lucide-react";
import { useNavigate, Link } from "react-router-dom";
import Swal from "sweetalert2";
import { toast } from "react-toastify";

import {
  useDeleteModelMutation,
  useGetAllModelQuery,
} from "../../api/model.api";
import { capitalize, formatPrice, storageLabel } from "../../lib/helper";
import { usePagination, extractPaginatedData } from "../../lib/usePagination";

const ModelPage = () => {
  const navigate = useNavigate();

  const {
    page,
    limit,
    search,
    params,
    onPageChange,
    onPageSizeChange,
    onSearchChange,
  } = usePagination({ initialLimit: 10 });

  const { data, isLoading } = useGetAllModelQuery(params);
  const [deleteModel] = useDeleteModelMutation();

  const { rows: modelList, totalRecords } = extractPaginatedData(data, {
    clientPage: page,
    clientLimit: limit,
    clientSearch: search,
  });

  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: "Delete Model?",
      text: "This action cannot be undone.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#dc2626",
      confirmButtonText: "Delete",
      cancelButtonText: "Cancel",
    });

    if (!result.isConfirmed) return;

    try {
      await deleteModel({ id }).unwrap();
      toast.success("Model deleted successfully");
    } catch (err) {
      toast.error(err?.data?.message || "Failed to delete Model");
    }
  };

  const columnConfig = {
    deviceId: {
      label: "Device",
      render: (_, row) => capitalize(row.brandId?.deviceId?.name),
    },
    brandId: {
      label: "Brand",
      render: (_, row) => capitalize(row.brandId?.name),
    },

    name: {
      label: "Model Name",
      render: (value) => capitalize(value),
    },
    storages: {
      label: "Storages & Base Price",
      render: (value) => {
        if (!value?.length) return "--";

        return (
          <div className="flex flex-col items-center gap-1">
            {value.map((row) => (
              <span
                key={row._id}
                className="whitespace-nowrap rounded-md bg-gray-100 px-2 py-0.5 text-xs text-gray-700"
              >
                {storageLabel(row.storageId)} — {formatPrice(row.basePrice)}
              </span>
            ))}
          </div>
        );
      },
    },

    logo: {
      label: "Logo",
      render: (value) =>
        value ? (
          <a href={value} target="_blank" rel="noreferrer">
            <img
              src={value}
              alt="logo"
              className="w-12 h-12 rounded-md border object-contain mx-auto"
            />
          </a>
        ) : (
          "--"
        ),
    },
    slug: {
      label: "Slug",
    },

    createdAt: {
      label: "Created At",
      render: (value) => (value ? new Date(value).toLocaleDateString() : "--"),
    },

    action: {
      label: "Action",
      render: (_, row) => (
        <div className="flex items-center justify-center gap-2">
          <button
            title="Edit"
            onClick={() =>
              navigate(`/device-management/models/update/${row._id}`)
            }
            className="w-9 h-9 rounded-lg border border-blue-200 bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white flex items-center justify-center"
          >
            <Pencil size={17} />
          </button>

          <button
            title="Delete"
            onClick={() => handleDelete(row._id)}
            className="w-9 h-9 rounded-lg border border-red-200 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white flex items-center justify-center"
          >
            <Trash2 size={17} />
          </button>
        </div>
      ),
    },
  };

  return (
    <div>
      <PageHeader title="Models Management" path="add" btnTitle="Add Model" />

      <div className="flex justify-end mt-2 mb-2">
        <Link
          to="/device-management/models/upload"
          className="inline-flex items-center gap-2 rounded-lg border border-green-200 bg-green-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-green-700"
        >
          Upload Excel
        </Link>
      </div>

      <div className="mt-2">
        <Table
          data={modelList}
          columnConfig={columnConfig}
          paginationMode="server"
          totalRecords={totalRecords}
          page={page}
          pageSize={limit}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
          loading={isLoading}
          searchValue={search}
          onSearch={onSearchChange}
        />
      </div>
    </div>
  );
};

export default ModelPage;
