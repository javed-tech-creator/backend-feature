import React, { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import PageHeader from "../../components/PageHeader";
import Loader from "../../components/Loader";
import {
  useGetOrderByIdQuery,
  useUpdateOrderStatusMutation,
} from "../../api/order.api";

const ORDER_STATUSES = [
  "requested",
  "confirmed",
  "accepted",
  "rejected",
  "completed",
  "cancelled",
];

const formatStatus = (value) =>
  value ? value.charAt(0).toUpperCase() + value.slice(1) : "--";

const getOrder = (response) =>
  response?.data?.data || response?.data || response;

const OrderDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data, isLoading, isError, error } = useGetOrderByIdQuery(
    { id },
    { skip: !id },
  );
  const [updateOrderStatus, { isLoading: isUpdating }] =
    useUpdateOrderStatusMutation();
  const order = getOrder(data);
  const [status, setStatus] = useState("");

  useEffect(() => {
    if (order?.status) setStatus(order.status);
  }, [order?.status]);

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      await updateOrderStatus({ id, status }).unwrap();
      toast.success("Order status updated successfully");
      navigate("/orders");
    } catch (updateError) {
      toast.error(
        updateError?.data?.message || "Failed to update order status",
      );
    }
  };

  if (isLoading) return <Loader />;

  if (isError) {
    return (
      <>
        <PageHeader title="Update Order Status" />
        <div className="py-20 text-center text-sm text-red-600">
          {error?.data?.message || error?.message || "Failed to load order"}
        </div>
      </>
    );
  }

  return (
    <div>
      <PageHeader title="Update Order Status" />
      <div className="mx-auto max-w-xl rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
        <button
          type="button"
          onClick={() => navigate("/orders")}
          className="mb-6 inline-flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900"
        >
          Back to orders
        </button>

        <div className="mb-6">
          <p className="text-xs uppercase tracking-wide text-gray-500">
            Order ID
          </p>
          <p className="mt-1 break-all font-medium text-gray-900">
            {order?._id || order?.id || id}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label
              htmlFor="order-status"
              className="mb-2 block text-sm font-medium text-gray-700"
            >
              Status
            </label>
            <select
              id="order-status"
              value={status}
              onChange={(event) => setStatus(event.target.value)}
              className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm outline-none focus:border-primary"
              required
            >
              <option value="" disabled>
                Select status
              </option>
              {ORDER_STATUSES.map((option) => (
                <option key={option} value={option}>
                  {formatStatus(option)}
                </option>
              ))}
            </select>
          </div>

          <button
            type="submit"
            disabled={isUpdating || !status}
            className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-white disabled:cursor-not-allowed disabled:opacity-60"
          >
            {isUpdating ? <Loader2 size={16} className="animate-spin" /> : null}
            {isUpdating ? "Updating..." : "Update Status"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default OrderDetails;
