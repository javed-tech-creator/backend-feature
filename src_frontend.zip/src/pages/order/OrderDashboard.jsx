import React from "react";
import { ChevronDown, ExternalLink, Loader2, X } from "lucide-react";
import { toast } from "react-toastify";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";
import {
  useGetAllOrdersQuery,
  useUploadOrderDocumentsMutation,
  useUpdateOrderStatusMutation,
} from "../../api/order.api";
import { usePagination, extractPaginatedData } from "../../lib/usePagination";

const display = (value) => value || "--";
const formatDateTime = (value) => {
  if (!value) return "--";

  const date = new Date(value);
  const dateLabel = `${date.getDate()} ${date.toLocaleString("en-US", {
    month: "short",
  })} ${date.getFullYear()}`;
  const timeLabel = date.toLocaleString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

  return (
    <div className="text-center whitespace-nowrap">
      <div>{dateLabel}</div>
      <div className="text-xs text-gray-500">{timeLabel}</div>
    </div>
  );
};
const formatPrice = (value) =>
  value == null ? "--" : Number(value).toLocaleString();
const compactOrderId = (value) => {
  if (!value) return "--";

  const orderId = String(value);
  if (orderId.length <= 14) return orderId;

  return `${orderId.slice(0, 6)}...${orderId.slice(-6)}`;
};

const ORDER_STATUS_STYLES = {
  requested: "bg-amber-100 text-amber-700 border-amber-200",
  confirmed: "bg-blue-100 text-blue-700 border-blue-200",
  accepted: "bg-cyan-100 text-cyan-700 border-cyan-200",
  rejected: "bg-red-100 text-red-700 border-red-200",
  completed: "bg-emerald-100 text-emerald-700 border-emerald-200",
  cancelled: "bg-rose-100 text-rose-700 border-rose-200",
};

const ORDER_STATUSES = Object.keys(ORDER_STATUS_STYLES);

const formatStatus = (value) => {
  if (!value) return "--";

  return String(value)
    .toLowerCase()
    .replace(/\b\w/g, (character) => character.toUpperCase());
};

const getUser = (row) =>
  row?.userId && typeof row.userId === "object" ? row.userId : row;
const getModel = (row) => row?.modelId;
const getStorage = (row) => row?.storageId;
const getAddress = (row) =>
  row?.OrderAddress ||
  row?.orderAddress ||
  row?.address ||
  row?.orderAddressId ||
  {};
const getDocumentUrl = (document) => {
  if (!document) return "";
  if (typeof document === "string") return document;

  return document.url || document.secure_url || document.fileUrl || "";
};

const SelectedFilePreview = ({ file, field }) => {
  const [previewUrl, setPreviewUrl] = React.useState("");
  const isImage = file?.type?.startsWith("image/");

  React.useEffect(() => {
    if (!file || !isImage) {
      setPreviewUrl("");
      return undefined;
    }

    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);

    return () => URL.revokeObjectURL(objectUrl);
  }, [file, isImage]);

  if (!file) return null;

  return (
    <div className="mt-3 flex items-center gap-3">
      {isImage ? (
        <img
          src={previewUrl}
          alt={`${field} preview`}
          className="h-16 w-16 rounded border border-gray-200 object-cover"
        />
      ) : (
        <div className="flex h-16 w-16 items-center justify-center rounded border border-gray-200 bg-gray-50 text-xs font-medium text-gray-500">
          PDF
        </div>
      )}
      <div className="min-w-0 flex-1">
        <p className="truncate text-xs text-gray-700">{file.name}</p>
        <p className="text-[11px] text-gray-500">
          {(file.size / 1024 / 1024).toFixed(2)} MB
        </p>
      </div>
    </div>
  );
};

const OrderDashboard = () => {
  const {
    page,
    limit,
    search,
    params,
    onPageChange,
    onPageSizeChange,
    onSearchChange,
  } = usePagination({ initialLimit: 10 });
  const { data, isLoading, isError, error } = useGetAllOrdersQuery(params);
  const [updateOrderStatus, { isLoading: isUpdatingStatus }] =
    useUpdateOrderStatusMutation();
  const [uploadOrderDocuments, { isLoading: isUploadingDocuments }] =
    useUploadOrderDocumentsMutation();
  const [documentFiles, setDocumentFiles] = React.useState({});
  const [documentModalOrderId, setDocumentModalOrderId] = React.useState(null);
  const { rows, totalRecords } = extractPaginatedData(data, {
    clientPage: page,
    clientLimit: limit,
    clientSearch: search,
  });

  const handleDocumentFileChange = (orderId, field, file) => {
    setDocumentFiles((currentFiles) => ({
      ...currentFiles,
      [orderId]: {
        ...currentFiles[orderId],
        [field]: file,
      },
    }));
  };

  const handleDocumentUpload = async (orderId, event) => {
    event.preventDefault();
    const files = documentFiles[orderId] || {};

    if (!files.aadhaar && !files.imei) {
      toast.error("Select at least one document to upload");
      return;
    }

    const formData = new FormData();
    if (files.aadhaar) formData.append("aadhaar", files.aadhaar);
    if (files.imei) formData.append("imei", files.imei);

    try {
      await uploadOrderDocuments({ orderId, formData }).unwrap();
      toast.success("Order documents uploaded successfully");
      setDocumentFiles((currentFiles) => {
        const nextFiles = { ...currentFiles };
        delete nextFiles[orderId];
        return nextFiles;
      });
      setDocumentModalOrderId(null);
    } catch (uploadError) {
      toast.error(
        uploadError?.data?.message || "Failed to upload order documents",
      );
    }
  };
  const columnConfig = {
    orderId: {
      label: "Order ID",
      render: (value, row) => {
        const orderNumber = row?.orderNumber;
        const displayValue = orderNumber || value;

        return (
          <span title={displayValue || "Order ID"}>
            {orderNumber || compactOrderId(displayValue)}
          </span>
        );
      },
    },
    user: {
      label: "User",
      render: (_, row) => {
        const user = getUser(row);
        return (
          <div>
            <div>{display(user.fullName)}</div>
            <div className="text-xs text-gray-500">{display(user.email)}</div>
            <div className="text-xs text-gray-500">{display(user.phone)}</div>
          </div>
        );
      },
    },
    modelId: {
      label: "Model",
      render: (_, row) => {
        const model = getModel(row);
        if (!model || typeof model !== "object") {
          return (
            <span className="whitespace-normal wrap-break-word">
              {display(model)}
            </span>
          );
        }

        return (
          <div className="flex w-48 min-w-0 items-center gap-2 text-left">
            {model.logo ? (
              <img
                src={model.logo}
                alt={model.name || "Model"}
                className="h-10 w-10 rounded border border-gray-200 object-contain"
              />
            ) : null}
            <div className="min-w-0 whitespace-normal wrap-break-word">
              <div className="font-medium whitespace-normal wrap-break-word">
                {display(model.name)}
              </div>
              <div className="text-xs text-gray-500 whitespace-normal wrap-break-word">
                {display(model.brandId?.name)}
                {model.deviceId?.name || model.brandId?.deviceId?.name
                  ? ` / ${model.deviceId?.name || model.brandId?.deviceId?.name}`
                  : ""}
              </div>
            </div>
          </div>
        );
      },
    },
    storageId: {
      label: "Storage",
      render: (_, row) => {
        const storage = getStorage(row);
        return display(
          typeof storage === "object"
            ? [storage.ram, storage.rom].filter(Boolean).join(" / ")
            : storage,
        );
      },
    },
    basePrice: { label: "Base Price", render: formatPrice },
    finalPrice: { label: "Final Price", render: formatPrice },
    status: {
      label: "Status",
      render: (value, row) => {
        if (!value) return "--";

        const status = String(value).toLowerCase();
        const statusStyle =
          ORDER_STATUS_STYLES[status] ||
          "bg-gray-100 text-gray-600 border-gray-200";
        const orderId = row?._id || row?.id || row?.orderId;

        const handleStatusChange = async (event) => {
          const nextStatus = event.target.value;
          if (!orderId || nextStatus === status) return;

          try {
            await updateOrderStatus({
              id: orderId,
              status: nextStatus,
              queryParams: params,
            }).unwrap();
            toast.success("Order status updated successfully");
          } catch (updateError) {
            toast.error(
              updateError?.data?.message || "Failed to update order status",
            );
          }
        };

        return (
          <div className="relative inline-flex items-center">
            <select
              value={status}
              onChange={handleStatusChange}
              disabled={!orderId || isUpdatingStatus}
              title="Change order status"
              aria-label="Change order status"
              className={`min-w-28 cursor-pointer appearance-none rounded-full border py-1 pl-3 pr-8 text-left text-xs font-simeibold shadow-sm outline-none transition hover:shadow-md focus:ring-2 focus:ring-black/10 ${statusStyle} disabled:cursor-not-allowed disabled:opacity-60`}
            >
              {[
                ...(!ORDER_STATUSES.includes(status) ? [status] : []),
                ...ORDER_STATUSES,
              ].map((option) => (
                <option
                  key={option}
                  value={option}
                  className="bg-white text-gray-700"
                >
                  {formatStatus(option)}
                </option>
              ))}
            </select>
            <ChevronDown
              size={14}
              strokeWidth={2.5}
              className="pointer-events-none absolute right-2.5 text-black/50"
              aria-hidden="true"
            />
          </div>
        );
      },
    },
    location: {
      label: "Location",
      render: (_, row) => (
        <div className="text-center whitespace-nowrap">
          <div>{display(row.city)}</div>
          <div className="text-xs text-gray-500">{display(row.state)}</div>
        </div>
      ),
    },
    address: {
      label: "Order Address",
      render: (_, row) => {
        const address = getAddress(row);
        return (
          <div>
            <div>{display(address.address1)}</div>
            <div>{display(address.address2)}</div>
            <div className="text-xs text-gray-500">
              {[address.city, address.state, address.pincode]
                .filter(Boolean)
                .join(", ") || "--"}
            </div>
          </div>
        );
      },
    },
    documents: {
      label: "Documents",
      render: (_, row) => {
        const orderId = row?._id || row?.id || row?.orderId;
        const document = row?.document || row?.documents;
        const files = documentFiles[orderId] || {};
        const isCompleted =
          String(row?.status || "").toLowerCase() === "completed";
        const aadhaarUrl = getDocumentUrl(document?.aadhaar);
        const imeiUrl = getDocumentUrl(document?.imei);
        const hasUploadedDocuments = aadhaarUrl || imeiUrl;

        return (
          <div className="min-w-40 space-y-2 text-center whitespace-normal">
            <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs justify-center">
              {[
                ["Aadhaar", aadhaarUrl],
                ["IMEI", imeiUrl],
              ].map(([label, value]) => {
                return value ? (
                  <a
                    key={label}
                    href={value}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 font-medium text-primary hover:underline"
                  >
                    {label}
                    <ExternalLink size={12} aria-hidden="true" />
                  </a>
                ) : null;
              })}
              {!hasUploadedDocuments && !isCompleted ? (
                <span className="text-gray-500">No documents</span>
              ) : null}
            </div>

            {isCompleted && orderId && !hasUploadedDocuments ? (
                <button
                  type="button"
                  onClick={() => setDocumentModalOrderId(orderId)}
                  className="inline-flex items-center gap-1 rounded-md bg-primary px-2.5 py-1 text-xs font-medium text-white"
                >
                  Upload
                </button>
            ) : null}
          </div>
        );
      },
    },
    createdAt: { label: "Created At", render: formatDateTime },
  };

  if (isError) {
    return (
      <>
        <PageHeader title="Orders" />
        <div className="py-20 text-center text-sm text-red-600">
          {error?.data?.message || error?.message || "Failed to load orders"}
        </div>
      </>
    );
  }

  return (
    <div>
      <PageHeader title="Orders" />
      <Table
        data={rows}
        columnConfig={columnConfig}
        paginationMode="server"
        totalRecords={totalRecords}
        page={page}
        pageSize={limit}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
        loading={isLoading}
        searchValue={search}
        onSearch={onSearchChange}
      />

      {documentModalOrderId ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-lg rounded-xl bg-white p-5 shadow-xl">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-simeibold text-gray-900">
                  Upload order documents
                </h2>
                <p className="mt-1 text-xs text-gray-500">
                  Select Aadhaar, EMI, or both documents.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setDocumentModalOrderId(null)}
                className="rounded-md p-1 text-gray-500 hover:bg-gray-100 hover:text-gray-900"
                aria-label="Close upload modal"
              >
                <X size={18} />
              </button>
            </div>

            <form
              onSubmit={(event) =>
                handleDocumentUpload(documentModalOrderId, event)
              }
              className="space-y-4"
            >
              {["aadhaar", "imei"].map((field) => {
                const file = documentFiles[documentModalOrderId]?.[field];
                const label = field === "imei" ? "IMEI" : "Aadhaar";

                return (
                  <div
                    key={field}
                    className="rounded-lg border border-gray-200 p-3"
                  >
                    <label className="block text-sm font-medium text-gray-700">
                      {label}
                      <input
                        type="file"
                        accept="image/*,.pdf"
                        onChange={(event) =>
                          handleDocumentFileChange(
                            documentModalOrderId,
                            field,
                            event.target.files?.[0] || null,
                          )
                        }
                        className="mt-2 block w-full text-xs text-gray-600 file:mr-3 file:rounded-md file:border-0 file:bg-gray-100 file:px-3 file:py-2 file:text-xs file:font-medium file:text-gray-700"
                      />
                    </label>
                    {file ? (
                      <>
                        <SelectedFilePreview file={file} field={field} />
                        <button
                          type="button"
                          onClick={() =>
                            handleDocumentFileChange(
                              documentModalOrderId,
                              field,
                              null,
                            )
                          }
                          className="text-xs text-red-600 hover:underline"
                        >
                          Remove
                        </button>
                      </>
                    ) : null}
                  </div>
                );
              })}

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setDocumentModalOrderId(null)}
                  className="rounded-md border border-gray-300 px-3 py-2 text-sm text-gray-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUploadingDocuments}
                  className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-white disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {isUploadingDocuments ? (
                    <Loader2 size={15} className="animate-spin" />
                  ) : null}
                  {isUploadingDocuments ? "Uploading..." : "Upload documents"}
                </button>
              </div>
            </form>
          </div>
        </div>
      ) : null}
    </div>
  );
};

export default OrderDashboard;
