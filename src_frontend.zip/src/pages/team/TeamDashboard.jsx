import React from "react";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";
import {
  useDeleteTeamMutation,
  useGetAllTeamQuery,
} from "../../api/team.api";
import { SquarePen, Trash } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import ReadMore from "../blog/ReadMore";
import { usePagination, extractPaginatedData } from "../../lib/usePagination";

function TeamDashboard() {
  const backendUrl = import.meta.env.VITE_BACKEND;
  const navigate = useNavigate();
  const { page, limit, search, params, onPageChange, onPageSizeChange, onSearchChange } =
    usePagination({ initialLimit: 10 });
  const { data, isLoading, isError, error } = useGetAllTeamQuery(params);
  const [deleteTeam] = useDeleteTeamMutation();

  const { rows, totalRecords } = extractPaginatedData(data, {
    clientPage: page,
    clientLimit: limit,
    clientSearch: search,
  });

  const handleDelete = (item) => {
    const id = item?._id;
    toast(
      ({ closeToast }) => (
        <div>
          <p className="mb-2">Are you sure you want to delete?</p>
          <div className="flex gap-2">
            <button
              onClick={async () => {
                try {
                  await deleteTeam({ id }).unwrap();
                  toast.success("Team member deleted successfully");
                } catch (err) {
                  toast.error("Failed to delete member");
                }
                closeToast();
              }}
              className="px-3 py-1 bg-red-500 text-white rounded text-xs"
            >
              Yes
            </button>
            <button
              onClick={closeToast}
              className="px-3 py-1 bg-gray-300 text-xs rounded"
            >
              No
            </button>
          </div>
        </div>
      ),
      { autoClose: false, closeOnClick: false, draggable: false }
    );
  };

  const handleEdit = (item) => {
    navigate(`update/${item?._id}`);
  };

  const teamColumnConfig = {
    actions: {
      label: "Actions",
      render: (val, row) => (
        <div className="flex justify-center gap-3">
          <button
            onClick={() => handleEdit(row)}
            className="text-orange-500 cursor-pointer"
            title="Edit"
          >
            <SquarePen size={20} />
          </button>
          <button
            onClick={() => handleDelete(row)}
            className="text-orange-500 cursor-pointer"
            title="Delete"
          >
            <Trash size={20} />
          </button>
        </div>
      ),
    },
    name: { label: "Name" },
    designation: { label: "Designation" },
    // department: { label: "Department" },
    description: {
      label: "Description",
      render: (val) => <ReadMore html={val} />,
    },
    image: {
      label: "Image",
      render: (val) => (
        <img
          src={val?.public_url || `${backendUrl}/${val?.url}`}
          alt="team"
          className="h-10 w-10 object-cover rounded"
          onClick={() =>
            window.open(
              val?.public_url || `${backendUrl}/${val?.url}`,
              "_blank"
            )
          }
        />
      ),
    },
    createdAt: {
      label: "Created At",
      render: (val) => new Date(val).toLocaleString(),
    },
  };

  if (isError) {
    return (
      <>
        <PageHeader
          title="Team Dashboard"
          path="add"
          btnTitle="Add New Member"
        />
        <div className="text-red-600 text-sm py-20 text-center">
          {error?.data?.message || error?.message}
        </div>
      </>
    );
  }
  return (
    <div>
      <PageHeader title="Team Dashboard" path="add" btnTitle="Add New Member" />
      <Table
        data={rows}
        columnConfig={teamColumnConfig}
        paginationMode="server"
        totalRecords={totalRecords}
        page={page}
        pageSize={limit}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
        loading={isLoading}
        searchValue={search}
        onSearch={onSearchChange}
      />
    </div>
  );
}

export default TeamDashboard;
