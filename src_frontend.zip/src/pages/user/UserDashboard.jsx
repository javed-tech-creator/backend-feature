import React from "react";
import PageHeader from "../../components/PageHeader";
import Table from "../../components/Table";
import { useGetAllUsersQuery } from "../../api/user.api";
import { usePagination, extractPaginatedData } from "../../lib/usePagination";

const formatDateTime = (value) => {
  if (!value) return "--";

  const date = new Date(value);
  const dateLabel = `${date.getDate()} ${date.toLocaleString("en-US", {
    month: "short",
  })} ${date.getFullYear()}`;
  const timeLabel = date.toLocaleString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

  return (
    <div className="text-center whitespace-nowrap">
      <div>{dateLabel}</div>
      <div className="text-xs text-gray-500">{timeLabel}</div>
    </div>
  );
};

const UserDashboard = () => {
  const {
    page,
    limit,
    search,
    params,
    onPageChange,
    onPageSizeChange,
    onSearchChange,
  } = usePagination({ initialLimit: 10 });
  const { data, isLoading, isError, error } = useGetAllUsersQuery(params);
  const { rows, totalRecords } = extractPaginatedData(data, {
    clientPage: page,
    clientLimit: limit,
    clientSearch: search,
  });

  const columnConfig = {
    fullName: { label: "Full Name" },
    email: { label: "Email" },
    phone: { label: "Phone" },
    isVerified: {
      label: "Verified",
      render: (value) => (
        <span
          className={`mx-auto block h-3 w-3 rounded-full ${
            value ? "bg-green-500" : "bg-red-500"
          }`}
          title={value ? "Verified" : "Not verified"}
          aria-label={value ? "Verified" : "Not verified"}
        />
      ),
    },
    createdAt: {
      label: "Created At",
      render: formatDateTime,
    },
    updatedAt: {
      label: "Updated At",
      render: formatDateTime,
    },
  };

  if (isError) {
    return (
      <>
        <PageHeader title="Registered Users" />
        <div className="py-20 text-center text-sm text-red-600">
          {error?.data?.message || error?.message || "Failed to load users"}
        </div>
      </>
    );
  }

  return (
    <div>
      <PageHeader title="Registered Users" />
      <Table
        data={rows}
        columnConfig={columnConfig}
        paginationMode="server"
        totalRecords={totalRecords}
        page={page}
        pageSize={limit}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
        loading={isLoading}
        searchValue={search}
        onSearch={onSearchChange}
      />
    </div>
  );
};

export default UserDashboard;
