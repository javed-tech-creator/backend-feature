import { Schema, model } from 'mongoose';

const orderCounterSchema = new Schema(
  {
    key: { type: String, required: true, unique: true },
    sequence: { type: Number, required: true, default: 0 },
  },
  { versionKey: false },
);

export const OrderCounter = model('OrderCounter', orderCounterSchema);