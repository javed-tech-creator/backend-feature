import { model, Schema } from "mongoose";
import { baseSchemaOptions } from "./base.model";

const documentSchema = new Schema(
  {
    userId: {
      type: Schema.Types.ObjectId,
      required: true,
      ref: "User",
      index: true,
    },

    orderId: {
      type: Schema.Types.ObjectId,
      required: true,
      ref: "Order",
      index: true,
    },

    aadhaar: {
      publicId: {
        type: String,
        required: true,
      },
      url: {
        type: String,
        required: true,
      },
    },

    imei: {
      publicId: {
        type: String,
        required: true,
      },
      url: {
        type: String,
        required: true,
      },
    },

    isDeleted: {
      type: Boolean,
      default: false,
    },
  },
  baseSchemaOptions,
);

documentSchema.index(
  { orderId: 1 },
  {
    unique: true,
    partialFilterExpression: {
      isDeleted: false,
    },
  },
);

export const Document = model("Document", documentSchema);