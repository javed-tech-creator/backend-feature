import mongoose from 'mongoose';
import { OrderStatus, OrderType, UserRole } from '../../lib/enum';
import { OrderAddress } from '../../model/order-address.model';
import { Order } from '../../model/order.model';
import { OrderCounter } from '../../model/order-counter.model';
import { UserAnswer } from '../../model/user-answer.model';
import { ApiError } from '../../utils/api-error';
import { buildMeta, toSkipTake } from '../../utils/pagination';
import { findLiveById } from '../../utils/query';
import {
  OrderAddressCreateDto,
  OrderCreateDto,
  OrderListQuery,
  OrderStatusUpdateDto,
} from './dto/index.dto';
import { IOrder } from '../../types/types';

const LABEL = 'Order';

interface RequestUser {
  id: string;
  role: UserRole;
}

/** Customers only ever reach their own orders; admins reach every order. */
const assertVisible = (orderUserId: string, user: RequestUser) => {
  if (user.role !== UserRole.ADMIN && orderUserId !== user.id) {
    throw ApiError.forbidden();
  }
};

export class OrderService {
  static async create(
    userId: string,
    { state, city, modelId, storageId, basePrice, finalPrice, orderType, answers }: OrderCreateDto,
  ) {
    const session = await mongoose.startSession();

    try {
      session.startTransaction();

      const existingOrder = await Order.findOne({
        userId,
        modelId,
        orderType: OrderType.SELL,
        status: OrderStatus.REQUESTED,
        isDeleted: false,
      }).session(session);

      let order: IOrder;

      if (existingOrder) {
        // Update existing REQUESTED order
        existingOrder.state = state;
        existingOrder.city = city;
        existingOrder.basePrice = basePrice;
        existingOrder.finalPrice = finalPrice;
        existingOrder.storageId = new mongoose.Types.ObjectId(storageId);

        order = await existingOrder.save({ session });

        // Soft delete previous answers
        await UserAnswer.updateMany(
          {
            orderId: order._id,
            isDeleted: false,
          },
          {
            $set: {
              isDeleted: true,
            },
          },
          { session },
        );

        // Add updated answers
        if (answers?.length) {
          await UserAnswer.insertMany(
            answers.map((answer) => ({
              ...answer,
              orderId: order._id,
            })),
            { session },
          );
        }
      } else {
        const counter = await OrderCounter.findOneAndUpdate(
          { key: 'ORDSELL' },
          { $inc: { sequence: 1 } },
          { new: true, upsert: true, session },
        );
        const orderNumber = `ORDSELL${String(counter.sequence).padStart(3, '0')}`;

        const [newOrder] = await Order.create(
          [
            {
              orderNumber,
              userId,
              state,
              city,
              modelId,
              storageId,
              orderType: OrderType.SELL,
              basePrice,
              finalPrice,
            },
          ],
          { session },
        );

        order = newOrder;

        if (answers?.length) {
          await UserAnswer.insertMany(
            answers.map((answer) => ({
              ...answer,
              orderId: order._id,
            })),
            { session },
          );
        }
      }

      await session.commitTransaction();

      return order;
    } catch (error) {
      await session.abortTransaction();
      throw error;
    } finally {
      await session.endSession();
    }
  }

  private static async findMany(query: OrderListQuery, userId?: string) {
    const { skip, take } = toSkipTake(query);
    const filter = {
      isDeleted: false,
      ...(userId ? { userId } : {}),
      ...(query.status ? { status: query.status } : {}),
      ...(query.orderType ? { orderType: query.orderType } : {}),
      ...(query.modelId ? { modelId: query.modelId } : {}),
    };

    const [orders, total] = await Promise.all([
      Order.find(filter)
        .populate('modelId', 'name slug')
        .populate('storageId', 'ram rom slug')
        .sort({ [query.sortBy]: query.order === 'asc' ? 1 : -1 })
        .skip(skip)
        .limit(take),
      Order.countDocuments(filter),
    ]);

    return { orders, meta: buildMeta(query, total) };
  }

  static async list(query: OrderListQuery, user: RequestUser) {
    // Only an admin may filter by userId; a customer is pinned to their own orders.
    const userId = user.role === UserRole.ADMIN ? query.userId : user.id;

    return OrderService.findMany(query, userId);
  }

  /** The caller's own orders, whatever their role. */
  static async listMine(query: OrderListQuery, userId: string) {
    return OrderService.findMany(query, userId);
  }

  static async getById(id: string, user: RequestUser) {
    const order = await findLiveById(Order, id, LABEL);
    assertVisible(order.userId.toString(), user);

    const answers = await UserAnswer.find({ orderId: order._id, isDeleted: false });

    return { ...order.toObject(), answers };
  }

  static async updateStatus(id: string, { status }: OrderStatusUpdateDto) {
    const order = await findLiveById(Order, id, LABEL);
    order.status = status;

    return order.save();
  }

  static async confirmWithAddress(
    id: string,
    user: RequestUser,
    addressData: OrderAddressCreateDto,
  ) {
    const session = await mongoose.startSession();

    try {
      session.startTransaction();

      const order = await Order.findOne({ _id: id, userId: user.id, isDeleted: false }).session(
        session,
      );
      if (!order) {
        throw ApiError.notFound(`${LABEL} not found`);
      }
      assertVisible(order.userId.toString(), user);

      order.status = OrderStatus.CONFIRMED;
      await order.save({ session });

      const [address] = await OrderAddress.create(
        [
          {
            orderId: order._id,
            address1: addressData.addressLine1,
            address2: addressData.addressLine2,
            state: addressData.state,
            city: addressData.city,
            pincode: addressData.pinCode,
          },
        ],
        { session },
      );

      await session.commitTransaction();
      return { order, address };
    } catch (error) {
      await session.abortTransaction();
      throw error;
    } finally {
      await session.endSession();
    }
  }

  static async remove(id: string, user: RequestUser) {
    const order = await findLiveById(Order, id, LABEL);
    assertVisible(order.userId.toString(), user);

    order.isDeleted = true;
    await order.save();
  }
}
