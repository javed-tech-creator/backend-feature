import { Router } from 'express';
import { authenticate } from '../../middlewares/authenticate';
import { validate } from '../../middlewares/validate';
import { idParamSchema } from '../../utils/object-id';
import { OrderController } from './order.controller';
import { orderAddressCreateSchema, orderCreateSchema } from './dto/index.dto';

const router = Router();

router.use(authenticate);

router.post('/', validate({ body: orderCreateSchema }), OrderController.create);

router.get('/', OrderController.list);
// Must stay above '/:id', otherwise 'my' is read as an order id.
router.get('/my', OrderController.listMine);
router.get('/:id', validate({ params: idParamSchema }), OrderController.getById);

router.patch('/:id/address',
   validate({ params: idParamSchema, body: orderAddressCreateSchema }),
    OrderController.addAddress
  );

router.delete('/:id', validate({ params: idParamSchema }), OrderController.remove);

export default router;
