import { Request, Response } from 'express';
import { UserRole } from '../../lib/enum';
import { User } from '../../model/user.model';
import { ResponseHandler } from '../../helper/response.handler';
// import { ApiError } from '../../utils/api-error';
import { UserCheckPhoneDto } from './dto/check.phone';
import { UserSendOtpDto } from './dto/send.otp';
import { generateOTP } from '../../helper/generate-otp.helper';
import { env } from '../../config/env';
import { sendOtpSms } from '../../helper/send-otp.helper';
import { compareOtp, hashOtp } from '../../helper/hash-otp.helper';
import { UserVerifyOtpDto } from './dto/user.login';
import { generateAccessToken } from '../../helper/generate-token.helper';
import { UserUpdateProfileDto } from './dto/update.profile';

export class UserController {
  static async checkPhone(req: Request, res: Response): Promise<void> {
    try {
      const { phone } = req.body as UserCheckPhoneDto;

      const user = await User.findOne({
        phone,
        isDeleted: false,
      });

      ResponseHandler.success(res, 'Phone number checked successfully.', {
        exists: !!user,
        isNewUser: !user,
      });
    } catch (error) {
      ResponseHandler.error(res, 'Something went wrong while checking phone number.', 500, {
        error: error instanceof Error ? error : undefined,
        context: {
          controller: 'checkPhone',
          method: req.method,
          path: req.path,
        },
      });
    }
  }
  static async sendOtp(req: Request, res: Response): Promise<void> {
    try {
      const { phone, fullName, email } = req.body as UserSendOtpDto;

      const existingUser = await User.findOne({
        phone,
        isDeleted: false,
      });

      // New user
      if (!existingUser) {
        if (!fullName) {
          ResponseHandler.error(res, 'Full name is required for new users.', 400);
          return;
        }

        const otp = generateOTP();
        const otpHash = hashOtp(otp);
        const expiry = new Date(Date.now() + env.otp.expiryMinutes * 60 * 1000);

        // console.log(`Generated OTP for ${phone}: ${otp}`); // Log the OTP for testing purposes
        // Send OTP through Renflair
        await sendOtpSms(phone, otp);

        await User.create({
          phone,
          fullName: fullName.trim(),

          ...(email?.trim() ? { email: email.trim() } : {}),

          role: UserRole.CUSTOMER,
          otp: otpHash,
          otpExpiresAt: expiry,
          otpAttempts: 0,
          isVerified: false,
        });

        ResponseHandler.success(res, 'OTP sent successfully.', {
          isNewUser: true,
        });

        return;
      }

      // Existing user
      const otp = generateOTP();
      const otpHash = hashOtp(otp);

      const expiry = new Date(Date.now() + env.otp.expiryMinutes * 60 * 1000);

      // console.log(`Generated OTP for ${phone}: ${otp}`); // Log the OTP for testing purposes
      // Send OTP through Renflair
      await sendOtpSms(phone, otp);

      // ATOMIC UPDATE
      await User.updateOne(
        { _id: existingUser._id },
        {
          $set: {
            otp: otpHash,
            otpExpiresAt: expiry,
            otpAttempts: 0,
          },
        },
      );

      ResponseHandler.success(res, 'OTP sent successfully.', {
        isNewUser: false,
      });
    } catch (error) {
      ResponseHandler.error(res, 'Something went wrong while sending OTP.', 500, {
        error: error instanceof Error ? error : undefined,
        context: {
          controller: 'sendOtp',
          method: req.method,
          path: req.path,
        },
      });
    }
  }
  static async verifyOtp(req: Request, res: Response): Promise<void> {
    try {
      const { phone, otp } = req.body as UserVerifyOtpDto;

      const user = await User.findOne({
        phone,
        isDeleted: false,
      });

      if (!user) {
        ResponseHandler.error(res, 'User not found.', 404);
        return;
      }

      // OTP doesn't exist
      if (!user.otp || !user.otpExpiresAt) {
        ResponseHandler.error(res, 'OTP not found. Please request a new OTP.', 400);
        return;
      }

      // Maximum OTP attempts
      if (user.otpAttempts >= 5) {
        user.otp = null;
        user.otpExpiresAt = null;
        user.otpAttempts = 0;

        await user.save();

        ResponseHandler.error(res, 'Too many incorrect attempts. Please request a new OTP.', 429);
        return;
      }

      // OTP expiry check
      if (new Date() > user.otpExpiresAt) {
        user.otp = null;
        user.otpExpiresAt = null;
        user.otpAttempts = 0;

        await user.save();

        ResponseHandler.error(res, 'OTP has expired. Please request a new OTP.', 400);
        return;
      }

      // Compare OTP hash
      const isValidOtp = compareOtp(otp, user.otp);

      if (!isValidOtp) {
        const updatedUser = await User.findOneAndUpdate(
          { _id: user._id },
          {
            $inc: {
              otpAttempts: 1,
            },
          },
          {
            new: true,
            projection: {
              otpAttempts: 1,
            },
          },
        );

        const remainingAttempts = Math.max(0, 5 - (updatedUser?.otpAttempts ?? 0));

        ResponseHandler.error(res, `Invalid OTP. ${remainingAttempts} attempts remaining.`, 400);
        return;
      }

      const verifiedUser = await User.findOneAndUpdate(
        {
          _id: user._id,
          otp: user.otp,
          otpExpiresAt: { $gt: new Date() },
        },
        {
          $set: {
            otp: null,
            otpExpiresAt: null,
            otpAttempts: 0,
            isVerified: true,
          },
        },
        {
          new: true,
        },
      );

      if (!verifiedUser) {
        ResponseHandler.error(res, 'OTP has already been used or expired.', 400);
        return;
      }

      // Generate JWT here
      const token = generateAccessToken({
        userId: verifiedUser._id.toString(),
        phone: verifiedUser.phone,
      });

      ResponseHandler.success(res, 'OTP verified successfully.', {
        token,
        user: {
          phone: verifiedUser.phone,
          fullName: verifiedUser.fullName,
        },
      });
    } catch (error) {
      ResponseHandler.error(res, 'Something went wrong while verifying OTP.', 500, {
        error: error instanceof Error ? error : undefined,
        context: {
          controller: 'verifyOtp',
          method: req.method,
          path: req.path,
        },
      });
    }
  }

  static async updateProfile(req: Request, res: Response): Promise<void> {
    try {
      const { fullName, email } = req.body as UserUpdateProfileDto;
      const userId = req.user!.id;

      if (email) {
        const existingUser = await User.findOne({
          email,
          _id: { $ne: userId },
          isDeleted: false,
        });

        if (existingUser) {
          ResponseHandler.error(res, 'Email is already in use.', 409);
          return;
        }
      }

      const updatedUser = await User.findOneAndUpdate(
        { _id: userId, isDeleted: false },
        {
          $set: {
            ...(fullName !== undefined ? { fullName } : {}),
            ...(email !== undefined ? { email } : {}),
          },
        },
        { new: true, projection: { phone: 1, fullName: 1, email: 1, role: 1 } },
      );

      if (!updatedUser) {
        ResponseHandler.error(res, 'User not found.', 404);
        return;
      }

      ResponseHandler.success(res, 'Profile updated successfully.', {
        user: {
          id: updatedUser._id,
          phone: updatedUser.phone,
          fullName: updatedUser.fullName,
          email: updatedUser.email,
          role: updatedUser.role,
        },
      });
    } catch (error) {
      ResponseHandler.error(res, 'Something went wrong while updating profile.', 500, {
        error: error instanceof Error ? error : undefined,
        context: {
          controller: 'updateProfile',
          method: req.method,
          path: req.path,
        },
      });
    }
  }
}
