import { Router } from 'express';
import { authenticate } from '../../middlewares/authenticate';
import { validate } from '../../middlewares/validate';
import { UserController } from './user.controller';
import { userUpdateProfileSchema } from './dto/update.profile';

const router = Router();

router.post('/exist-phone', UserController.checkPhone);
router.post('/send-otp', UserController.sendOtp);
router.post('/verify-otp', UserController.verifyOtp);
router.patch(
  '/profile',
  authenticate,
  validate({ body: userUpdateProfileSchema }),
  UserController.updateProfile,
);

export default router;
