import { z } from 'zod';

export const userUpdateProfileSchema = z
  .object({
    fullName: z.string().trim().min(1, 'Full name is required').optional(),
    email: z.string().trim().toLowerCase().email('Invalid email address').optional(),
  })
  .refine((data) => data.fullName !== undefined || data.email !== undefined, {
    message: 'At least one profile field is required',
  });

export type UserUpdateProfileDto = z.infer<typeof userUpdateProfileSchema>;
