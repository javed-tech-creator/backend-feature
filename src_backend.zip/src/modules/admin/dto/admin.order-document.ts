import { z } from 'zod';
import { objectIdSchema } from '../../../utils/object-id';

export const orderDocumentParamsSchema = z.object({
  orderId: objectIdSchema,
});

export type OrderDocumentParams = z.infer<typeof orderDocumentParamsSchema>;