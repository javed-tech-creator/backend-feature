import { paginationQuerySchema, searchSchema } from '../../../utils/pagination';

export const adminListQuerySchema = paginationQuerySchema.extend({
  search: searchSchema,
});

export type AdminListQuery = typeof adminListQuerySchema._output;
