import { paginationQuerySchema } from '../../../utils/pagination';

export const adminListQuerySchema = paginationQuerySchema;

export type AdminListQuery = typeof adminListQuerySchema._output;