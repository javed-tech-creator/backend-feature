import bcrypt from 'bcryptjs';
import { UserRole } from '../../lib/enum';
import { Document } from '../../model/document.model';
import { OrderAddress } from '../../model/order-address.model';
import { Order } from '../../model/order.model';
import { User } from '../../model/user.model';
import { ApiError } from '../../utils/api-error';
import { buildMeta, buildSearchFilter, toSkipTake } from '../../utils/pagination';
import { signToken, toUserResponse } from '../../utils/token';
import { uploadImage } from '../../utils/upload';
import {
  AdminListQuery,
  AdminLoginDto,
  AdminSignupDto,
  OrderDocumentParams,
} from './dto/index.dto';
import { PASSWORD_SALT_ROUNDS } from '../../lib/constant';

const isEmail = (value: string): boolean => value.includes('@');

export class AdminService {
  static async uploadOrderDocuments(
    orderId: OrderDocumentParams['orderId'],
    files?: { [fieldname: string]: Express.Multer.File[] },
  ) {
    const aadhaar = files?.aadhaar?.[0];
    const imei = files?.imei?.[0];

    if (!aadhaar || !imei) {
      throw ApiError.badRequest('Both aadhaar and imei images are required');
    }

    const order = await Order.findOne({ _id: orderId, isDeleted: false }).select('userId');
    if (!order) {
      throw ApiError.notFound('Order not found');
    }

    const existingDocument = await Document.findOne({ orderId, isDeleted: false });
    if (existingDocument) {
      throw ApiError.conflict('Documents already uploaded for this order');
    }

    const [aadhaarImage, imeiImage] = await Promise.all([
      uploadImage(aadhaar, 'documents/aadhaar'),
      uploadImage(imei, 'documents/imei'),
    ]);

    return Document.create({
      userId: order.userId,
      orderId: order._id,
      aadhaar: aadhaarImage,
      imei: imeiImage,
    });
  }

  static async listUsers(query: AdminListQuery) {
    const { skip, take } = toSkipTake(query);
    const filter = {
      isDeleted: false,
      ...buildSearchFilter(query.search, ['fullName', 'email', 'phone']),
    };

    const [users, total] = await Promise.all([
      User.find(filter)
        .select('phone email createdAt updatedAt fullName isVerified')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(take)
        .lean(),
      User.countDocuments(filter),
    ]);

    return { users, meta: buildMeta(query, total) };
  }

  static async listOrders(query: AdminListQuery) {
    const { skip, take } = toSkipTake(query);
    const filter = {
      isDeleted: false,
      ...buildSearchFilter(query.search, ['status', 'state', 'city', 'orderType']),
    };

    const [orders, total] = await Promise.all([
      Order.find(filter)
        .select(
          'orderNumber userId modelId storageId basePrice finalPrice status state city createdAt updatedAt',
        )
        .populate('userId', 'fullName email phone')
        .populate({
          path: 'modelId',
          select: 'name logo brandId',
          populate: {
            path: 'brandId',
            select: 'name deviceId',
            populate: {
              path: 'deviceId',
              select: 'name',
            },
          },
        })
        .populate('storageId', 'ram rom')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(take)
        .lean(),
      Order.countDocuments(filter),
    ]);

    const orderIds = orders.map((order) => order._id);
    const addresses = await OrderAddress.find({
      orderId: { $in: orderIds },
      isDeleted: false,
    })
      .select('orderId address1 address2 state city pincode')
      .lean();
    const addressByOrderId = new Map(
      addresses.map((address) => [address.orderId.toString(), address]),
    );
    const documents = await Document.find({
      orderId: { $in: orderIds },
      isDeleted: false,
    })
      .select('orderId aadhaar imei')
      .lean();
    const documentByOrderId = new Map(
      documents.map((document) => [document.orderId.toString(), document]),
    );

    return {
      orders: orders.map((order) => ({
        ...order,
        orderId: order._id,
        document: documentByOrderId.get(order._id.toString()) ?? null,
        address: (() => {
          const address = addressByOrderId.get(order._id.toString());
          return address
            ? {
                address1: address.address1,
                address2: address.address2,
                state: address.state,
                city: address.city,
                pincode: address.pincode,
              }
            : null;
        })(),
      })),
      meta: buildMeta(query, total),
    };
  }

  static async signup({ phone, email, password, fullName }: AdminSignupDto) {
    const existing = await User.findOne({
      $or: [{ phone }, ...(email ? [{ email }] : [])],
      isDeleted: false,
    });

    if (existing) {
      throw ApiError.conflict('An account with this phone or email already exists');
    }

    const admin = await User.create({
      phone,
      email,
      password: await bcrypt.hash(password, PASSWORD_SALT_ROUNDS),
      fullName,
      role: UserRole.ADMIN,
    });

    return toUserResponse(admin);
  }

  static async login({ identifier, password }: AdminLoginDto) {
    const admin = await User.findOne({
      ...(isEmail(identifier) ? { email: identifier.toLowerCase() } : { phone: identifier }),
      role: UserRole.ADMIN,
      isDeleted: false,
    }).select('+password');

    if (!admin || !admin.password) {
      throw ApiError.unauthorized('Invalid credentials');
    }

    const passwordMatches = await bcrypt.compare(password, admin.password);
    if (!passwordMatches) {
      throw ApiError.unauthorized('Invalid credentials');
    }

    return {
      token: signToken(admin.id, admin.role),
      admin: toUserResponse(admin),
    };
  }
}
