import { Router } from 'express';
import { UserRole } from '../../lib/enum';
import { authenticate } from '../../middlewares/authenticate';
import { authorize } from '../../middlewares/authorize';
import { strictLimiter } from '../../middlewares/rate-limit';
import { uploadImageFile } from '../../middlewares/upload-image';
import { uploadFile } from '../../middlewares/upload-file';
import { validate } from '../../middlewares/validate';
import { idParamSchema } from '../../utils/object-id';
import { brandCreateSchema, brandUpdateSchema } from '../brand/dto/index.dto';
import { deviceCreateSchema, deviceUpdateSchema } from '../device/dto/index.dto';
import { modelCreateSchema, modelUpdateSchema } from '../model/dto/index.dto';
import { orderStatusUpdateSchema } from '../order/dto/index.dto';
import {
  questionCreateSchema,
  questionReorderSchema,
  questionUpdateSchema,
} from '../question/dto/index.dto';
import {
  questionOptionCreateSchema,
  questionOptionUpdateSchema,
} from '../question-option/dto/index.dto';
import { storageCreateSchema, storageUpdateSchema } from '../storage/dto/index.dto';
import { modelBulkUploadSchema } from '../model/dto/index.dto';
import { AdminController } from './admin.controller';
import { adminListQuerySchema, adminLoginSchema } from './dto/index.dto';

const router = Router();

router.post('/login', strictLimiter, validate({ body: adminLoginSchema }), AdminController.login);
router.post('/logout', AdminController.logout);
// Every route below is admin-only — the guard is applied once, here.
router.use(authenticate, authorize(UserRole.ADMIN));

// Admin listings
router.get('/users', validate({ query: adminListQuerySchema }), AdminController.listUsers);
router.get('/orders', validate({ query: adminListQuerySchema }), AdminController.listOrders);

// Device
router.post(
  '/device',
  uploadImageFile.single('logo'),
  validate({ body: deviceCreateSchema }),
  AdminController.createDevice,
);
router.patch(
  '/device/:id',
  uploadImageFile.single('logo'),
  validate({ params: idParamSchema, body: deviceUpdateSchema }),
  AdminController.updateDevice,
);
router.delete('/device/:id', validate({ params: idParamSchema }), AdminController.removeDevice);

// Brand
router.post(
  '/brand',
  uploadImageFile.single('logo'),
  validate({ body: brandCreateSchema }),
  AdminController.createBrand,
);
router.patch(
  '/brand/:id',
  uploadImageFile.single('logo'),
  validate({ params: idParamSchema, body: brandUpdateSchema }),
  AdminController.updateBrand,
);
router.delete('/brand/:id', validate({ params: idParamSchema }), AdminController.removeBrand);

// Storage
router.post('/storage', validate({ body: storageCreateSchema }), AdminController.createStorage);
router.patch(
  '/storage/:id',
  validate({ params: idParamSchema, body: storageUpdateSchema }),
  AdminController.updateStorage,
);
router.delete('/storage/:id', validate({ params: idParamSchema }), AdminController.removeStorage);

// Model
router.post(
  '/model',
  uploadImageFile.single('logo'),
  validate({ body: modelCreateSchema }),
  AdminController.createModel,
);
router.post(
  '/model/upload',
  uploadFile.single('file'),
  validate({ body: modelBulkUploadSchema }),
  AdminController.bulkUploadModels,
);
router.patch(
  '/model/:id',
  uploadImageFile.single('logo'),
  validate({ params: idParamSchema, body: modelUpdateSchema }),
  AdminController.updateModel,
);
router.delete('/model/:id', validate({ params: idParamSchema }), AdminController.removeModel);

// Question
router.post('/question', validate({ body: questionCreateSchema }), AdminController.createQuestion);
// Declared before '/question/:id' so 'reorder' is not swallowed as an id.
router.patch(
  '/question/reorder',
  validate({ body: questionReorderSchema }),
  AdminController.reorderQuestions,
);
router.patch(
  '/question/:id',
  validate({ params: idParamSchema, body: questionUpdateSchema }),
  AdminController.updateQuestion,
);
router.delete('/question/:id', validate({ params: idParamSchema }), AdminController.removeQuestion);

// Question option
router.post(
  '/question-option',
  validate({ body: questionOptionCreateSchema }),
  AdminController.createQuestionOption,
);
router.patch(
  '/question-option/:id',
  validate({ params: idParamSchema, body: questionOptionUpdateSchema }),
  AdminController.updateQuestionOption,
);
router.delete(
  '/question-option/:id',
  validate({ params: idParamSchema }),
  AdminController.removeQuestionOption,
);

// Order
router.patch(
  '/order/:id/status',
  validate({ params: idParamSchema, body: orderStatusUpdateSchema }),
  AdminController.updateOrderStatus,
);

export default router;
