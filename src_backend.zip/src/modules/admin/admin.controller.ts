import { NextFunction, Request, Response } from 'express';
import { ResponseHandler } from '../../helper/response.handler';
import { AUTH_COOKIE_Admin } from '../../lib/constant';
import { clearAuthCookie, setAuthCookie } from '../../utils/auth-cookie';
import { BrandService } from '../brand/brand.service';
import { DeviceService } from '../device/device.service';
import { ModelService } from '../model/model.service';
import { OrderService } from '../order/order.service';
import { QuestionService } from '../question/question.service';
import { QuestionOptionService } from '../question-option/question-option.service';
import { StorageService } from '../storage/storage.service';
import { AdminService } from './admin.service';
import { adminListQuerySchema } from './dto/index.dto';

export class AdminController {
  static async listUsers(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = adminListQuerySchema.parse(req.query);
      const { users, meta } = await AdminService.listUsers(query);
      ResponseHandler.paginated(res, 'Users fetched successfully', users, meta);
    } catch (error) {
      next(error);
    }
  }

  static async listOrders(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = adminListQuerySchema.parse(req.query);
      const { orders, meta } = await AdminService.listOrders(query);
      ResponseHandler.paginated(res, 'Orders fetched successfully', orders, meta);
    } catch (error) {
      next(error);
    }
  }

  static async login(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { token, admin } = await AdminService.login(req.body);
      setAuthCookie(res, token, AUTH_COOKIE_Admin);
      ResponseHandler.success(res, 'Logged in successfully', admin);
    } catch (error) {
      next(error);
    }
  }
  static async logout(req: Request, res: Response): Promise<void> {
   clearAuthCookie(res, AUTH_COOKIE_Admin);
  ResponseHandler.success(res, "Logout successful");
}

  static async createDevice(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const device = await DeviceService.create(req.body, req.file);
      ResponseHandler.success(res, 'Device created successfully', device, 201);
    } catch (error) {
      next(error);
    }
  }

  static async updateDevice(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const device = await DeviceService.update(req.params.id as string, req.body, req.file);
      ResponseHandler.success(res, 'Device updated successfully', device);
    } catch (error) {
      next(error);
    }
  }

  static async removeDevice(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await DeviceService.remove(req.params.id as string);
      ResponseHandler.success(res, 'Device deleted successfully');
    } catch (error) {
      next(error);
    }
  }

  static async createBrand(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const brand = await BrandService.create(req.body, req.file);
      ResponseHandler.success(res, 'Brand created successfully', brand, 201);
    } catch (error) {
      next(error);
    }
  }

  static async updateBrand(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const brand = await BrandService.update(req.params.id as string, req.body, req.file);
      ResponseHandler.success(res, 'Brand updated successfully', brand);
    } catch (error) {
      next(error);
    }
  }

  static async removeBrand(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await BrandService.remove(req.params.id as string);
      ResponseHandler.success(res, 'Brand deleted successfully');
    } catch (error) {
      next(error);
    }
  }

  static async createStorage(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const storage = await StorageService.create(req.body);
      ResponseHandler.success(res, 'Storage created successfully', storage, 201);
    } catch (error) {
      next(error);
    }
  }

  static async updateStorage(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const storage = await StorageService.update(req.params.id as string, req.body);
      ResponseHandler.success(res, 'Storage updated successfully', storage);
    } catch (error) {
      next(error);
    }
  }

  static async removeStorage(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await StorageService.remove(req.params.id as string);
      ResponseHandler.success(res, 'Storage deleted successfully');
    } catch (error) {
      next(error);
    }
  }

  static async createModel(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const model = await ModelService.create(req.body, req.file);
      ResponseHandler.success(res, 'Model created successfully', model, 201);
    } catch (error) {
      next(error);
    }
  }

  static async bulkUploadModels(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const models = await ModelService.bulkUpload(req.body, req.file);
      ResponseHandler.success(res, 'Models uploaded successfully', models, 201);
    } catch (error) {
      next(error);
    }
  }

  static async updateModel(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const model = await ModelService.update(req.params.id as string, req.body, req.file);
      ResponseHandler.success(res, 'Model updated successfully', model);
    } catch (error) {
      next(error);
    }
  }

  static async removeModel(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await ModelService.remove(req.params.id as string);
      ResponseHandler.success(res, 'Model deleted successfully');
    } catch (error) {
      next(error);
    }
  }

  static async createQuestion(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const question = await QuestionService.create(req.body);
      ResponseHandler.success(res, 'Question created successfully', question, 201);
    } catch (error) {
      next(error);
    }
  }

  static async updateQuestion(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const question = await QuestionService.update(req.params.id as string, req.body);
      ResponseHandler.success(res, 'Question updated successfully', question);
    } catch (error) {
      next(error);
    }
  }

  static async reorderQuestions(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await QuestionService.reorder(req.body);
      ResponseHandler.success(res, 'Questions reordered successfully');
    } catch (error) {
      next(error);
    }
  }

  static async removeQuestion(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await QuestionService.remove(req.params.id as string);
      ResponseHandler.success(res, 'Question deleted successfully');
    } catch (error) {
      next(error);
    }
  }

  static async createQuestionOption(
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> {
    try {
      const option = await QuestionOptionService.create(req.body);
      ResponseHandler.success(res, 'Question option created successfully', option, 201);
    } catch (error) {
      next(error);
    }
  }

  static async updateQuestionOption(
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> {
    try {
      const option = await QuestionOptionService.update(req.params.id as string, req.body);
      ResponseHandler.success(res, 'Question option updated successfully', option);
    } catch (error) {
      next(error);
    }
  }

  static async removeQuestionOption(
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> {
    try {
      await QuestionOptionService.remove(req.params.id as string);
      ResponseHandler.success(res, 'Question option deleted successfully');
    } catch (error) {
      next(error);
    }
  }

  static async updateOrderStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const order = await OrderService.updateStatus(req.params.id as string, req.body);
      ResponseHandler.success(res, 'Order status updated successfully', order);
    } catch (error) {
      next(error);
    }
  }

  static async uploadOrderDocuments(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const files = req.files as
        | { [fieldname: string]: Express.Multer.File[] }
        | undefined;
      const document = await AdminService.uploadOrderDocuments(
        req.params.orderId as string,
        files,
      );
      ResponseHandler.success(res, 'Order documents uploaded successfully', document, 201);
    } catch (error) {
      next(error);
    }
  }
}
