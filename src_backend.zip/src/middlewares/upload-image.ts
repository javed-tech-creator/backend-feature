import multer from 'multer';
import { env } from '../config/env';
import { ApiError } from '../utils/api-error';

/** Keeps the file in memory so the service can stream it straight to Cloudinary. */
export const uploadImageFile = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: env.upload.maxFileSize, files: 2 },
  fileFilter: (_req, file, callback) => {
    if (!file.mimetype.startsWith('image/')) {
      callback(ApiError.badRequest('Only image files are allowed'));
      return;
    }
    callback(null, true);
  },
});
